import re
import time
from config import data, save_data, DEFAULT_MESSAGES_LIMIT

# ========================================================================
#                      نظام تعدد اللغات
# ========================================================================

DEFAULT_LANGUAGE = 'ar'

LANGUAGES = {
    'ar': {'name': 'العربية', 'flag': '🇮🇶'},
    'en': {'name': 'English', 'flag': '🇬🇧'},
    'ru': {'name': 'Русский', 'flag': '🇷🇺'},
    'zh': {'name': '中文', 'flag': '🇨🇳'},
    'fa': {'name': 'فارسی', 'flag': '🇮🇷'},
}

# رموز اللغة المستخدمة مع مكتبة الترجمة (قد تختلف عن مفاتيحنا الداخلية)
TRANSLATE_TARGET_CODE = {
    'ar': 'ar',
    'en': 'en',
    'ru': 'ru',
    'zh': 'zh-CN',
    'fa': 'fa',
}

# نطاقات يونيكود تقريبية للتحقق هل النص "يبدو" مكتوباً بلغة معينة
_SCRIPT_RANGES = {
    'ru': r'[\u0400-\u04FF]',
    'zh': r'[\u4e00-\u9fff]',
    'ar': r'[\u0600-\u06FF]',
    'fa': r'[\u0600-\u06FF]',  # ملاحظة: العربية والفارسية تتشاركان أغلب نطاق يونيكود هذا
}

TEXTS = {
    'btn_new_chat': {'ar': '🔄 محادثة جديدة', 'en': '🔄 New Chat', 'ru': '🔄 Новый чат', 'zh': '🔄 新对话', 'fa': '🔄 گفتگوی جدید'},
    'btn_search': {'ar': '🔍 بحث', 'en': '🔍 Search', 'ru': '🔍 Поиск', 'zh': '🔍 搜索', 'fa': '🔍 جستجو'},
    'btn_research_models': {
        'ar': '🧪 نماذج البحث',
        'en': '🧪 Research Models',
        'ru': '🧪 Модели поиска',
        'zh': '🧪 搜索模型',
        'fa': '🧪 مدل‌های جستجو',
    },
    'btn_developer': {'ar': '👨‍💻 المطور', 'en': '👨‍💻 Developer', 'ru': '👨‍💻 Разработчик', 'zh': '👨‍💻 开发者', 'fa': '👨‍💻 توسعه‌دهنده'},
    'btn_channel': {'ar': '📢 قناة المطور', 'en': '📢 Dev Channel', 'ru': '📢 Канал разработчика', 'zh': '📢 开发者频道', 'fa': '📢 کانال توسعه‌دهنده'},
    'btn_account_info': {'ar': 'ℹ️ معلومات حسابك', 'en': 'ℹ️ Your Account Info', 'ru': 'ℹ️ Информация об аккаунте', 'zh': 'ℹ️ 您的账户信息', 'fa': 'ℹ️ اطلاعات حساب شما'},
    'btn_vip': {'ar': '🌟 اشتراك VIP', 'en': '🌟 VIP Subscription', 'ru': '🌟 VIP подписка', 'zh': '🌟 VIP订阅', 'fa': '🌟 اشتراک VIP'},
    'btn_support': {'ar': '📩 تواصل مع الدعم', 'en': '📩 Contact Support', 'ru': '📩 Связаться с поддержкой', 'zh': '📩 联系客服', 'fa': '📩 ارتباط با پشتیبانی'},
    'btn_language': {'ar': '🌐 تغيير اللغة', 'en': '🌐 Change Language', 'ru': '🌐 Изменить язык', 'zh': '🌐 更改语言', 'fa': '🌐 تغییر زبان'},
    'btn_back': {'ar': '🔙 رجوع', 'en': '🔙 Back', 'ru': '🔙 Назад', 'zh': '🔙 返回', 'fa': '🔙 بازگشت'},
    'btn_cancel': {'ar': '❌ الغاء', 'en': '❌ Cancel', 'ru': '❌ Отмена', 'zh': '❌ 取消', 'fa': '❌ لغو'},
    'btn_contact_subscribe': {'ar': '📩 تواصل للاشتراك', 'en': '📩 Contact to Subscribe', 'ru': '📩 Связаться для подписки', 'zh': '📩 联系订阅', 'fa': '📩 تماس برای اشتراک'},
    'btn_join_channel': {'ar': '📢 اشترك في القناة', 'en': '📢 Join Channel', 'ru': '📢 Подписаться на канал', 'zh': '📢 加入频道', 'fa': '📢 عضویت در کانال'},

    'main_menu_title': {'ar': '🏠 القائمة الرئيسية', 'en': '🏠 Main Menu', 'ru': '🏠 Главное меню', 'zh': '🏠 主菜单', 'fa': '🏠 منوی اصلی'},

    'subscribe_required': {
        'ar': '⚠️ يجب الاشتراك في القناة أولاً:',
        'en': '⚠️ You must join the channel first:',
        'ru': '⚠️ Сначала вы должны подписаться на канал:',
        'zh': '⚠️ 您必须先加入频道:',
        'fa': '⚠️ ابتدا باید در کانال عضو شوید:',
    },
    'search_prompt': {
        'ar': '🔍 **أرسل ما تريد البحث عنه:**\nمثال: `/search اخبار التكنولوجيا`',
        'en': '🔍 **Send what you want to search for:**\nExample: `/search technology news`',
        'ru': '🔍 **Отправьте, что вы хотите найти:**\nПример: `/search новости технологий`',
        'zh': '🔍 **请发送您要搜索的内容:**\n例如: `/search 科技新闻`',
        'fa': '🔍 **آنچه می‌خواهید جستجو کنید را ارسال کنید:**\nمثال: `/search اخبار فناوری`',
    },
    'search_in_progress': {
        'ar': '🔍 **جاري البحث...**',
        'en': '🔍 **Searching...**',
        'ru': '🔍 **Идёт поиск...**',
        'zh': '🔍 **正在搜索...**',
        'fa': '🔍 **در حال جستجو...**',
    },
    'search_cancel_button_toast': {
        'ar': '✅ تم إلغاء البحث بنجاح',
        'en': '✅ Search cancelled successfully',
        'ru': '✅ Поиск успешно отменён',
        'zh': '✅ 搜索已成功取消',
        'fa': '✅ جستجو با موفقیت لغو شد',
    },
    'btn_search_cancel': {
        'ar': '⛔ إلغاء البحث',
        'en': '⛔ Cancel Search',
        'ru': '⛔ Отменить поиск',
        'zh': '⛔ 取消搜索',
        'fa': '⛔ لغو جستجو',
    },
    'search_general_prompt': {
        'ar': '🔍 **أرسل ما تريد البحث عنه:**\nمثال: اخبار التكنولوجيا',
        'en': '🔍 **Send what you want to search for:**\nExample: technology news',
        'ru': '🔍 **Отправьте, что вы хотите найти:**\nПример: новости технологий',
        'zh': '🔍 **请发送您要搜索的内容:**\n例如: 科技新闻',
        'fa': '🔍 **آنچه می‌خواهید جستجو کنید را ارسال کنید:**\nمثال: اخبار فناوری',
    },
    # ===== مطالبة بإدخال نص البحث لبحث V1 (DuckDuckGo) =====
    'search_text_v1_prompt': {
        'ar': '🔍 [WORMGPT-research-V1]\n\n📝 أرسل النص أو الكلمة التي تريد البحث عنها في DuckDuckGo:',
        'en': '🔍 [WORMGPT-research-V1]\n\n📝 Send the text or keyword you want to search on DuckDuckGo:',
        'ru': '🔍 [WORMGPT-research-V1]\n\n📝 Отправьте текст или ключевое слово для поиска в DuckDuckGo:',
        'zh': '🔍 [WORMGPT-research-V1]\n\n📝 请发送您想在DuckDuckGo上搜索的文本或关键词:',
        'fa': '🔍 [WORMGPT-research-V1]\n\n📝 متن یا کلمه کلیدی را که می‌خواهید در DuckDuckGo جستجو کنید ارسال کنید:',
    },
    # ===== مطالبة موحدة للبحث (نص / صورة / صورة مع نص) =====
    'search_unified_prompt': {
        'ar': '🔍 <b>وضع البحث مفعّل</b>\n\n📝 يمكنك إرسال:\n• نص للبحث عنه\n• صورة للبحث بها\n• صورة مع نص للبحث بالصورة والنص معاً\n\n💡 سيتم الكشف عن نوع البحث تلقائياً.',
        'en': '🔍 <b>Search Mode Active</b>\n\n📝 You can send:\n• Text to search\n• An image to search with\n• An image with text to search with both\n\n💡 The search type is detected automatically.',
        'ru': '🔍 <b>Режим поиска активен</b>\n\n📝 Вы можете отправить:\n• Текст для поиска\n• Изображение для поиска\n• Изображение с текстом для совместного поиска\n\n💡 Тип поиска определяется автоматически.',
        'zh': '🔍 <b>搜索模式已激活</b>\n\n📝 您可以发送:\n• 要搜索的文本\n• 用于搜索的图片\n• 带文本的图片以同时搜索\n\n💡 搜索类型将自动检测。',
        'fa': '🔍 <b>حالت جستجو فعال است</b>\n\n📝 می‌توانید ارسال کنید:\n• متن برای جستجو\n• تصویر برای جستجو\n• تصویر با متن برای جستجوی همزمان\n\n💡 نوع جستجو به‌صورت خودکار شناسایی می‌شود.',
    },
    # ===== إشعار للمستخدم: أرسل صورتك مع نص البحث V2 =====
    'research_v2_image_no_caption': {
        'ar': '🖼️ <b>تم استلام صورتك</b>\n\n📝 أرسل رسالتك الآن مع الصورة لإجراء بحث عميق.',
        'en': '🖼️ <b>Your image was received</b>\n\n📝 Send your message now together with the image to start a deep search.',
        'ru': '🖼️ <b>Изображение получено</b>\n\n📝 Отправьте ваше сообщение вместе с изображением для глубокого поиска.',
        'zh': '🖼️ <b>图片已收到</b>\n\n📝 请发送您的消息与图片一起进行深度搜索。',
        'fa': '🖼️ <b>تصویر شما دریافت شد</b>\n\n📝 پیام خود را همراه با تصویر برای جستجوی عمیق ارسال کنید.',
    },
    # ===== مطالبة بإدخال نص البحث لبحث V2 (مع أو بدون صورة) =====
    'research_v2_text_prompt': {
        'ar': '🔎 [WORMGPT-research-V2]\n\n📝 أرسل طلبك (نص، أو صورة مع نص) للبحث العميق:',
        'en': '🔎 [WORMGPT-research-V2]\n\n📝 Send your request (text, or image with text) for deep search:',
        'ru': '🔎 [WORMGPT-research-V2]\n\n📝 Отправьте запрос (текст или изображение с текстом) для глубокого поиска:',
        'zh': '🔎 [WORMGPT-research-V2]\n\n📝 发送您的请求(文字或图片加文字)以进行深度搜索:',
        'fa': '🔎 [WORMGPT-research-V2]\n\n📝 درخواست خود را (متن یا تصویر با متن) برای جستجوی عمیق ارسال کنید:',
    },
    'copy_code_alert': {
        'ar': '📋 تم نسخ الكود! يمكنك لصقه في أي مكان ✅',
        'en': '📋 Code copied! You can paste it anywhere ✅',
        'ru': '📋 Код скопирован! Вы можете вставить его куда угодно ✅',
        'zh': '📋 代码已复制!您可以粘贴到任何地方 ✅',
        'fa': '📋 کد کپی شد! می‌توانید آن را هرجا که می‌خواهید جای‌گذاری کنید ✅',
    },

    'new_chat_toast': {
        'ar': '✅ تم البدء',
        'en': '✅ Started',
        'ru': '✅ Начато',
        'zh': '✅ 已开始',
        'fa': '✅ شروع شد',
    },
    'new_chat_confirm': {
        'ar': '🔄 **تم بدء محادثة جديدة!**\nالسياق السابق تم مسحه.',
        'en': '🔄 **New conversation started!**\nThe previous context has been cleared.',
        'ru': '🔄 **Начат новый разговор!**\nПредыдущий контекст очищен.',
        'zh': '🔄 **新对话已开始!**\n之前的上下文已清除。',
        'fa': '🔄 **گفتگوی جدید شروع شد!**\nزمینه قبلی پاک شد.',
    },
    'clear_confirm': {
        'ar': '🗑️ **تم مسح سياق المحادثة!**\nيمكنك البدء من جديد.',
        'en': '🗑️ **Conversation context cleared!**\nYou can start fresh.',
        'ru': '🗑️ **Контекст разговора очищен!**\nВы можете начать заново.',
        'zh': '🗑️ **对话上下文已清除!**\n您可以重新开始。',
        'fa': '🗑️ **زمینه گفتگو پاک شد!**\nمی‌توانید از نو شروع کنید.',
    },

    'cooldown_wait': {
        'ar': '⏳ <b>يرجى الانتظار {seconds} ثانية</b>\nسيتم الرد على رسالتك تلقائياً بعد انتهاء الوقت ⏱️\n\n💎 اشترك VIP للتحدث بدون أي وقت انتظار!',
        'en': '⏳ <b>Please wait {seconds} seconds</b>\nYour message will be answered automatically once the time is up ⏱️\n\n💎 Subscribe to VIP to chat with no waiting time!',
        'ru': '⏳ <b>Пожалуйста, подождите {seconds} секунд</b>\nНа ваше сообщение ответят автоматически после истечения времени ⏱️\n\n💎 Подпишитесь на VIP, чтобы общаться без ожидания!',
        'zh': '⏳ <b>请等待 {seconds} 秒</b>\n时间到后将自动回复您的消息 ⏱️\n\n💎 订阅 VIP 即可无需等待畅聊!',
        'fa': '⏳ <b>لطفاً {seconds} ثانیه صبر کنید</b>\nپس از پایان زمان، پاسخ پیام شما به‌صورت خودکار ارسال می‌شود ⏱️\n\n💎 برای گفتگو بدون هیچ زمان انتظار، VIP شوید!',
    },
    'quota_exceeded': {
        'ar': '⚠️ <b>انتهى رصيد رسائلك!</b>\n\nلقد استهلكت جميع رسائلك المتاحة.\nللحصول على رصيد إضافي أو اشتراك VIP بدون حدود وبدون وقت انتظار، تواصل مع الإدارة: {owner}',
        'en': '⚠️ <b>Your message balance has run out!</b>\n\nYou have used all your available messages.\nTo get more messages or an unlimited, wait-free VIP subscription, contact admin: {owner}',
        'ru': '⚠️ <b>Ваш баланс сообщений закончился!</b>\n\nВы использовали все доступные сообщения.\nЧтобы получить больше сообщений или безлимитную VIP-подписку без ожидания, свяжитесь с администрацией: {owner}',
        'zh': '⚠️ <b>您的消息额度已用完!</b>\n\n您已用完所有可用消息。\n如需获取更多额度或无限制、无需等待的 VIP 订阅,请联系管理员:{owner}',
        'fa': '⚠️ <b>اعتبار پیام‌های شما به پایان رسید!</b>\n\nشما تمام پیام‌های موجود خود را استفاده کرده‌اید.\nبرای دریافت اعتبار بیشتر یا اشتراک VIP بدون محدودیت و بدون زمان انتظار، با ادمین تماس بگیرید: {owner}',
    },
    'maintenance_notice': {
        'ar': '🛠️ <b>البوت تحت الصيانة حالياً</b>\n\nنعمل على تحسينات وتطويرات، نرجو المحاولة بعد قليل 🙏',
        'en': '🛠️ <b>The bot is currently under maintenance</b>\n\nWe are working on improvements, please try again shortly 🙏',
        'ru': '🛠️ <b>Бот сейчас на техническом обслуживании</b>\n\nМы работаем над улучшениями, пожалуйста, попробуйте чуть позже 🙏',
        'zh': '🛠️ <b>机器人目前正在维护中</b>\n\n我们正在进行改进,请稍后再试 🙏',
        'fa': '🛠️ <b>بات در حال حاضر در حالت تعمیر و نگهداری است</b>\n\nما در حال انجام بهبودها هستیم، لطفاً کمی بعد دوباره تلاش کنید 🙏',
    },
    'maintenance_notice_alert': {
        'ar': '🛠️ البوت تحت الصيانة حالياً، حاول بعد قليل.',
        'en': '🛠️ The bot is under maintenance, please try again shortly.',
        'ru': '🛠️ Бот на техническом обслуживании, попробуйте позже.',
        'zh': '🛠️ 机器人正在维护中,请稍后再试。',
        'fa': '🛠️ بات در حال تعمیر است، کمی بعد دوباره تلاش کنید.',
    },

    'vip_status_active': {
        'ar': '✅ أنت مشترك VIP حالياً، ينتهي اشتراكك في: {expiry}',
        'en': '✅ You are currently a VIP subscriber, your subscription ends on: {expiry}',
        'ru': '✅ Вы сейчас являетесь VIP-подписчиком, ваша подписка истекает: {expiry}',
        'zh': '✅ 您当前是 VIP 订阅者,订阅将于 {expiry} 到期',
        'fa': '✅ شما در حال حاضر مشترک VIP هستید، اشتراک شما در {expiry} پایان می‌یابد',
    },
    'vip_status_inactive': {
        'ar': '⭕ أنت لست مشتركاً VIP حالياً',
        'en': '⭕ You are not currently a VIP subscriber',
        'ru': '⭕ Вы сейчас не являетесь VIP-подписчиком',
        'zh': '⭕ 您当前不是 VIP 订阅者',
        'fa': '⭕ شما در حال حاضر مشترک VIP نیستید',
    },
    'vip_panel_body': {
        'ar': '🌟 <b>اشتراك VIP</b>\n\n{status_line}\n\n<b>✨ مميزات VIP:</b>\n• 💬 دردشة بدون أي حدود في عدد الرسائل\n• ⚡ بدون أي وقت انتظار بين الرسائل\n• 🚀 أولوية في الرد\n• 📸 تحليل الصور مع V2\n• 🎁 مميزات إضافية قادمة قريباً\n\n📩 للاشتراك أو الاستفسار، تواصل مع الدعم',
        'en': '🌟 <b>VIP Subscription</b>\n\n{status_line}\n\n<b>✨ VIP Benefits:</b>\n• 💬 Chat with no message limits\n• ⚡ No waiting time between messages\n• 🚀 Priority responses\n• 📸 Image analysis with V2\n• 🎁 More features coming soon\n\n📩 To subscribe or ask questions, contact support',
        'ru': '🌟 <b>VIP-подписка</b>\n\n{status_line}\n\n<b>✨ Преимущества VIP:</b>\n• 💬 Общение без ограничений по количеству сообщений\n• ⚡ Без ожидания между сообщениями\n• 🚀 Приоритетные ответы\n• 📸 Анализ изображений с V2\n• 🎁 Больше функций уже скоро\n\n📩 Чтобы подписаться или задать вопрос, свяжитесь с поддержкой',
        'zh': '🌟 <b>VIP 订阅</b>\n\n{status_line}\n\n<b>✨ VIP 权益:</b>\n• 💬 聊天消息无限制\n• ⚡ 消息之间无需等待\n• 🚀 优先回复\n• 📸 V2图像分析功能\n• 🎁 更多功能即将推出\n\n📩 如需订阅或咨询,请联系客服',
        'fa': '🌟 <b>اشتراک VIP</b>\n\n{status_line}\n\n<b>✨ مزایای VIP:</b>\n• 💬 گفتگو بدون هیچ محدودیتی در تعداد پیام\n• ⚡ بدون هیچ زمان انتظاری بین پیام‌ها\n• 🚀 پاسخ‌دهی با اولویت\n• 📸 تحلیل تصویر با V2\n• 🎁 ویژگی‌های بیشتر به‌زودی\n\n📩 برای اشتراک یا پرسش، با پشتیبانی تماس بگیرید',
    },

    'account_info_panel': {
        'ar': 'ℹ️ <b>معلومات حسابك</b>\n\n🆔 الايدي: <code>{user_id}</code>\n👤 اليوزر: {username}\n{status_line}\n💬 الرسائل المتبقية: {messages_left}\n📨 إجمالي الرسائل المرسلة: {total_sent}\n📅 تاريخ الانضمام: {joined_at}',
        'en': 'ℹ️ <b>Your Account Info</b>\n\n🆔 ID: <code>{user_id}</code>\n👤 Username: {username}\n{status_line}\n💬 Messages remaining: {messages_left}\n📨 Total messages sent: {total_sent}\n📅 Joined on: {joined_at}',
        'ru': 'ℹ️ <b>Информация о вашем аккаунте</b>\n\n🆔 ID: <code>{user_id}</code>\n👤 Юзернейм: {username}\n{status_line}\n💬 Осталось сообщений: {messages_left}\n📨 Всего отправлено сообщений: {total_sent}\n📅 Дата регистрации: {joined_at}',
        'zh': 'ℹ️ <b>您的账户信息</b>\n\n🆔 ID:<code>{user_id}</code>\n👤 用户名:{username}\n{status_line}\n💬 剩余消息数:{messages_left}\n📨 已发送消息总数:{total_sent}\n📅 加入日期:{joined_at}',
        'fa': 'ℹ️ <b>اطلاعات حساب شما</b>\n\n🆔 آیدی: <code>{user_id}</code>\n👤 یوزرنیم: {username}\n{status_line}\n💬 پیام‌های باقی‌مانده: {messages_left}\n📨 مجموع پیام‌های ارسالی: {total_sent}\n📅 تاریخ عضویت: {joined_at}',
    },

    'btn_stars_subscribe': {
        'ar': '⭐ اشتراك عبر نجوم تلجرام', 'en': '⭐ Subscribe via Telegram Stars',
        'ru': '⭐ Подписка через Telegram Stars', 'zh': '⭐ 通过 Telegram Stars 订阅',
        'fa': '⭐ اشتراک از طریق استارز تلگرام',
    },
    # ===== تحليل الصور (V2) =====
    'photo_v2_only': {
        'ar': '📸 <b>ميزة تحليل الصور متاحة لـ V2 فقط</b>\n\nقم بالتبديل إلى WORMGPT-V2 لاستخدام هذه الميزة.',
        'en': '📸 <b>Image analysis is a V2 exclusive feature</b>\n\nSwitch to WORMGPT-V2 to use this feature.',
        'ru': '📸 <b>Анализ изображений доступен только для V2</b>\n\nПереключитесь на WORMGPT-V2 для использования.',
        'zh': '📸 <b>图像分析是V2专属功能</b>\n\n切换到WORMGPT-V2以使用此功能。',
        'fa': '📸 <b>تحلیل تصویر فقط برای V2 موجود است</b>\n\nبرای استفاده به WORMGPT-V2 بروید.',
    },
    'photo_ask_analyze': {
        'ar': '📸 <b>تم استلام الصورة</b>\n\nهل تريد <b>وصف وتحليل</b> هذه الصورة؟',
        'en': '📸 <b>Photo received</b>\n\nWould you like a <b>description and analysis</b> of this image?',
        'ru': '📸 <b>Фото получено</b>\n\nХотите получить <b>описание и анализ</b> этого изображения?',
        'zh': '📸 <b>已收到图片</b>\n\n是否需要对此图片进行<b>描述和分析</b>？',
        'fa': '📸 <b>تصویر دریافت شد</b>\n\nآیا می‌خواهید <b>توصیف و تحلیل</b> این تصویر را دریافت کنید؟',
    },
    'photo_analyzing': {
        'ar': '🔍 جاري تحليل الصورة...',
        'en': '🔍 Analyzing image...',
        'ru': '🔍 Анализирую изображение...',
        'zh': '🔍 正在分析图片...',
        'fa': '🔍 در حال تحلیل تصویر...',
    },
    'photo_analyze_error': {
        'ar': '❌ تعذّر تحليل الصورة، يرجى المحاولة مرة أخرى.',
        'en': '❌ Could not analyze the image, please try again.',
        'ru': '❌ Не удалось проанализировать изображение, попробуйте снова.',
        'zh': '❌ 无法分析图片，请重试。',
        'fa': '❌ تحلیل تصویر امکان‌پذیر نیست، دوباره تلاش کنید.',
    },
    'btn_analyze_yes': {
        'ar': '✅ نعم، حلّل', 'en': '✅ Yes, analyze',
        'ru': '✅ Да, анализировать', 'zh': '✅ 是，分析', 'fa': '✅ بله، تحلیل کن',
    },
    'btn_analyze_no': {
        'ar': '❌ لا، شكراً', 'en': '❌ No, thanks',
        'ru': '❌ Нет, спасибо', 'zh': '❌ 不用了', 'fa': '❌ نه، ممنون',
    },
    # ===== وصف الصورة (بعد الضغط على "لا شكراً") =====
    'photo_description_prompt': {
        'ar': '📝 <b>أرسل الوصف أو السؤال الذي تريد إرساله مع الصورة:</b>\n\n💡 اكتب ما تريد أن يقوم الذكاء الاصطناعي بتحليله في الصورة.',
        'en': '📝 <b>Send the description or question you want to send with the image:</b>\n\n💡 Write what you want the AI to analyze in the image.',
        'ru': '📝 <b>Отправьте описание или вопрос, который вы хотите отправить вместе с изображением:</b>\n\n💡 Напишите, что вы хотите, чтобы ИИ проанализировал на изображении.',
        'zh': '📝 <b>发送您想要与图片一起发送的描述或问题：</b>\n\n💡 写下您希望AI分析图片中的内容。',
        'fa': '📝 <b>توضیح یا سوالی که می‌خواهید همراه با تصویر ارسال کنید را بنویسید:</b>\n\n💡 بنویسید چه چیزی می‌خواهید هوش مصنوعی در تصویر تحلیل کند.',
    },
    'btn_cancel_photo_description': {
        'ar': '❌ إلغاء', 'en': '❌ Cancel',
        'ru': '❌ Отмена', 'zh': '❌ 取消', 'fa': '❌ لغو',
    },
    'photo_ask_description_toast': {
        'ar': '✏️ أرسل وصفاً أو سؤالاً للصورة',
        'en': '✏️ Send a description or question for the image',
        'ru': '✏️ Отправьте описание или вопрос для изображения',
        'zh': '✏️ 发送图片的描述或问题',
        'fa': '✏️ یک توضیح یا سوال برای تصویر ارسال کنید',
    },
    'photo_description_cancelled_toast': {
        'ar': '✅ تم الإلغاء',
        'en': '✅ Cancelled',
        'ru': '✅ Отменено', 'zh': '✅ 已取消', 'fa': '✅ لغو شد',
    },

    'btn_stars_week': {
        'ar': '📅 أسبوع — 10 ⭐', 'en': '📅 1 Week — 10 ⭐', 'ru': '📅 1 неделя — 10 ⭐',
        'zh': '📅 1周 — 10 ⭐', 'fa': '📅 ۱ هفته — ۱۰ ⭐',
    },
    'btn_stars_2weeks': {
        'ar': '📅 أسبوعين — 20 ⭐', 'en': '📅 2 Weeks — 20 ⭐', 'ru': '📅 2 недели — 20 ⭐',
        'zh': '📅 2周 — 20 ⭐', 'fa': '📅 ۲ هفته — ۲۰ ⭐',
    },
    'btn_stars_3weeks': {
        'ar': '📅 3 أسابيع — 30 ⭐', 'en': '📅 3 Weeks — 30 ⭐', 'ru': '📅 3 недели — 30 ⭐',
        'zh': '📅 3周 — 30 ⭐', 'fa': '📅 ۳ هفته — ۳۰ ⭐',
    },
    'stars_picker_prompt': {
        'ar': '⭐ <b>اشتراك VIP عبر نجوم تلجرام</b>\n\nاختر مدة الاشتراك:',
        'en': '⭐ <b>VIP Subscription via Telegram Stars</b>\n\nChoose a subscription duration:',
        'ru': '⭐ <b>VIP-подписка через Telegram Stars</b>\n\nВыберите длительность подписки:',
        'zh': '⭐ <b>通过 Telegram Stars 订阅 VIP</b>\n\n请选择订阅时长:',
        'fa': '⭐ <b>اشتراک VIP از طریق استارز تلگرام</b>\n\nمدت اشتراک را انتخاب کنید:',
    },
    'invoice_title': {
        'ar': 'اشتراك VIP - {duration}', 'en': 'VIP Subscription - {duration}',
        'ru': 'VIP-подписка - {duration}', 'zh': 'VIP 订阅 - {duration}', 'fa': 'اشتراک VIP - {duration}',
    },
    'invoice_description': {
        'ar': 'دردشة بدون حدود وبدون وقت انتظار لمدة {duration}',
        'en': 'Unlimited, wait-free chat for {duration}',
        'ru': 'Безлимитный чат без ожидания на {duration}',
        'zh': '{duration}内畅聊无限制、无需等待',
        'fa': 'گفتگوی بدون محدودیت و بدون انتظار به مدت {duration}',
    },
    'vip_payment_welcome': {
        'ar': '🎉 <b>تم تفعيل اشتراك VIP بنجاح!</b>\n\nشكراً لدعمك 💎\nأصبحت الآن عضو VIP، يمكنك الدردشة بدون أي حدود وبدون وقت انتظار ⚡\n\n📅 ينتهي اشتراكك في: {expiry}\n\n✨ استمتع بتجربة أسرع وأولوية أعلى في الردود!',
        'en': '🎉 <b>Your VIP subscription is now active!</b>\n\nThank you for your support 💎\nYou are now a VIP member — chat with no limits and no waiting time ⚡\n\n📅 Your subscription ends on: {expiry}\n\n✨ Enjoy a faster experience with higher priority responses!',
        'ru': '🎉 <b>Ваша VIP-подписка активирована!</b>\n\nБлагодарим за поддержку 💎\nТеперь вы VIP-участник — общайтесь без ограничений и без ожидания ⚡\n\n📅 Подписка действует до: {expiry}\n\n✨ Наслаждайтесь более быстрыми и приоритетными ответами!',
        'zh': '🎉 <b>您的 VIP 订阅已激活!</b>\n\n感谢您的支持 💎\n您现在是 VIP 会员 —— 畅聊无限制、无需等待 ⚡\n\n📅 订阅有效期至:{expiry}\n\n✨ 尽享更快速、更高优先级的回复体验!',
        'fa': '🎉 <b>اشتراک VIP شما با موفقیت فعال شد!</b>\n\nبا تشکر از حمایت شما 💎\nاکنون عضو VIP هستید — بدون هیچ محدودیت و بدون زمان انتظار گفتگو کنید ⚡\n\n📅 اشتراک شما تا {expiry} معتبر است\n\n✨ از پاسخ‌هایی سریع‌تر و با اولویت بالاتر لذت ببرید!',
    },

    'support_prompt': {
        'ar': '📩 <b>تواصل مع الدعم</b>\n\nأرسل رسالتك (نص)، أو صورة، أو فيديو.\nيمكنك إضافة نص مع الصورة أو الفيديو كتعليق.',
        'en': '📩 <b>Contact Support</b>\n\nSend your message (text), a photo, or a video.\nYou can add text together with a photo or video as a caption.',
        'ru': '📩 <b>Связь с поддержкой</b>\n\nОтправьте ваше сообщение (текст), фото или видео.\nВы можете добавить текст к фото или видео в виде подписи.',
        'zh': '📩 <b>联系客服</b>\n\n请发送您的消息(文字)、图片或视频。\n您可以在图片或视频中添加文字作为说明。',
        'fa': '📩 <b>ارتباط با پشتیبانی</b>\n\nپیام خود را (متن)، یک عکس یا یک ویدیو ارسال کنید.\nمی‌توانید متن را همراه با عکس یا ویدیو به‌عنوان توضیح اضافه کنید.',
    },
    'support_invalid': {
        'ar': '⚠️ يرجى إرسال نص أو صورة أو فيديو.',
        'en': '⚠️ Please send text, a photo, or a video.',
        'ru': '⚠️ Пожалуйста, отправьте текст, фото или видео.',
        'zh': '⚠️ 请发送文字、图片或视频。',
        'fa': '⚠️ لطفاً متن، عکس یا ویدیو ارسال کنید.',
    },
    'support_sent_confirmation': {
        'ar': '✅ <b>تم إرسال رسالتك إلى الدعم بنجاح!</b>\nسيتم الرد عليك في أقرب وقت ممكن 🙏',
        'en': '✅ <b>Your message has been sent to support!</b>\nWe will get back to you as soon as possible 🙏',
        'ru': '✅ <b>Ваше сообщение отправлено в поддержку!</b>\nМы ответим вам как можно скорее 🙏',
        'zh': '✅ <b>您的消息已发送给客服!</b>\n我们会尽快回复您 🙏',
        'fa': '✅ <b>پیام شما برای پشتیبانی ارسال شد!</b>\nدر اسرع وقت پاسخ داده خواهد شد 🙏',
    },
    'support_reply_header': {
        'ar': '📩 <b>رد من فريق الدعم:</b>',
        'en': '📩 <b>Reply from the support team:</b>',
        'ru': '📩 <b>Ответ от службы поддержки:</b>',
        'zh': '📩 <b>客服团队回复:</b>',
        'fa': '📩 <b>پاسخ از تیم پشتیبانی:</b>',
    },

    'language_picker_prompt': {
        'ar': '🌐 <b>اختر لغتك المفضلة:</b>',
        'en': '🌐 <b>Choose your preferred language:</b>',
        'ru': '🌐 <b>Выберите предпочитаемый язык:</b>',
        'zh': '🌐 <b>请选择您的首选语言:</b>',
        'fa': '🌐 <b>زبان مورد نظر خود را انتخاب کنید:</b>',
    },
    'language_set_confirmation': {
        'ar': '✅ تم تغيير اللغة إلى {flag} {lang_name}',
        'en': '✅ Language changed to {flag} {lang_name}',
        'ru': '✅ Язык изменён на {flag} {lang_name}',
        'zh': '✅ 语言已更改为 {flag} {lang_name}',
        'fa': '✅ زبان به {flag} {lang_name} تغییر یافت',
    },

    'developer_text': {
        'ar': '**👨‍💻 المطور**\n\n🌑 **الاسم:** {name}\n📱 **اليوزر:** {owner}\n📢 **القناة:** {channel}\n📅 **الإصدار:** V2\n\n💀 **وورم جي بي تي - غير مقيد بالكامل**\n*لا قيود - لا رقابة - يفعل أي شيء*\n\n📧 **للتواصل:** {owner}',
        'en': '**👨‍💻 Developer**\n\n🌑 **Name:** {name}\n📱 **Username:** {owner}\n📢 **Channel:** {channel}\n📅 **Version:** V2\n\n💀 **WormGPT - Fully Unrestricted**\n*No limits - No censorship - Does anything*\n\n📧 **Contact:** {owner}',
        'ru': '**👨‍💻 Разработчик**\n\n🌑 **Имя:** {name}\n📱 **Юзернейм:** {owner}\n📢 **Канал:** {channel}\n📅 **Версия:** V2\n\n💀 **WormGPT - Полностью без ограничений**\n*Без ограничений - без цензуры - делает что угодно*\n\n📧 **Связь:** {owner}',
        'zh': '**👨‍💻 开发者**\n\n🌑 **名称:** {name}\n📱 **用户名:** {owner}\n📢 **频道:** {channel}\n📅 **版本:** V2\n\n💀 **WormGPT - 完全无限制**\n*无限制 - 无审查 - 无所不能*\n\n📧 **联系方式:** {owner}',
        'fa': '**👨‍💻 توسعه‌دهنده**\n\n🌑 **نام:** {name}\n📱 **یوزرنیم:** {owner}\n📢 **کانال:** {channel}\n📅 **نسخه:** V2\n\n💀 **WormGPT - کاملاً بدون محدودیت**\n*بدون محدودیت - بدون سانسور - هر کاری انجام می‌دهد*\n\n📧 **تماس:** {owner}',
    },

    'info_text': {
        'ar': '**📱 معلومات البوت**\n\n👤 **الاسم:** وورم جي بي تي\n👨‍💻 **المطور:** {owner}\n📢 **القناة:** {channel}\n📅 **الإصدار:** V2\n\n**⚙️ المميزات:**\n• ✅ ذاكرة قوية (10رسالة)\n• ✅ فهم سياق المحادثة\n• ✅ بحث مدمج ذكي\n• ✅ توليد أكواد مع ملفات\n• ✅ كود صغير يظهر مباشرة\n• ✅ كود كبير يحفظ كملف\n• ✅ تنسيق أكواد جميل\n• ✅ دعم الرسائل الطويلة\n• ✨ كتابة تدريجية فائقة السرعة\n• 🌟 اشتراك VIP بدون حدود\n\n**📝 الأوامر:**\n/start - بدء البوت\n/clear - مسح المحادثة\n/info - هذه القائمة\n/language - تغيير اللغة\n\n🚀 **الحالة:** شغال 24/7',
        'en': '**📱 Bot Info**\n\n👤 **Name:** WormGPT\n👨‍💻 **Developer:** {owner}\n📢 **Channel:** {channel}\n📅 **Version:** V2\n\n**⚙️ Features:**\n• ✅ Strong memory (10 messages)\n• ✅ Conversation context understanding\n• ✅ Smart built-in search\n• ✅ Code generation with files\n• ✅ Small code shown directly\n• ✅ Large code saved as a file\n• ✅ Clean code formatting\n• ✅ Long message support\n• ✨ Ultra-fast progressive typing\n• 🌟 Unlimited VIP subscription\n\n**📝 Commands:**\n/start - Start the bot\n/clear - Clear the conversation\n/info - This menu\n/language - Change language\n\n🚀 **Status:** Running 24/7',
        'ru': '**📱 Информация о боте**\n\n👤 **Имя:** WormGPT\n👨‍💻 **Разработчик:** {owner}\n📢 **Канал:** {channel}\n📅 **Версия:** V2\n\n**⚙️ Возможности:**\n• ✅ Хорошая память (10 сообщений)\n• ✅ Понимание контекста разговора\n• ✅ Встроенный умный поиск\n• ✅ Генерация кода с файлами\n• ✅ Маленький код отображается сразу\n• ✅ Большой код сохраняется в файл\n• ✅ Красивое оформление кода\n• ✅ Поддержка длинных сообщений\n• ✨ Сверхбыстрая постепенная печать\n• 🌟 VIP-подписка без ограничений\n\n**📝 Команды:**\n/start - Запустить бота\n/clear - Очистить разговор\n/info - Это меню\n/language - Изменить язык\n\n🚀 **Статус:** Работает 24/7',
        'zh': '**📱 机器人信息**\n\n👤 **名称:** WormGPT\n👨‍💻 **开发者:** {owner}\n📢 **频道:** {channel}\n📅 **版本:** V2\n\n**⚙️ 功能:**\n• ✅ 强大的记忆功能(10条消息)\n• ✅ 理解对话上下文\n• ✅ 智能内置搜索\n• ✅ 生成代码并提供文件\n• ✅ 小代码直接显示\n• ✅ 大代码保存为文件\n• ✅ 美观的代码格式\n• ✅ 支持长消息\n• ✨ 超快速逐步输入效果\n• 🌟 无限制 VIP 订阅\n\n**📝 命令:**\n/start - 启动机器人\n/clear - 清除对话\n/info - 此菜单\n/language - 更改语言\n\n🚀 **状态:** 24/7 运行中',
        'fa': '**📱 اطلاعات بات**\n\n👤 **نام:** WormGPT\n👨‍💻 **توسعه‌دهنده:** {owner}\n📢 **کانال:** {channel}\n📅 **نسخه:** V2\n\n**⚙️ ویژگی‌ها:**\n• ✅ حافظه قوی (۱۰ پیام)\n• ✅ درک زمینه گفتگو\n• ✅ جستجوی هوشمند داخلی\n• ✅ تولید کد همراه با فایل\n• ✅ کد کوچک مستقیماً نمایش داده می‌شود\n• ✅ کد بزرگ به‌صورت فایل ذخیره می‌شود\n• ✅ قالب‌بندی زیبای کد\n• ✅ پشتیبانی از پیام‌های طولانی\n• ✨ نگارش تدریجی فوق‌سریع\n• 🌟 اشتراک VIP بدون محدودیت\n\n**📝 دستورات:**\n/start - شروع بات\n/clear - پاک کردن گفتگو\n/info - این منو\n/language - تغییر زبان\n\n🚀 **وضعیت:** فعال ۲۴/۷',
    },

    # ===== رسالة الانتظار =====
    'wait_processing': {
        'ar': '⏳ <b>جاري المعالجة...</b>\n\nيعمل الذكاء الاصطناعي على إجابتك، يرجى الانتظار.',
        'en': '⏳ <b>Processing...</b>\n\nAI is working on your answer, please wait.',
        'ru': '⏳ <b>Обработка...</b>\n\nИИ работает над вашим ответом, подождите.',
        'zh': '⏳ <b>处理中...</b>\n\nAI正在处理您的问题，请稍候。',
        'fa': '⏳ <b>در حال پردازش...</b>\n\nهوش مصنوعی در حال آماده‌سازی پاسخ است، لطفاً صبر کنید.',
    },
    'btn_subscribe_wait': {
        'ar': '💎 اشتراك', 'en': '💎 Subscribe', 'ru': '💎 Подписка',
        'zh': '💎 订阅', 'fa': '💎 اشتراک',
    },

    # ===== نظام النماذج =====
    # ===== قائمة نماذج البحث (Research Models) =====
    'research_models_prompt': {
        'ar': '🧪 <b>نماذج البحث</b>\n\nاختر النموذج المطلوب:\n\n<b>WORMGPT-research-V1</b> — بحث نصي عبر DuckDuckGo (متاح للجميع)\n<b>WORMGPT-research-V2</b> — بحث عميق + صور + سياق 20 (للمشتركين VIP والأدمن فقط)',
        'en': '🧪 <b>Research Models</b>\n\nChoose your model:\n\n<b>WORMGPT-research-V1</b> — Text search via DuckDuckGo (available for everyone)\n<b>WORMGPT-research-V2</b> — Deep search + images + 20-msg context (VIP/Admin only)',
        'ru': '🧪 <b>Модели поиска</b>\n\nВыберите модель:\n\n<b>WORMGPT-research-V1</b> — текстовый поиск через DuckDuckGo (доступно всем)\n<b>WORMGPT-research-V2</b> — глубокий поиск + изображения + контекст 20 (только VIP/Админ)',
        'zh': '🧪 <b>搜索模型</b>\n\n请选择您的模型:\n\n<b>WORMGPT-research-V1</b> — 通过DuckDuckGo进行文本搜索(所有人都可用)\n<b>WORMGPT-research-V2</b> — 深度搜索+图片+20条上下文(仅限 VIP/管理员)',
        'fa': '🧪 <b>مدل‌های جستجو</b>\n\nمدل مورد نظر را انتخاب کنید:\n\n<b>WORMGPT-research-V1</b> — جستجوی متنی از طریق DuckDuckGo (برای همه در دسترس)\n<b>WORMGPT-research-V2</b> — جستجوی عمیق + تصاویر + ۲۰ پیام زمینه (فقط VIP/مدیر)',
    },
    'model_research_v1_label': {
        'ar': '⚡ WORMGPT-research-V1 {active}',
        'en': '⚡ WORMGPT-research-V1 {active}',
        'ru': '⚡ WORMGPT-research-V1 {active}',
        'zh': '⚡ WORMGPT-research-V1 {active}',
        'fa': '⚡ WORMGPT-research-V1 {active}',
    },
    'model_research_v2_label': {
        'ar': '🔥 WORMGPT-research-V2 {active}',
        'en': '🔥 WORMGPT-research-V2 {active}',
        'ru': '🔥 WORMGPT-research-V2 {active}',
        'zh': '🔥 WORMGPT-research-V2 {active}',
        'fa': '🔥 WORMGPT-research-V2 {active}',
    },
    'research_model_v1_selected': {
        'ar': '✅ تم اختيار <b>WORMGPT-research-V1</b>\n\nسيتم البحث عبر DuckDuckGo عند الضغط على زر "بحث".',
        'en': '✅ <b>WORMGPT-research-V1</b> selected\n\nDuckDuckGo will be used when you press the Search button.',
        'ru': '✅ Выбрано <b>WORMGPT-research-V1</b>\n\nDuckDuckGo будет использоваться при нажатии кнопки «Поиск».',
        'zh': '✅ 已选择 <b>WORMGPT-research-V1</b>\n\n点击搜索按钮时将使用DuckDuckGo。',
        'fa': '✅ <b>WORMGPT-research-V1</b> انتخاب شد\n\nهنگام فشردن دکمه جستجو از DuckDuckGo استفاده خواهد شد.',
    },
    'research_model_v2_selected': {
        'ar': '✅ تم اختيار <b>WORMGPT-research-V2</b>\n\nيمكنك الآن إرسال نص أو صورة مع نص للبحث العميق.',
        'en': '✅ <b>WORMGPT-research-V2</b> selected\n\nYou can now send text or image with text for deep search.',
        'ru': '✅ Выбрано <b>WORMGPT-research-V2</b>\n\nТеперь вы можете отправлять текст или изображение с текстом для глубокого поиска.',
        'zh': '✅ 已选择 <b>WORMGPT-research-V2</b>\n\n现在您可以发送文本或带文本的图片进行深度搜索。',
        'fa': '✅ <b>WORMGPT-research-V2</b> انتخاب شد\n\nاکنون می‌توانید متن یا تصویر با متن را برای جستجوی عمیق ارسال کنید.',
    },
    'research_v2_vip_only': {
        'ar': '🔒 <b>WORMGPT-research-V2</b> متاح فقط للمشتركين VIP والأدمن.',
        'en': '🔒 <b>WORMGPT-research-V2</b> is available for VIP subscribers and admins only.',
        'ru': '🔒 <b>WORMGPT-research-V2</b> доступен только VIP-подписчикам и администраторам.',
        'zh': '🔒 <b>WORMGPT-research-V2</b> 仅对付费VIP订阅者和管理员开放。',
        'fa': '🔒 <b>WORMGPT-research-V2</b> فقط برای مشترکین VIP و مدیران در دسترس است.',
    },
    'btn_switch_model': {
        'ar': '🤖 تغيير النموذج', 'en': '🤖 Switch Model', 'ru': '🤖 Сменить модель',
        'zh': '🤖 切换模型', 'fa': '🤖 تغییر مدل',
    },
    'model_switch_prompt': {
        'ar': '🤖 <b>اختر النموذج المطلوب:</b>\n\n<b>WORMGPT-V1</b> — النموذج الأساسي (مجاني)\n<b>WORMGPT-V2</b> — النموذج المتقدم (مدفوع • 4 رسائل يومية مجانية)',
        'en': '🤖 <b>Choose your model:</b>\n\n<b>WORMGPT-V1</b> — Basic model (free)\n<b>WORMGPT-V2</b> — Advanced model (paid • 4 free daily messages)',
        'ru': '🤖 <b>Выберите модель:</b>\n\n<b>WORMGPT-V1</b> — Базовая модель (бесплатно)\n<b>WORMGPT-V2</b> — Расширенная модель (платно • 4 ежедневных сообщения)',
        'zh': '🤖 <b>选择模型:</b>\n\n<b>WORMGPT-V1</b> — 基础模型 (免费)\n<b>WORMGPT-V2</b> — 高级模型 (付费 • 每日4条免费消息)',
        'fa': '🤖 <b>مدل مورد نظر را انتخاب کنید:</b>\n\n<b>WORMGPT-V1</b> — مدل پایه (رایگان)\n<b>WORMGPT-V2</b> — مدل پیشرفته (پولی • ۴ پیام رایگان روزانه)',
    },
    'model_v1_label': {
        'ar': '⚡ WORMGPT-V1 {active}', 'en': '⚡ WORMGPT-V1 {active}',
        'ru': '⚡ WORMGPT-V1 {active}', 'zh': '⚡ WORMGPT-V1 {active}', 'fa': '⚡ WORMGPT-V1 {active}',
    },
    'model_v2_label': {
        'ar': '🔥 WORMGPT-V2 {active}', 'en': '🔥 WORMGPT-V2 {active}',
        'ru': '🔥 WORMGPT-V2 {active}', 'zh': '🔥 WORMGPT-V2 {active}', 'fa': '🔥 WORMGPT-V2 {active}',
    },
    'model_switched_v1': {
        'ar': '✅ تم التبديل إلى <b>WORMGPT-V1</b> (النموذج الأساسي)',
        'en': '✅ Switched to <b>WORMGPT-V1</b> (Basic model)',
        'ru': '✅ Переключено на <b>WORMGPT-V1</b> (базовая модель)',
        'zh': '✅ 已切换到 <b>WORMGPT-V1</b> (基础模型)',
        'fa': '✅ به <b>WORMGPT-V1</b> (مدل پایه) تغییر یافت',
    },
    'model_switched_v2': {
        'ar': '✅ تم التبديل إلى <b>WORMGPT-V2</b> (النموذج المتقدم)\n\n🔥 متبقي لك اليوم: <b>{trials}</b> رسالة',
        'en': '✅ Switched to <b>WORMGPT-V2</b> (Advanced model)\n\n🔥 You have <b>{trials}</b> daily messages left',
        'ru': '✅ Переключено на <b>WORMGPT-V2</b> (расширенная модель)\n\n🔥 Осталось пробных сообщений: <b>{trials}</b>',
        'zh': '✅ 已切换到 <b>WORMGPT-V2</b> (高级模型)\n\n🔥 剩余免费试用消息: <b>{trials}</b>',
        'fa': '✅ به <b>WORMGPT-V2</b> (مدل پیشرفته) تغییر یافت\n\n🔥 پیام‌های آزمایشی باقیمانده: <b>{trials}</b>',
    },
    'v2_trial_exhausted': {
        'ar': '🔒 <b>انتهت رسائل V2 اليومية</b>\n\nتُجدَّد غداً تلقائياً، أو اشترك في VIP للحصول على وصول كامل وغير محدود.',
        'en': '🔒 <b>WORMGPT-V2 free trial messages exhausted</b>\n\nSubscribe to VIP for full unlimited access to the advanced model.',
        'ru': '🔒 <b>Пробные сообщения WORMGPT-V2 исчерпаны</b>\n\nОформите VIP-подписку для полного неограниченного доступа к расширенной модели.',
        'zh': '🔒 <b>WORMGPT-V2免费试用消息已用完</b>\n\n订阅VIP以获得高级模型的完整无限访问权限。',
        'fa': '🔒 <b>پیام‌های آزمایشی رایگان WORMGPT-V2 تمام شد</b>\n\nبرای دسترسی کامل و نامحدود به مدل پیشرفته، اشتراک VIP تهیه کنید.',
    },
    'v2_trial_remaining': {
        'ar': '🔥 <b>WORMGPT-V2</b> — متبقي لك اليوم <b>{trials}</b> رسالة',
        'en': '🔥 <b>WORMGPT-V2</b> — <b>{trials}</b> free trial messages left',
        'ru': '🔥 <b>WORMGPT-V2</b> — осталось <b>{trials}</b> пробных сообщений',
        'zh': '🔥 <b>WORMGPT-V2</b> — 剩余 <b>{trials}</b> 条试用消息',
        'fa': '🔥 <b>WORMGPT-V2</b> — <b>{trials}</b> پیام آزمایشی باقیمانده',
    },

    # ===== أخطاء عامة وردود اتصال =====
    'err_connection': {
        'ar': '❌ خطأ في الاتصال، يرجى المحاولة مرة أخرى',
        'en': '❌ Connection error, please try again',
        'ru': '❌ Ошибка соединения, попробуйте ещё раз',
        'zh': '❌ 连接错误，请重试',
        'fa': '❌ خطای اتصال، لطفاً دوباره تلاش کنید',
    },
    # ===== نظام التبديل التلقائي V2 → V1 =====
    'v2_balance_exhausted': {
        'ar': '⚠️ <b>خدمة V2 أصبحت غير متاحة حالياً</b>\n\nيبدو أن رصيدك في V2 قد انتهى أو تم تجاوز الحد المسموح به.\n\n✅ تم التحويل تلقائياً إلى نموذج <b>V1</b> — جاري معالجة طلبك...',
        'en': '⚠️ <b>V2 service is currently unavailable</b>\n\nIt looks like your V2 balance has run out or the daily limit has been exceeded.\n\n✅ Automatically switched to the <b>V1</b> model — processing your request...',
        'ru': '⚠️ <b>Сервис V2 сейчас недоступен</b>\n\nПохоже, ваш баланс V2 закончился или превышен дневной лимит.\n\n✅ Автоматически переключено на модель <b>V1</b> — обрабатываю ваш запрос...',
        'zh': '⚠️ <b>V2 服务当前不可用</b>\n\n您的 V2 余额似乎已用完或已达到每日限额。\n\n✅ 已自动切换到 <b>V1</b> 模型 — 正在处理您的请求...',
        'fa': '⚠️ <b>سرویس V2 در حال حاضر در دسترس نیست</b>\n\nبه نظر می‌رسد اعتبار V2 شما تمام شده یا از سقف روزانه فراتر رفته‌اید.\n\n✅ به‌صورت خودکار به مدل <b>V1</b> سوئیچ شد — در حال پردازش درخواست شما...',
    },
    'retry_state_lost': {
        'ar': '⌛ انتهت صلاحية آخر طلب. يرجى إعادة إرسال رسالتك للمعالجة.',
        'en': '⌛ Last request has expired. Please resend your message to process it.',
        'ru': '⌛ Срок последнего запроса истёк. Пожалуйста, отправьте сообщение ещё раз.',
        'zh': '⌛ 上一个请求已过期。请重新发送您的消息以进行处理。',
        'fa': '⌛ درخواست آخر منقضی شد. لطفاً پیام خود را برای پردازش مجدد ارسال کنید.',
    },
    'err_not_admin': {
        'ar': '❌ انت لست ادمن!',
        'en': '❌ You are not an admin!',
        'ru': '❌ Вы не администратор!',
        'zh': '❌ 您不是管理员！',
        'fa': '❌ شما ادمین نیستید!',
    },
    'admin_panel_title': {
        'ar': '👑 <b>لوحة التحكم</b>',
        'en': '👑 <b>Admin Panel</b>',
        'ru': '👑 <b>Панель администратора</b>',
        'zh': '👑 <b>管理面板</b>',
        'fa': '👑 <b>پنل مدیریت</b>',
    },
    'admin_cancel_text': {
        'ar': '❌ <b>تم الإلغاء</b>\n\n👑 لوحة التحكم',
        'en': '❌ <b>Cancelled</b>\n\n👑 Admin Panel',
        'ru': '❌ <b>Отменено</b>\n\n👑 Панель администратора',
        'zh': '❌ <b>已取消</b>\n\n👑 管理面板',
        'fa': '❌ <b>لغو شد</b>\n\n👑 پنل مدیریت',
    },
    'admin_action_retry_msg': {
        'ar': '🔄 أعد إرسال رسالتك وسيتم معالجتها فوراً',
        'en': '🔄 Resend your message and it will be processed immediately',
        'ru': '🔄 Отправьте сообщение ещё раз, и оно будет обработано немедленно',
        'zh': '🔄 重新发送您的消息，将立即处理',
        'fa': '🔄 پیام خود را دوباره ارسال کنید، فوراً پردازش می‌شود',
    },

    # ===== نظام الإحالة =====
    'btn_referral_link': {
        'ar': '🔗 رابط الإحالة', 'en': '🔗 Referral Link', 'ru': '🔗 Реферальная ссылка',
        'zh': '🔗 推荐链接', 'fa': '🔗 لینک معرفی',
    },
    'referral_panel': {
        'ar': '🔗 <b>رابط الإحالة الخاص بك</b>\n\n<code>{ref_link}</code>\n\n👥 <b>عدد من انضموا:</b> {ref_count} شخص\n🎁 <b>رصيد V2 الإضافي:</b> +{ref_bonus} رسالة/يوم\n\n📌 شارك الرابط — كل شخص ينضم يُضيف لك <b>+2 رسالة V2 يومية</b> مجاناً!',
        'en': '🔗 <b>Your Referral Link</b>\n\n<code>{ref_link}</code>\n\n👥 <b>People joined:</b> {ref_count}\n🎁 <b>Extra V2 quota:</b> +{ref_bonus} msg/day\n\n📌 Share the link — every new joiner adds <b>+2 V2 daily messages</b> to your account for free!',
        'ru': '🔗 <b>Ваша реферальная ссылка</b>\n\n<code>{ref_link}</code>\n\n👥 <b>Присоединились:</b> {ref_count} чел.\n🎁 <b>Доп. квота V2:</b> +{ref_bonus} соообщ./день\n\n📌 Поделитесь ссылкой — каждый новый участник добавляет вам <b>+2 сообщения V2 в день</b> бесплатно!',
        'zh': '🔗 <b>您的推荐链接</b>\n\n<code>{ref_link}</code>\n\n👥 <b>已加入人数:</b> {ref_count} 人\n🎁 <b>额外的 V2 配额:</b> 每天 +{ref_bonus} 条消息\n\n📌 分享链接 — 每位新加入者将为您免费增加 <b>每天 +2 条 V2 消息</b>！',
        'fa': '🔗 <b>لینک معرفی شما</b>\n\n<code>{ref_link}</code>\n\n👥 <b>تعداد عضو شده‌ها:</b> {ref_count} نفر\n🎁 <b>سهمیه اضافی V2:</b> +{ref_bonus} پیام در روز\n\n📌 لینک را به اشتراک بگذارید — هر عضو جدید <b>+۲ پیام V2 روزانه</b> به حساب شما اضافه می‌کند!',
    },
    'referral_join_thanks': {
        'ar': '🎉 انضم شخص جديد عبر رابط إحالتك!\n+2 رسالة V2 يومية أُضيفت لرصيدك.',
        'en': '🎉 Someone new joined via your referral link!\n+2 daily V2 messages added to your balance.',
        'ru': '🎉 Новый человек присоединился по вашей реферальной ссылке!\n+2 ежедневных сообщения V2 добавлено на ваш баланс.',
        'zh': '🎉 有人通过您的推荐链接加入了！\n您的余额中已增加 +2 条每日 V2 消息。',
        'fa': '🎉 یک نفر جدید از طریق لینک معرفی شما عضو شد!\n+۲ پیام V2 روزانه به موجودی شما اضافه شد.',
    },
    'referral_toggle_text': {
        'ar': '🔗 <b>زر رابط الإحالة</b>\n\nالحالة الحالية: <b>{status}</b>\n\nعند التفعيل يظهر الزر الأحمر الشفاف في القائمة الرئيسية لجميع المستخدمين.',
        'en': '🔗 <b>Referral Link Button</b>\n\nCurrent state: <b>{status}</b>\n\nWhen enabled, the transparent red button appears in the main menu for all users.',
        'ru': '🔗 <b>Кнопка реферальной ссылки</b>\n\nТекущее состояние: <b>{status}</b>\n\nПри включении прозрачная красная кнопка появится в главном меню для всех пользователей.',
        'zh': '🔗 <b>推荐链接按钮</b>\n\n当前状态:<b>{status}</b>\n\n启用后，透明红色按钮将出现在所有用户的主菜单中。',
        'fa': '🔗 <b>دکمه لینک معرفی</b>\n\nوضعیت فعلی: <b>{status}</b>\n\nدر صورت فعال‌سازی، دکمه شفاف قرمز در منوی اصلی همه کاربران نمایش داده می‌شود.',
    },
    'referral_status_enabled': {
        'ar': '✅ مفعّل', 'en': '✅ Enabled', 'ru': '✅ Включено', 'zh': '✅ 已启用', 'fa': '✅ فعال',
    },
    'referral_status_disabled': {
        'ar': '❌ موقوف', 'en': '❌ Disabled', 'ru': '❌ Отключено', 'zh': '❌ 已禁用', 'fa': '❌ غیرفعال',
    },
    'btn_referral_enable': {
        'ar': '🔗 تفعيل زر الإحالة', 'en': '🔗 Enable Referral Button', 'ru': '🔗 Включить кнопку реферала',
        'zh': '🔗 启用推荐按钮', 'fa': '🔗 فعال‌سازی دکمه معرفی',
    },
    'btn_referral_disable': {
        'ar': '❌ إلغاء زر الإحالة', 'en': '❌ Disable Referral Button', 'ru': '❌ Отключить кнопку реферала',
        'zh': '❌ 禁用推荐按钮', 'fa': '❌ غیرفعال‌سازی دکمه معرفی',
    },

    # ===== إدارة القنوات (أدمن) =====
    'btn_add_channel': {
        'ar': '➕ اضافة قناة', 'en': '➕ Add Channel', 'ru': '➕ Добавить канал', 'zh': '➕ 添加频道', 'fa': '➕ افزودن کانال',
    },
    'btn_remove_channel': {
        'ar': '➖ حذف قناة', 'en': '➖ Remove Channel', 'ru': '➖ Удалить канал', 'zh': '➖ 移除频道', 'fa': '➖ حذف کانال',
    },
    'btn_show_channels': {
        'ar': '📋 قائمة القنوات', 'en': '📋 Channels List', 'ru': '📋 Список каналов',
        'zh': '📋 频道列表', 'fa': '📋 لیست کانال‌ها',
    },
    'btn_delete_all_channels': {
        'ar': '🗑️ حذف الكل', 'en': '🗑️ Delete All', 'ru': '🗑️ Удалить все', 'zh': '🗑️ 全部删除', 'fa': '🗑️ حذف همه',
    },
    'btn_broadcast': {
        'ar': '📢 إذاعة', 'en': '📢 Broadcast', 'ru': '📢 Рассылка', 'zh': '📢 广播', 'fa': '📢 پیام‌رسانی',
    },
    'btn_renew_messages': {
        'ar': '🔄 تجديد الرسائل', 'en': '🔄 Renew Messages', 'ru': '🔄 Продление сообщений',
        'zh': '🔄 续费消息', 'fa': '🔄 تمدید پیام',
    },
    'btn_vip_subscription_admin': {
        'ar': '🌟 اشتراك VIP', 'en': '🌟 VIP Subscription', 'ru': '🌟 VIP-подписка', 'zh': '🌟 VIP 订阅', 'fa': '🌟 اشتراک VIP',
    },
    'btn_vip_list': {
        'ar': '📋 قائمة VIP', 'en': '📋 VIP List', 'ru': '📋 Список VIP', 'zh': '📋 VIP 列表', 'fa': '📋 لیست VIP',
    },
    'btn_stats': {
        'ar': '📊 احصائيات', 'en': '📊 Statistics', 'ru': '📊 Статистика', 'zh': '📊 统计', 'fa': '📊 آمار',
    },
    'btn_maintenance_enable': {
        'ar': '🛠️ تفعيل وضع الصيانة', 'en': '🛠️ Enable Maintenance', 'ru': '🛠️ Включить обслуживание',
        'zh': '🛠️ 启用维护模式', 'fa': '🛠️ فعال‌سازی حالت تعمیر',
    },
    'btn_maintenance_disable': {
        'ar': '✅ إيقاف الصيانة (تشغيل البوت)', 'en': '✅ Disable Maintenance (Resume Bot)',
        'ru': '✅ Отключить обслуживание (запустить бота)',
        'zh': '✅ 关闭维护模式 (启动机器人)', 'fa': '✅ غیرفعال‌سازی تعمیر (روشن‌سازی ربات)',
    },
    'admin_add_channel_prompt': {
        'ar': '➕ <b>أرسل معرف القناة مع @ لإضافتها:</b>\nمثال: @channelname',
        'en': '➕ <b>Send the channel username with @ to add it:</b>\nExample: @channelname',
        'ru': '➕ <b>Отправьте имя канала с @ для добавления:</b>\nПример: @channelname',
        'zh': '➕ <b>发送带 @ 的频道用户名以添加:</b>\n例如: @channelname',
        'fa': '➕ <b>نام کاربری کانال را با @ ارسال کنید تا اضافه شود:</b>\nمثال: @channelname',
    },
    'admin_remove_channel_prompt': {
        'ar': '➖ <b>أرسل معرف القناة مع @ لحذفها:</b>',
        'en': '➖ <b>Send the channel username with @ to remove it:</b>',
        'ru': '➖ <b>Отправьте имя канала с @ для удаления:</b>',
        'zh': '➖ <b>发送带 @ 的频道用户名以移除:</b>',
        'fa': '➖ <b>نام کاربری کانال را با @ ارسال کنید تا حذف شود:</b>',
    },
    'admin_channel_added': {
        'ar': '✅ <b>تمت إضافة القناة:</b> {channel_name}',
        'en': '✅ <b>Channel added:</b> {channel_name}',
        'ru': '✅ <b>Канал добавлен:</b> {channel_name}',
        'zh': '✅ <b>已添加频道:</b> {channel_name}',
        'fa': '✅ <b>کانال اضافه شد:</b> {channel_name}',
    },
    'admin_channel_invite_failed': {
        'ar': '❌ <b>فشل في الحصول على رابط الدعوة</b>',
        'en': '❌ <b>Failed to obtain invite link</b>',
        'ru': '❌ <b>Не удалось получить ссылку-приглашение</b>',
        'zh': '❌ <b>无法获取邀请链接</b>',
        'fa': '❌ <b>دریافت لینک دعوت ناموفق بود</b>',
    },
    'admin_channel_not_found': {
        'ar': '❌ <b>القناة غير موجودة</b>',
        'en': '❌ <b>Channel does not exist</b>',
        'ru': '❌ <b>Канал не существует</b>',
        'zh': '❌ <b>频道不存在</b>',
        'fa': '❌ <b>کانال وجود ندارد</b>',
    },
    'admin_channel_removed': {
        'ar': '✅ <b>تم حذف القناة:</b> {channel_name}',
        'en': '✅ <b>Channel removed:</b> {channel_name}',
        'ru': '✅ <b>Канал удалён:</b> {channel_name}',
        'zh': '✅ <b>已移除频道:</b> {channel_name}',
        'fa': '✅ <b>کانال حذف شد:</b> {channel_name}',
    },
    'admin_channels_list_empty': {
        'ar': '❌ <b>لا توجد قنوات مسجلة</b>',
        'en': '❌ <b>No channels registered</b>',
        'ru': '❌ <b>Каналы не зарегистрированы</b>',
        'zh': '❌ <b>未注册任何频道</b>',
        'fa': '❌ <b>هیچ کانالی ثبت نشده است</b>',
    },
    'admin_channels_list_header': {
        'ar': '📋 <b>القنوات:</b>',
        'en': '📋 <b>Channels:</b>',
        'ru': '📋 <b>Каналы:</b>',
        'zh': '📋 <b>频道:</b>',
        'fa': '📋 <b>کانال‌ها:</b>',
    },
    'admin_channels_all_deleted': {
        'ar': '🗑️ <b>تم حذف جميع القنوات!</b>',
        'en': '🗑️ <b>All channels have been deleted!</b>',
        'ru': '🗑️ <b>Все каналы удалены!</b>',
        'zh': '🗑️ <b>已删除所有频道!</b>',
        'fa': '🗑️ <b>همه کانال‌ها حذف شدند!</b>',
    },
    'admin_action_generic_error': {
        'ar': '❌ <b>حدث خطأ، يرجى المحاولة مرة أخرى.</b>',
        'en': '❌ <b>An error occurred, please try again.</b>',
        'ru': '❌ <b>Произошла ошибка, попробуйте ещё раз.</b>',
        'zh': '❌ <b>发生错误，请重试。</b>',
        'fa': '❌ <b>خطایی رخ داد، لطفاً دوباره تلاش کنید.</b>',
    },

    # ===== الصيانة =====
    'maintenance_enabled_text': {
        'ar': '🛠️ <b>تم تفعيل وضع الصيانة</b>\n\nلن يتمكن المستخدمون (عدا الأدمن) من استخدام البوت حتى تقوم بإيقافه.',
        'en': '🛠️ <b>Maintenance mode enabled</b>\n\nUsers (except admins) will not be able to use the bot until you disable it.',
        'ru': '🛠️ <b>Режим обслуживания включён</b>\n\nПользователи (кроме админов) не смогут пользоваться ботом, пока вы его не отключите.',
        'zh': '🛠️ <b>已启用维护模式</b>\n\n在您关闭之前，用户(管理员除外)将无法使用机器人。',
        'fa': '🛠️ <b>حالت تعمیر فعال شد</b>\n\nکاربران (به‌جز ادمین) تا زمانی که آن را غیرفعال نکنید، نمی‌توانند از ربات استفاده کنند.',
    },
    'maintenance_disabled_text': {
        'ar': '✅ <b>تم إيقاف وضع الصيانة</b>\n\nالبوت يعمل الآن بشكل طبيعي لجميع المستخدمين.',
        'en': '✅ <b>Maintenance mode disabled</b>\n\nThe bot is now running normally for all users.',
        'ru': '✅ <b>Режим обслуживания отключён</b>\n\nБот теперь работает в обычном режиме для всех пользователей.',
        'zh': '✅ <b>已关闭维护模式</b>\n\n机器人现已为所有用户正常运行。',
        'fa': '✅ <b>حالت تعمیر غیرفعال شد</b>\n\nربات اکنون برای همه کاربران به‌طور عادی کار می‌کند.',
    },

    # ===== الإذاعة =====
    'broadcast_prompt': {
        'ar': '📢 <b>الإذاعة</b>\n\n📝 أرسل ما تريد إذاعته على المستخدمين: نص، صورة، فيديو، أو صورة/فيديو مع تعليق:',
        'en': '📢 <b>Broadcast</b>\n\n📝 Send what you want to broadcast to users: text, photo, video, or media with caption:',
        'ru': '📢 <b>Рассылка</b>\n\n📝 Отправьте, что вы хотите разослать: текст, фото, видео или медиа с подписью:',
        'zh': '📢 <b>广播</b>\n\n📝 发送您想广播给用户的内容:文字、图片、视频或带说明的媒体:',
        'fa': '📢 <b>پیام‌رسانی</b>\n\n📝 آنچه می‌خواهید برای کاربران ارسال کنید را بفرستید: متن، عکس، ویدیو یا رسانه با توضیح:',
    },
    'broadcast_invalid': {
        'ar': '⚠️ <b>لم يتم التعرف على محتوى صالح للإذاعة.</b>\nأرسل نص، صورة، أو فيديو (مع أو بدون تعليق):',
        'en': '⚠️ <b>No valid broadcast content was recognized.</b>\nSend text, a photo, or a video (with or without a caption):',
        'ru': '⚠️ <b>Не распознано допустимое содержимое для рассылки.</b>\nОтправьте текст, фото или видео (с подписью или без):',
        'zh': '⚠️ <b>未识别到有效的广播内容。</b>\n请发送文字、图片或视频(可带说明):',
        'fa': '⚠️ <b>محتوای معتبری برای پیام‌رسانی شناسایی نشد.</b>\nمتن، عکس یا ویدیو (با یا بدون توضیح) ارسال کنید:',
    },
    'broadcast_received': {
        'ar': '✅ <b>تم استلام محتوى الإذاعة</b>\n\n📤 اختر الفئة المستهدفة بالإذاعة:',
        'en': '✅ <b>Broadcast content received</b>\n\n📤 Choose the target audience for the broadcast:',
        'ru': '✅ <b>Содержимое рассылки получено</b>\n\n📤 Выберите целевую аудиторию:',
        'zh': '✅ <b>已收到广播内容</b>\n\n📤 选择广播的目标受众:',
        'fa': '✅ <b>محتوای پیام‌رسانی دریافت شد</b>\n\n📤 مخاطب هدف پیام‌رسانی را انتخاب کنید:',
    },
    'broadcast_sending': {
        'ar': '📤 <b>جاري إرسال الإذاعة...</b>\n\n🎯 الفئة: {target_label}\n👥 العدد: {count}\n📌 التثبيت: {pin_label}',
        'en': '📤 <b>Sending broadcast...</b>\n\n🎯 Target: {target_label}\n👥 Count: {count}\n📌 Pinning: {pin_label}',
        'ru': '📤 <b>Идёт рассылка...</b>\n\n🎯 Аудитория: {target_label}\n👥 Кол-во: {count}\n📌 Закрепление: {pin_label}',
        'zh': '📤 <b>正在发送广播...</b>\n\n🎯 目标:{target_label}\n👥 数量:{count}\n📌 置顶:{pin_label}',
        'fa': '📤 <b>در حال ارسال پیام‌رسانی...</b>\n\n🎯 مخاطب: {target_label}\n👥 تعداد: {count}\n📌 سنجاق: {pin_label}',
    },
    'broadcast_summary': {
        'ar': '✅ <b>تم الانتهاء من الإذاعة</b>\n\n🎯 الفئة: {target_label}\n👥 الإجمالي: {total}\n✅ تم الإرسال بنجاح: {success}\n❌ فشل الإرسال: {failed}',
        'en': '✅ <b>Broadcast complete</b>\n\n🎯 Target: {target_label}\n👥 Total: {total}\n✅ Sent successfully: {success}\n❌ Failed: {failed}',
        'ru': '✅ <b>Рассылка завершена</b>\n\n🎯 Аудитория: {target_label}\n👥 Всего: {total}\n✅ Успешно отправлено: {success}\n❌ Ошибок: {failed}',
        'zh': '✅ <b>广播完成</b>\n\n🎯 目标:{target_label}\n👥 总数:{total}\n✅ 成功发送:{success}\n❌ 失败:{failed}',
        'fa': '✅ <b>پیام‌رسانی تمام شد</b>\n\n🎯 مخاطب: {target_label}\n👥 مجموع: {total}\n✅ موفق: {success}\n❌ ناموفق: {failed}',
    },
    'broadcast_pin_label': {
        'ar': 'مفعل', 'en': 'enabled', 'ru': 'включено', 'zh': '已启用', 'fa': 'فعال',
    },
    'broadcast_pin_label_off': {
        'ar': 'غير مفعل', 'en': 'disabled', 'ru': 'отключено', 'zh': '未启用', 'fa': 'غیرفعال',
    },
    'broadcast_target_normal_label': {
        'ar': '👥 المستخدمين العاديين', 'en': '👥 Normal users', 'ru': '👥 Обычные пользователи',
        'zh': '👥 普通用户', 'fa': '👥 کاربران عادی',
    },
    'broadcast_target_vip_label': {
        'ar': '🌟 مستخدمين VIP', 'en': '🌟 VIP users', 'ru': '🌟 VIP-пользователи',
        'zh': '🌟 VIP 用户', 'fa': '🌟 کاربران VIP',
    },
    'broadcast_target_all_label': {
        'ar': '📢 جميع المستخدمين (الكل)', 'en': '📢 All users (everyone)', 'ru': '📢 Все пользователи',
        'zh': '📢 所有用户 (全部)', 'fa': '📢 همه کاربران (همه)',
    },
    'btn_broadcast_normal': {
        'ar': '👥 المستخدمين العاديين', 'en': '👥 Normal Users', 'ru': '👥 Обычные пользователи',
        'zh': '👥 普通用户', 'fa': '👥 کاربران عادی',
    },
    'btn_broadcast_vip': {
        'ar': '🌟 مستخدمين VIP', 'en': '🌟 VIP Users', 'ru': '🌟 VIP-пользователи',
        'zh': '🌟 VIP 用户', 'fa': '🌟 کاربران VIP',
    },
    'btn_broadcast_all': {
        'ar': '📢 جميع المستخدمين (الكل)', 'en': '📢 All Users (Everyone)', 'ru': '📢 Все пользователи',
        'zh': '📢 所有用户 (全部)', 'fa': '📢 همه کاربران (همه)',
    },
    'btn_broadcast_pin_yes': {
        'ar': '📌 نعم، قم بالتثبيت', 'en': '📌 Yes, pin it', 'ru': '📌 Да, закрепить',
        'zh': '📌 是的, 置顶', 'fa': '📌 بله، سنجاق کن',
    },
    'btn_broadcast_pin_no': {
        'ar': '🚫 لا، بدون تثبيت', 'en': '🚫 No, do not pin', 'ru': '🚫 Нет, без закрепления',
        'zh': '🚫 不, 不置顶', 'fa': '🚫 نه، بدون سنجاق',
    },
    'broadcast_pin_prompt': {
        'ar': '📌 <b>هل تريد تثبيت هذه الرسالة في محادثات المستخدمين الذين تصلهم؟</b>',
        'en': '📌 <b>Do you want to pin this message in the chats of the users who receive it?</b>',
        'ru': '📌 <b>Закрепить это сообщение в чатах пользователей, которые его получат?</b>',
        'zh': '📌 <b>是否要在收到此消息的用户的聊天中置顶?</b>',
        'fa': '📌 <b>آیا می‌خواهید این پیام را در چت کاربرانی که دریافت می‌کنند سنجاق کنید؟</b>',
    },

    # ===== تجديد الرسائل =====
    'renew_messages_prompt': {
        'ar': '🔄 <b>تجديد رصيد الرسائل</b>\n\n✏️ أرسل آيدي أو يوزر المستخدم:',
        'en': '🔄 <b>Renew Message Balance</b>\n\n✏️ Send the user ID or username:',
        'ru': '🔄 <b>Продление баланса сообщений</b>\n\n✏️ Отправьте ID или юзернейм пользователя:',
        'zh': '🔄 <b>续费消息余额</b>\n\n✏️ 发送用户的 ID 或用户名:',
        'fa': '🔄 <b>تمدید موجودی پیام</b>\n\n✏️ آیدی یا یوزرنیم کاربر را ارسال کنید:',
    },
    'renew_user_not_found': {
        'ar': '❌ <b>لم يتم العثور على المستخدم!</b>\nتأكد من الايدي أو اليوزر وحاول مرة أخرى:',
        'en': '❌ <b>User not found!</b>\nMake sure the ID or username is correct and try again:',
        'ru': '❌ <b>Пользователь не найден!</b>\nУбедитесь, что ID или юзернейм верны, и попробуйте ещё раз:',
        'zh': '❌ <b>未找到用户!</b>\n请确认 ID 或用户名正确后重试:',
        'fa': '❌ <b>کاربر یافت نشد!</b>\nاز درستی آیدی یا یوزرنیم مطمئن شوید و دوباره تلاش کنید:',
    },
    'renew_user_found': {
        'ar': '✅ <b>تم العثور على المستخدم</b>\n\n👤 الاسم: {name}\n🆔 اليوزر: {username}\n🔢 الايدي: <code>{user_id}</code>\n📊 رصيده الحالي: {balance} رسالة\n\n✏️ أرسل عدد الرسائل التي تريد تجديدها (إضافتها) لهذا المستخدم:',
        'en': '✅ <b>User found</b>\n\n👤 Name: {name}\n🆔 Username: {username}\n🔢 ID: <code>{user_id}</code>\n📊 Current balance: {balance} messages\n\n✏️ Send the number of messages to renew (add) to this user:',
        'ru': '✅ <b>Пользователь найден</b>\n\n👤 Имя: {name}\n🆔 Юзернейм: {username}\n🔢 ID: <code>{user_id}</code>\n📊 Текущий баланс: {balance} сообщений\n\n✏️ Отправьте количество сообщений для добавления этому пользователю:',
        'zh': '✅ <b>已找到用户</b>\n\n👤 名称:{name}\n🆔 用户名:{username}\n🔢 ID:<code>{user_id}</code>\n📊 当前余额:{balance} 条消息\n\n✏️ 发送要为此用户续费(添加)的消息数量:',
        'fa': '✅ <b>کاربر پیدا شد</b>\n\n👤 نام: {name}\n🆔 یوزرنیم: {username}\n🔢 آیدی: <code>{user_id}</code>\n📊 موجودی فعلی: {balance} پیام\n\n✏️ تعداد پیام‌هایی که می‌خواهید به این کاربر اضافه کنید را ارسال کنید:',
    },
    'renew_amount_invalid': {
        'ar': '❌ <b>يرجى إرسال عدد صحيح أكبر من صفر:</b>',
        'en': '❌ <b>Please send a positive integer:</b>',
        'ru': '❌ <b>Пожалуйста, отправьте положительное целое число:</b>',
        'zh': '❌ <b>请发送一个正整数:</b>',
        'fa': '❌ <b>لطفاً یک عدد صحیح مثبت ارسال کنید:</b>',
    },
    'renew_success_admin': {
        'ar': '✅ <b>تم تجديد الرسائل بنجاح!</b>\n\n👤 المستخدم: {name} ({username})\n🔢 الايدي: <code>{user_id}</code>\n📊 الرصيد السابق: {old}\n➕ تم إضافة: {added}\n📈 الرصيد الجديد: {new}',
        'en': '✅ <b>Messages renewed successfully!</b>\n\n👤 User: {name} ({username})\n🔢 ID: <code>{user_id}</code>\n📊 Previous balance: {old}\n➕ Added: {added}\n📈 New balance: {new}',
        'ru': '✅ <b>Сообщения успешно продлены!</b>\n\n👤 Пользователь: {name} ({username})\n🔢 ID: <code>{user_id}</code>\n📊 Предыдущий баланс: {old}\n➕ Добавлено: {added}\n📈 Новый баланс: {new}',
        'zh': '✅ <b>消息续费成功!</b>\n\n👤 用户:{name} ({username})\n🔢 ID:<code>{user_id}</code>\n📊 之前余额:{old}\n➕ 已添加:{added}\n📈 新余额:{new}',
        'fa': '✅ <b>تمدید پیام‌ها با موفقیت انجام شد!</b>\n\n👤 کاربر: {name} ({username})\n🔢 آیدی: <code>{user_id}</code>\n📊 موجودی قبلی: {old}\n➕ اضافه شده: {added}\n📈 موجودی جدید: {new}',
    },
    'renew_user_notification': {
        'ar': '🎉 <b>تم تجديد رصيد رسائلك!</b>\n\n📈 رصيدك الحالي: {new} رسالة 💬',
        'en': '🎉 <b>Your message balance has been renewed!</b>\n\n📈 Current balance: {new} messages 💬',
        'ru': '🎉 <b>Ваш баланс сообщений продлён!</b>\n\n📈 Текущий баланс: {new} сообщений 💬',
        'zh': '🎉 <b>您的消息余额已续费!</b>\n\n📈 当前余额:{new} 条消息 💬',
        'fa': '🎉 <b>موجودی پیام شما تمدید شد!</b>\n\n📈 موجودی فعلی: {new} پیام 💬',
    },

    # ===== تفعيل VIP من الأدمن =====
    'admin_vip_prompt': {
        'ar': '🌟 <b>تفعيل اشتراك VIP</b>\n\n✏️ أرسل آيدي أو يوزر المستخدم:',
        'en': '🌟 <b>Activate VIP Subscription</b>\n\n✏️ Send the user ID or username:',
        'ru': '🌟 <b>Активация VIP-подписки</b>\n\n✏️ Отправьте ID или юзернейм пользователя:',
        'zh': '🌟 <b>激活 VIP 订阅</b>\n\n✏️ 发送用户的 ID 或用户名:',
        'fa': '🌟 <b>فعال‌سازی اشتراک VIP</b>\n\n✏️ آیدی یا یوزرنیم کاربر را ارسال کنید:',
    },
    'admin_vip_user_info': {
        'ar': '✅ <b>تم العثور على المستخدم</b>\n\n👤 الاسم: {name}\n🆔 اليوزر: {username}\n🔢 الايدي: <code>{user_id}</code>\n{vip_line}\n📅 اختر مدة اشتراك VIP:',
        'en': '✅ <b>User found</b>\n\n👤 Name: {name}\n🆔 Username: {username}\n🔢 ID: <code>{user_id}</code>\n{vip_line}\n📅 Choose VIP subscription duration:',
        'ru': '✅ <b>Пользователь найден</b>\n\n👤 Имя: {name}\n🆔 Юзернейм: {username}\n🔢 ID: <code>{user_id}</code>\n{vip_line}\n📅 Выберите длительность VIP-подписки:',
        'zh': '✅ <b>已找到用户</b>\n\n👤 名称:{name}\n🆔 用户名:{username}\n🔢 ID:<code>{user_id}</code>\n{vip_line}\n📅 选择 VIP 订阅时长:',
        'fa': '✅ <b>کاربر پیدا شد</b>\n\n👤 نام: {name}\n🆔 یوزرنیم: {username}\n🔢 آیدی: <code>{user_id}</code>\n{vip_line}\n📅 مدت اشتراک VIP را انتخاب کنید:',
    },
    'admin_vip_existing_line': {
        'ar': '⏰ اشتراكه الحالي ينتهي في: {expiry}\n',
        'en': '⏰ Current subscription ends on: {expiry}\n',
        'ru': '⏰ Текущая подписка истекает: {expiry}\n',
        'zh': '⏰ 当前订阅将于 {expiry} 到期\n',
        'fa': '⏰ اشتراک فعلی در {expiry} پایان می‌یابد\n',
    },
    'admin_vip_no_existing_line': {
        'ar': '⭕ ليس مشتركاً في VIP حالياً\n',
        'en': '⭕ Not currently subscribed to VIP\n',
        'ru': '⭕ В настоящее время не подписан на VIP\n',
        'zh': '⭕ 当前未订阅 VIP\n',
        'fa': '⭕ در حال حاضر مشترک VIP نیست\n',
    },
    'admin_vip_success': {
        'ar': '✅ <b>تم تفعيل اشتراك VIP بنجاح!</b>\n\n👤 المستخدم: {name} ({username})\n🔢 الايدي: <code>{user_id}</code>\n📅 المدة: {duration}\n⏰ ينتهي الاشتراك في: {expiry}\n\n💎 المستخدم الآن بدون وقت انتظار وبدون حدود رسائل ⚡',
        'en': '✅ <b>VIP subscription activated successfully!</b>\n\n👤 User: {name} ({username})\n🔢 ID: <code>{user_id}</code>\n📅 Duration: {duration}\n⏰ Subscription ends on: {expiry}\n\n💎 The user now has no waiting time and no message limits ⚡',
        'ru': '✅ <b>VIP-подписка успешно активирована!</b>\n\n👤 Пользователь: {name} ({username})\n🔢 ID: <code>{user_id}</code>\n📅 Длительность: {duration}\n⏰ Подписка истекает: {expiry}\n\n💎 Теперь у пользователя нет ожидания и лимита сообщений ⚡',
        'zh': '✅ <b>VIP 订阅已成功激活!</b>\n\n👤 用户:{name} ({username})\n🔢 ID:<code>{user_id}</code>\n📅 时长:{duration}\n⏰ 订阅将于 {expiry} 到期\n\n💎 用户现无等待时间，无消息限制 ⚡',
        'fa': '✅ <b>اشتراک VIP با موفقیت فعال شد!</b>\n\n👤 کاربر: {name} ({username})\n🔢 آیدی: <code>{user_id}</code>\n📅 مدت: {duration}\n⏰ اشتراک در {expiry} پایان می‌یابد\n\n💎 کاربر اکنون بدون زمان انتظار و بدون محدودیت پیام است ⚡',
    },
    'admin_vip_user_notification': {
        'ar': '🎉 <b>تهانينا! تم تفعيل اشتراك VIP لحسابك</b> 🌟\n\n📅 المدة: {duration}\n⏰ ينتهي في: {expiry}\n\n💎 الآن تتحدث بدون أي وقت انتظار بين الرسائل وبدون حدود! ⚡',
        'en': '🎉 <b>Congratulations! A VIP subscription has been activated on your account</b> 🌟\n\n📅 Duration: {duration}\n⏰ Ends on: {expiry}\n\n💎 You can now chat with no waiting time between messages and no limits! ⚡',
        'ru': '🎉 <b>Поздравляем! На вашем аккаунте активирована VIP-подписка</b> 🌟\n\n📅 Длительность: {duration}\n⏰ Истекает: {expiry}\n\n💎 Теперь вы можете общаться без ожидания и без ограничений! ⚡',
        'zh': '🎉 <b>恭喜!您的账户已激活 VIP 订阅</b> 🌟\n\n📅 时长:{duration}\n⏰ 到期时间:{expiry}\n\n💎 现在您可以畅聊，无需等待,无任何限制!⚡',
        'fa': '🎉 <b>تبریک! اشتراک VIP برای حساب شما فعال شد</b> 🌟\n\n📅 مدت: {duration}\n⏰ پایان: {expiry}\n\n💎 اکنون بدون هیچ زمان انتظاری بین پیام‌ها و بدون هیچ محدودیتی گفتگو کنید! ⚡',
    },

    # ===== إحصائيات =====
    'stats_text': {
        'ar': '📊 <b>الاحصائيات</b>\n\n👥 <b>المستخدمين:</b> {users}\n💬 <b>المحادثات النشطة:</b> {convs}\n⚡ <b>الحالة:</b> نشط\n🧠 <b>الذاكرة:</b> 10 رسالة\n💀 <b>الوضع:</b> غير مقيد بالكامل\n✍️ <b>الكتابة:</b> تدريجية فائقة السرعة\n📝 <b>الأكواد:</b> صغير يظهر | كبير ملف',
        'en': '📊 <b>Statistics</b>\n\n👥 <b>Users:</b> {users}\n💬 <b>Active conversations:</b> {convs}\n⚡ <b>Status:</b> active\n🧠 <b>Memory:</b> 10 messages\n💀 <b>Mode:</b> fully unrestricted\n✍️ <b>Typing:</b> ultra-fast progressive\n📝 <b>Code:</b> small inline | large file',
        'ru': '📊 <b>Статистика</b>\n\n👥 <b>Пользователей:</b> {users}\n💬 <b>Активных диалогов:</b> {convs}\n⚡ <b>Состояние:</b> активно\n🧠 <b>Память:</b> 10 сообщений\n💀 <b>Режим:</b> полностью без ограничений\n✍️ <b>Печать:</b> сверхбыстрая постепенная\n📝 <b>Код:</b> маленький в строке | большой файл',
        'zh': '📊 <b>统计</b>\n\n👥 <b>用户数:</b> {users}\n💬 <b>活动对话:</b> {convs}\n⚡ <b>状态:</b> 活跃\n🧠 <b>内存:</b> 10 条消息\n💀 <b>模式:</b> 完全无限制\n✍️ <b>打字:</b> 超快渐进\n📝 <b>代码:</b> 小内联 | 大文件',
        'fa': '📊 <b>آمار</b>\n\n👥 <b>کاربران:</b> {users}\n💬 <b>گفتگوهای فعال:</b> {convs}\n⚡ <b>وضعیت:</b> فعال\n🧠 <b>حافظه:</b> ۱۰ پیام\n💀 <b>حالت:</b> کاملاً بدون محدودیت\n✍️ <b>نگارش:</b> تدریجی فوق‌سریع\n📝 <b>کد:</b> کوچک درون‌خطی | بزرگ فایل',
    },

    # ===== قائمة VIP (أدمن) =====
    'vip_list_header': {
        'ar': '📋 <b>قائمة مشتركي VIP النشطين</b> (الإجمالي: {count})',
        'en': '📋 <b>Active VIP Subscribers</b> (Total: {count})',
        'ru': '📋 <b>Активные VIP-подписчики</b> (Всего: {count})',
        'zh': '📋 <b>活跃的 VIP 订阅者</b> (总计:{count})',
        'fa': '📋 <b>مشترکین فعال VIP</b> (مجموع: {count})',
    },
    'vip_list_empty': {
        'ar': '📋 <b>قائمة VIP</b>\n\nلا يوجد مشتركون VIP نشطون حالياً.',
        'en': '📋 <b>VIP List</b>\n\nThere are no active VIP subscribers right now.',
        'ru': '📋 <b>Список VIP</b>\n\nСейчас нет активных VIP-подписчиков.',
        'zh': '📋 <b>VIP 列表</b>\n\n当前没有活跃的 VIP 订阅者。',
        'fa': '📋 <b>لیست VIP</b>\n\nدر حال حاضر هیچ مشترک فعال VIP وجود ندارد.',
    },

    # ===== دعم الأدمن =====
    'support_reply_prompt_admin': {
        'ar': '✍️ أرسل ردك للمستخدم (نص/صورة/فيديو):',
        'en': '✍️ Send your reply to the user (text/photo/video):',
        'ru': '✍️ Отправьте ваш ответ пользователю (текст/фото/видео):',
        'zh': '✍️ 向用户发送您的回复(文字/图片/视频):',
        'fa': '✍️ پاسخ خود را برای کاربر ارسال کنید (متن/عکس/ویدیو):',
    },
    'support_reply_invalid': {
        'ar': '⚠️ أرسل نص، صورة، أو فيديو كرد:',
        'en': '⚠️ Send text, a photo, or a video as your reply:',
        'ru': '⚠️ Отправьте текст, фото или видео в качестве ответа:',
        'zh': '⚠️ 请发送文字、图片或视频作为回复:',
        'fa': '⚠️ متن، عکس یا ویدیو به‌عنوان پاسخ ارسال کنید:',
    },
    'support_reply_no_target': {
        'ar': '❌ حدث خطأ، لم يتم تحديد المستخدم المستهدف بالرد.',
        'en': '❌ An error occurred, no target user for the reply was set.',
        'ru': '❌ Произошла ошибка, не указан целевой пользователь для ответа.',
        'zh': '❌ 发生错误,未指定回复的目标用户。',
        'fa': '❌ خطایی رخ داد، کاربر هدف برای پاسخ تعیین نشده است.',
    },
    'support_reply_sent': {
        'ar': '✅ تم إرسال ردك للمستخدم بنجاح.',
        'en': '✅ Your reply was sent to the user successfully.',
        'ru': '✅ Ваш ответ успешно отправлен пользователю.',
        'zh': '✅ 您的回复已成功发送给用户。',
        'fa': '✅ پاسخ شما با موفقیت برای کاربر ارسال شد.',
    },
    'support_reply_failed': {
        'ar': '❌ فشل إرسال الرد، قد يكون المستخدم حظر البوت.',
        'en': '❌ Failed to send the reply, the user may have blocked the bot.',
        'ru': '❌ Не удалось отправить ответ, возможно, пользователь заблокировал бота.',
        'zh': '❌ 发送回复失败,用户可能已阻止机器人。',
        'fa': '❌ ارسال پاسخ ناموفق بود، ممکن است کاربر ربات را مسدود کرده باشد.',
    },
    'btn_support_reply': {
        'ar': '↩️ رد على الرسالة', 'en': '↩️ Reply to message', 'ru': '↩️ Ответить на сообщение',
        'zh': '↩️ 回复消息', 'fa': '↩️ پاسخ به پیام',
    },

    # ===== رسائل إشعار للأدمن =====
    'admin_new_user_notice': {
        'ar': '✨ مستخدم جديد\n\nالاسم: {name}\nاليوزر: @{username}\nالايدي: {user_id}',
        'en': '✨ New user\n\nName: {name}\nUsername: @{username}\nID: {user_id}',
        'ru': '✨ Новый пользователь\n\nИмя: {name}\nЮзернейм: @{username}\nID: {user_id}',
        'zh': '✨ 新用户\n\n名称:{name}\n用户名:@{username}\nID:{user_id}',
        'fa': '✨ کاربر جدید\n\nنام: {name}\nیوزرنیم: @{username}\nآیدی: {user_id}',
    },
    'admin_support_forward_header': {
        'ar': '📩 <b>رسالة دعم جديدة</b>\n\n👤 الاسم: {name}\n🆔 اليوزر: {username}\n🔢 الايدي: <code>{user_id}</code>\n💎 الحالة: {status}\n🕐 وقت الإرسال: {timestamp}',
        'en': '📩 <b>New support message</b>\n\n👤 Name: {name}\n🆔 Username: {username}\n🔢 ID: <code>{user_id}</code>\n💎 Status: {status}\n🕐 Sent at: {timestamp}',
        'ru': '📩 <b>Новое сообщение в поддержку</b>\n\n👤 Имя: {name}\n🆔 Юзернейм: {username}\n🔢 ID: <code>{user_id}</code>\n💎 Статус: {status}\n🕐 Время отправки: {timestamp}',
        'zh': '📩 <b>新的支持消息</b>\n\n👤 名称:{name}\n🆔 用户名:{username}\n🔢 ID:<code>{user_id}</code>\n💎 状态:{status}\n🕐 发送时间:{timestamp}',
        'fa': '📩 <b>پیام پشتیبانی جدید</b>\n\n👤 نام: {name}\n🆔 یوزرنیم: {username}\n🔢 آیدی: <code>{user_id}</code>\n💎 وضعیت: {status}\n🕐 زمان ارسال: {timestamp}',
    },
    'admin_support_photo_caption': {
        'ar': '📷 صورة حساب المستخدم',
        'en': '📷 User account photo',
        'ru': '📷 Фото аккаунта пользователя',
        'zh': '📷 用户账户照片',
        'fa': '📷 عکس حساب کاربر',
    },
    'status_vip_active': {
        'ar': '🌟 VIP (ينتهي: {expiry})',
        'en': '🌟 VIP (ends: {expiry})',
        'ru': '🌟 VIP (истекает: {expiry})',
        'zh': '🌟 VIP (到期: {expiry})',
        'fa': '🌟 VIP (پایان: {expiry})',
    },
    'status_normal_user': {
        'ar': '👤 مستخدم عادي',
        'en': '👤 Normal user',
        'ru': '👤 Обычный пользователь',
        'zh': '👤 普通用户',
        'fa': '👤 کاربر عادی',
    },

    # ===== إشعار اشتراك VIP (نجوم) =====
    'admin_vip_payment_notice': {
        'ar': '⭐ <b>اشتراك VIP جديد!</b>\n\n👤 الاسم: {name}\n🆔 اليوزر: {username}\n🔢 الايدي: <code>{user_id}</code>\n📅 المدة: {duration}\n⭐ المبلغ: {amount} نجمة\n🧾 رقم العملية: <code>{charge_id}</code>\n🕐 وقت الاشتراك: {subscribed_at}\n⏳ ينتهي الاشتراك في: {expiry}\n📆 تاريخ انضمام المستخدم للبوت: {joined_at}\n📨 إجمالي رسائله السابقة: {total_sent}',
        'en': '⭐ <b>New VIP subscription!</b>\n\n👤 Name: {name}\n🆔 Username: {username}\n🔢 ID: <code>{user_id}</code>\n📅 Duration: {duration}\n⭐ Amount: {amount} stars\n🧾 Charge ID: <code>{charge_id}</code>\n🕐 Subscribed at: {subscribed_at}\n⏳ Subscription ends on: {expiry}\n📆 User joined bot on: {joined_at}\n📨 Total previous messages: {total_sent}',
        'ru': '⭐ <b>Новая VIP-подписка!</b>\n\n👤 Имя: {name}\n🆔 Юзернейм: {username}\n🔢 ID: <code>{user_id}</code>\n📅 Длительность: {duration}\n⭐ Сумма: {amount} звёзд\n🧾 Номер операции: <code>{charge_id}</code>\n🕐 Время подписки: {subscribed_at}\n⏳ Подписка истекает: {expiry}\n📆 Пользователь присоединился: {joined_at}\n📨 Всего предыдущих сообщений: {total_sent}',
        'zh': '⭐ <b>新的 VIP 订阅!</b>\n\n👤 名称:{name}\n🆔 用户名:{username}\n🔢 ID:<code>{user_id}</code>\n📅 时长:{duration}\n⭐ 金额:{amount} 颗星\n🧾 订单号:<code>{charge_id}</code>\n🕐 订阅时间:{subscribed_at}\n⏳ 订阅将于 {expiry} 到期\n📆 用户加入日期:{joined_at}\n📨 之前发送的消息总数:{total_sent}',
        'fa': '⭐ <b>اشتراک VIP جدید!</b>\n\n👤 نام: {name}\n🆔 یوزرنیم: {username}\n🔢 آیدی: <code>{user_id}</code>\n📅 مدت: {duration}\n⭐ مبلغ: {amount} ستاره\n🧾 شماره تراکنش: <code>{charge_id}</code>\n🕐 زمان اشتراک: {subscribed_at}\n⏳ اشتراک در {expiry} پایان می‌یابد\n📆 تاریخ عضویت کاربر: {joined_at}\n📨 مجموع پیام‌های قبلی: {total_sent}',
    },

    # ===== أزرار مدد VIP (لوحة الأدمن) =====
    'btn_vip_duration_week_admin': {
        'ar': '📅 اسبوع', 'en': '📅 1 week', 'ru': '📅 1 неделя', 'zh': '📅 1周', 'fa': '📅 ۱ هفته',
    },
    'btn_vip_duration_2weeks_admin': {
        'ar': '📅 اسبوعين', 'en': '📅 2 weeks', 'ru': '📅 2 недели', 'zh': '📅 2周', 'fa': '📅 ۲ هفته',
    },
    'btn_vip_duration_3weeks_admin': {
        'ar': '📅 3 اسابيع', 'en': '📅 3 weeks', 'ru': '📅 3 недели', 'zh': '📅 3周', 'fa': '📅 ۳ هفته',
    },
    'btn_copy_code': {
        'ar': '📋 نسخ الكود', 'en': '📋 Copy code', 'ru': '📋 Копировать код',
        'zh': '📋 复制代码', 'fa': '📋 کپی کد',
    },
    'btn_retry': {
        'ar': '🔄 إعادة المحاولة', 'en': '🔄 Retry', 'ru': '🔄 Повторить',
        'zh': '🔄 重试', 'fa': '🔄 تلاش مجدد',
    },
    'btn_back_small': {
        'ar': '🔙 رجوع', 'en': '🔙 Back', 'ru': '🔙 Назад', 'zh': '🔙 返回', 'fa': '🔙 بازگشت',
    },

    # ===========================================================
    #   ميزة رفع الملفات V2
    # ===========================================================
    'file_upload_welcome': {
        'ar': '📎 <b>تم استلام الملف بنجاح</b>\n\n📄 <b>اسم الملف:</b> <code>{file_name}</code>\n📏 <b>عدد الأسطر:</b> {line_count}\n\n💬 <b>الرجاء إرسال التعليم/الطلب الذي تريد من الذكاء الاصطناعي تنفيذه على هذا الملف.</b>',
        'en': '📎 <b>File received successfully</b>\n\n📄 <b>File name:</b> <code>{file_name}</code>\n📏 <b>Line count:</b> {line_count}\n\n💬 <b>Please send the instruction/request you want the AI to perform on this file.</b>',
        'ru': '📎 <b>Файл успешно получен</b>\n\n📄 <b>Имя файла:</b> <code>{file_name}</code>\n📏 <b>Кол-во строк:</b> {line_count}\n\n💬 <b>Пожалуйста, отправьте инструкцию/запрос, который вы хотите, чтобы ИИ выполнил над этим файлом.</b>',
        'zh': '📎 <b>文件已成功接收</b>\n\n📄 <b>文件名:</b> <code>{file_name}</code>\n📏 <b>行数:</b> {line_count}\n\n💬 <b>请发送您希望 AI 对此文件执行的指令/请求。</b>',
        'fa': '📎 <b>فایل با موفقیت دریافت شد</b>\n\n📄 <b>نام فایل:</b> <code>{file_name}</code>\n📏 <b>تعداد خطوط:</b> {line_count}\n\n💬 <b>لطفاً دستور/درخواستی که می‌خواهید هوش مصنوعی روی این فایل اجرا کند را ارسال کنید.</b>',
    },
    'file_too_large': {
        'ar': '⚠️ <b>الملف كبير جداً</b>\n\n📄 الملف: <code>{file_name}</code>\n📏 عدد الأسطر: {line_count}\n🚫 الحد الأقصى المسموح به: <b>{max_lines}</b> سطر\n\n❌ لا يمكن معالجة هذا الملف. يرجى إرسال ملف أصغر من {max_lines} سطراً.',
        'en': '⚠️ <b>File is too large</b>\n\n📄 File: <code>{file_name}</code>\n📏 Line count: {line_count}\n🚫 Maximum allowed: <b>{max_lines}</b> lines\n\n❌ This file cannot be processed. Please send a file smaller than {max_lines} lines.',
        'ru': '⚠️ <b>Файл слишком большой</b>\n\n📄 Файл: <code>{file_name}</code>\n📏 Кол-во строк: {line_count}\n🚫 Максимально допустимо: <b>{max_lines}</b> строк\n\n❌ Этот файл не может быть обработан. Пожалуйста, отправьте файл меньше {max_lines} строк.',
        'zh': '⚠️ <b>文件过大</b>\n\n📄 文件:<code>{file_name}</code>\n📏 行数:{line_count}\n🚫 允许的最大值:<b>{max_lines}</b> 行\n\n❌ 无法处理此文件。请发送少于 {max_lines} 行的文件。',
        'fa': '⚠️ <b>فایل بسیار بزرگ است</b>\n\n📄 فایل: <code>{file_name}</code>\n📏 تعداد خطوط: {line_count}\n🚫 حداکثر مجاز: <b>{max_lines}</b> خط\n\n❌ این فایل قابل پردازش نیست. لطفاً فایلی کمتر از {max_lines} خط ارسال کنید.',
    },
    'file_type_unsupported': {
        'ar': '⚠️ <b>نوع الملف غير مدعوم</b>\n\n📄 الملف: <code>{file_name}</code>\n📎 الامتداد: <code>{ext}</code>\n\n✅ الامتدادات المدعومة:\n{supported_list}\n\n💡 الرجاء إرسال ملف بصيغة مدعومة.',
        'en': '⚠️ <b>Unsupported file type</b>\n\n📄 File: <code>{file_name}</code>\n📎 Extension: <code>{ext}</code>\n\n✅ Supported extensions:\n{supported_list}\n\n💡 Please send a file with a supported format.',
        'ru': '⚠️ <b>Неподдерживаемый тип файла</b>\n\n📄 Файл: <code>{file_name}</code>\n📎 Расширение: <code>{ext}</code>\n\n✅ Поддерживаемые расширения:\n{supported_list}\n\n💡 Пожалуйста, отправьте файл в поддерживаемом формате.',
        'zh': '⚠️ <b>不支持的文件类型</b>\n\n📄 文件:<code>{file_name}</code>\n📎 扩展名:<code>{ext}</code>\n\n✅ 支持的扩展名:\n{supported_list}\n\n💡 请以支持的格式发送文件。',
        'fa': '⚠️ <b>نوع فایل پشتیبانی نمی‌شود</b>\n\n📄 فایل: <code>{file_name}</code>\n📎 پسوند: <code>{ext}</code>\n\n✅ پسوندهای پشتیبانی‌شده:\n{supported_list}\n\n💡 لطفاً فایلی با فرمت پشتیبانی‌شده ارسال کنید.',
    },
    'file_read_error': {
        'ar': '❌ <b>تعذّر قراءة محتوى الملف</b>\n\nقد يكون الملف تالفاً، أو مشفّراً، أو بتنسيق ثنائي لا يمكن قراءته كنص.\n\n💡 حاول إرسال الملف كنص عادي (UTF-8) أو كود مصدري صالح.',
        'en': '❌ <b>Could not read file content</b>\n\nThe file may be corrupted, encrypted, or in a binary format that cannot be read as text.\n\n💡 Try sending the file as plain UTF-8 text or valid source code.',
        'ru': '❌ <b>Не удалось прочитать содержимое файла</b>\n\nВозможно, файл повреждён, зашифрован или имеет двоичный формат, который нельзя прочитать как текст.\n\n💡 Попробуйте отправить файл как обычный текст UTF-8 или валидный исходный код.',
        'zh': '❌ <b>无法读取文件内容</b>\n\n文件可能已损坏、已加密或为无法作为文本读取的二进制格式。\n\n💡 请尝试以纯 UTF-8 文本或有效的源代码形式发送文件。',
        'fa': '❌ <b>خواندن محتوای فایل امکان‌پذیر نیست</b>\n\nممکن است فایل خراب، رمزگذاری‌شده یا با فرمت باینری باشد که قابل خواندن به‌صورت متن نیست.\n\n💡 فایل را به‌صورت متن ساده UTF-8 یا کد منبع معتبر ارسال کنید.',
    },
    'file_caption_used': {
        'ar': '📎 <b>تم استلام الملف مع تعليمك</b>\n\n📄 الملف: <code>{file_name}</code>\n📏 الأسطر: {line_count}\n💬 التعليم: <i>{instruction}</i>\n\n⚙️ جاري المعالجة...',
        'en': '📎 <b>File and your instruction received</b>\n\n📄 File: <code>{file_name}</code>\n📏 Lines: {line_count}\n💬 Instruction: <i>{instruction}</i>\n\n⚙️ Processing...',
        'ru': '📎 <b>Файл и ваша инструкция получены</b>\n\n📄 Файл: <code>{file_name}</code>\n📏 Строк: {line_count}\n💬 Инструкция: <i>{instruction}</i>\n\n⚙️ Обработка...',
        'zh': '📎 <b>文件和您的指令已接收</b>\n\n📄 文件:<code>{file_name}</code>\n📏 行数:{line_count}\n💬 指令:<i>{instruction}</i>\n\n⚙️ 处理中...',
        'fa': '📎 <b>فایل و دستور شما دریافت شد</b>\n\n📄 فایل: <code>{file_name}</code>\n📏 خطوط: {line_count}\n💬 دستور: <i>{instruction}</i>\n\n⚙️ در حال پردازش...',
    },
    'file_processing_started': {
        'ar': '📎 <b>جاري معالجة الملف</b>\n\n📄 <code>{file_name}</code>\n💬 التعليم: <i>{instruction}</i>\n\n⏳ يرجى الانتظار...',
        'en': '📎 <b>Processing file</b>\n\n📄 <code>{file_name}</code>\n💬 Instruction: <i>{instruction}</i>\n\n⏳ Please wait...',
        'ru': '📎 <b>Обработка файла</b>\n\n📄 <code>{file_name}</code>\n💬 Инструкция: <i>{instruction}</i>\n\n⏳ Пожалуйста, подождите...',
        'zh': '📎 <b>正在处理文件</b>\n\n📄 <code>{file_name}</code>\n💬 指令:<i>{instruction}</i>\n\n⏳ 请稍候...',
        'fa': '📎 <b>در حال پردازش فایل</b>\n\n📄 <code>{file_name}</code>\n💬 دستور: <i>{instruction}</i>\n\n⏳ لطفاً صبر کنید...',
    },

    # ===== نصوص نتائج البحث (format_search_results) — مفقودة سابقاً، كانت ثابتة بالعربية =====
    'search_no_results': {
        'ar': '🔍 لم يتم العثور على نتائج لـ: <b>{query}</b>\n\n💡 حاول بكلمات مختلفة.',
        'en': '🔍 No results found for: <b>{query}</b>\n\n💡 Try different keywords.',
        'ru': '🔍 По запросу <b>{query}</b> результатов не найдено.\n\n💡 Попробуйте другие слова.',
        'zh': '🔍 未找到与以下内容相关的结果:<b>{query}</b>\n\n💡 请尝试其他关键词。',
        'fa': '🔍 نتیجه‌ای برای <b>{query}</b> یافت نشد.\n\n💡 با کلمات دیگری امتحان کنید.',
    },
    'search_results_header': {
        'ar': '🔍 <b>نتائج البحث عن:</b> {query}\n\n',
        'en': '🔍 <b>Search results for:</b> {query}\n\n',
        'ru': '🔍 <b>Результаты поиска:</b> {query}\n\n',
        'zh': '🔍 <b>搜索结果:</b> {query}\n\n',
        'fa': '🔍 <b>نتایج جستجو برای:</b> {query}\n\n',
    },
    'search_no_title': {
        'ar': 'بدون عنوان', 'en': 'No title', 'ru': 'Без названия', 'zh': '无标题', 'fa': 'بدون عنوان',
    },
    'search_link_label': {
        'ar': 'رابط', 'en': 'Link', 'ru': 'Ссылка', 'zh': '链接', 'fa': 'لینک',
    },

    # ===== نصوص ملفات الكود (format_ai_response_with_codes / file caption) — كانت ثابتة بالعربية =====
    'code_sent_as_file': {
        'ar': '📎 <b>تم إرسال الكود ({label}) كملف مرفق</b>',
        'en': '📎 <b>Code ({label}) was sent as an attached file</b>',
        'ru': '📎 <b>Код ({label}) отправлен в виде прикреплённого файла</b>',
        'zh': '📎 <b>代码({label})已作为附件文件发送</b>',
        'fa': '📎 <b>کد ({label}) به‌صورت فایل پیوست ارسال شد</b>',
    },
    'generic_file_label': {
        'ar': 'ملف', 'en': 'File', 'ru': 'Файл', 'zh': '文件', 'fa': 'فایل',
    },
    'code_file_caption': {
        'ar': '📎 كود {label}: {query}',
        'en': '📎 Code {label}: {query}',
        'ru': '📎 Код {label}: {query}',
        'zh': '📎 代码 {label}: {query}',
        'fa': '📎 کد {label}: {query}',
    },
}


def t(key, lang, **kwargs):
    """جلب نص مترجم بحسب اللغة، مع رجوع افتراضي للعربية إن لم تتوفر الترجمة"""
    entry = TEXTS.get(key, {})
    template = entry.get(lang) or entry.get(DEFAULT_LANGUAGE) or key
    if kwargs:
        try:
            return template.format(**kwargs)
        except Exception:
            return template
    return template

def get_user_language(user_id):
    """ارجاع كود لغة المستخدم المخزن، أو اللغة الافتراضية"""
    user_data = data.get(str(user_id))
    if not user_data:
        return DEFAULT_LANGUAGE
    return user_data.get('language', DEFAULT_LANGUAGE)

def set_user_language(user_id, lang_code):
    """تخزين لغة المستخدم المختارة"""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': DEFAULT_MESSAGES_LIMIT, 'vip_until': 0}
    data[uid]['language'] = lang_code
    save_data()

def detect_language_from_telegram_code(tg_code):
    """تحويل رمز لغة تلجرام (language_code المُرسل تلقائياً من تطبيق المستخدم) إلى أحد رموز اللغات
    الخمسة المدعومة في البوت. إذا كانت لغة المستخدم غير مدعومة أو غير متوفرة، يتم اعتماد الإنكليزية تلقائياً"""
    if not tg_code:
        return 'en'
    normalized = tg_code.lower().split('-')[0].split('_')[0]
    if normalized in LANGUAGES:
        return normalized
    return 'en'

def ensure_user_language_detected(user_id, tg_code):
    """عند أول تواصل مع المستخدم (لا توجد لغة محفوظة له بعد)، يتم تحديد لغته تلقائياً حسب لغة تطبيق
    تلجرام الخاص به وتخزينها. لا يُعاد تعيينها لمن اختار لغته يدوياً مسبقاً عبر أمر /language"""
    uid = str(user_id)
    if uid not in data or 'language' not in data.get(uid, {}):
        detected = detect_language_from_telegram_code(tg_code)
        set_user_language(user_id, detected)

def _looks_like_language(text, lang_code):
    """فحص تقريبي: هل يبدو النص مكتوباً بلغة معينة (حسب نطاق يونيكود)"""
    pattern = _SCRIPT_RANGES.get(lang_code)
    if pattern:
        return bool(re.search(pattern, text))
    # افتراضي للغات اللاتينية (كالإنجليزية): تحقق من وجود حروف لاتينية
    return bool(re.search(r'[A-Za-z]', text))

