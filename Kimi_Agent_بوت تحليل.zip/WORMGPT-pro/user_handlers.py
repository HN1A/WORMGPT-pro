import json
import os
import time
import threading
from config import (ADMIN, CHANNEL, COOLDOWN_SECONDS, DEFAULT_MESSAGES_LIMIT, OWNER_USER, photo_pending,
                     admin_context, data, save_data, last_message_time, user_states,
                     file_pending, FILE_MAX_LINES, SUPPORTED_FILE_EXTENSIONS,
                     research_image_pending, RESEARCH_V2_CONTEXT_TTL_SECONDS)
from i18n import get_user_language, t
from telegram_api import (edit_message_text, edit_message_caption, send_message, send_photo,
                           send_document, send_chat_action, copy_message, delete_message,
                           get_best_profile_photo_file_id, get_file, download_file_bytes)
from buttons import (admin_buttons, cancel_button, copy_button, retry_button,
                       language_picker_buttons, main_buttons, model_choice_buttons,
                       not_subscribe_buttons, wait_subscribe_buttons, photo_analyze_buttons,
                       cancel_search_button, search_type_picker_buttons)
from vip_system import (consume_message, get_messages_left, get_vip_expiry_text,
                         increment_message_count, is_vip, has_v2_access, get_v2_trials_left,
                         consume_v2_trial, get_user_model, set_user_model,
                         get_referral_link, get_ref_count, get_ref_bonus_v2, process_referral,
                         get_research_model, set_research_model, can_use_research_v2)
from channels_db import subscs
from ai_engine import (ask_wormgpt, ask_wormgpt_v1, ask_wormgpt_v2, ask_wormgpt_research_v2,
                        NoBalanceError,
                        add_to_context, clear_context, format_ai_response_with_codes,
                        format_search_results, get_language_extension, save_code_to_file,
                        search_web, send_typing_effect, store_last_query, pop_last_query,
                        clear_research_v2_context)

# ========================================================================
#                      معالجة الأوامر والرسائل (مع Threading للسرعة)
# ========================================================================

def handle_start(chat_id, user_id, username, first_name, message_id=None, start_param=None):
    lang = get_user_language(user_id)
    is_subscribed, channel = subscs(user_id)
    if not is_subscribed and channel:
        send_message(chat_id, t('subscribe_required', lang), reply_markup=not_subscribe_buttons(channel, lang))
        return
    
    if str(user_id) not in data:
        data[str(user_id)] = {
            'name': first_name,
            'username': username,
            'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
            'messages_left': DEFAULT_MESSAGES_LIMIT,
            'vip_until': 0,
            'total_messages_sent': 0
        }
        with open('data/data.json', 'w') as f:
            json.dump(data, f)
        
        for admin_id in ADMIN:
            try:
                send_message(admin_id, t('admin_new_user_notice', get_user_language(admin_id), name=first_name, username=username, user_id=user_id), parse_mode='HTML')
            except:
                pass

        # معالجة رابط الإحالة (إن وُجد) — لمستخدمين جدد فقط
        if start_param:
            try:
                referrer_id = int(start_param)
                if process_referral(user_id, referrer_id):
                    send_message(referrer_id, t('referral_join_thanks', get_user_language(referrer_id)), parse_mode='HTML')
            except (ValueError, Exception):
                pass
    else:
        # تحديث الاسم واليوزر للمستخدمين الحاليين + التأكد من وجود حقول VIP ورصيد الرسائل وعداد الرسائل الكلي
        changed = False
        if data[str(user_id)].get('username') != username:
            data[str(user_id)]['username'] = username
            changed = True
        if data[str(user_id)].get('name') != first_name:
            data[str(user_id)]['name'] = first_name
            changed = True
        if 'messages_left' not in data[str(user_id)]:
            data[str(user_id)]['messages_left'] = DEFAULT_MESSAGES_LIMIT
            changed = True
        if 'vip_until' not in data[str(user_id)]:
            data[str(user_id)]['vip_until'] = 0
            changed = True
        if 'total_messages_sent' not in data[str(user_id)]:
            data[str(user_id)]['total_messages_sent'] = 0
            changed = True
        if changed:
            save_data()
    
    clear_context(user_id)
    
    text = '<b>Hi Too User :)</b>\n<blockquote><tg-spoiler>⚠️ Disclaimer:\nThis project was created for educational and research purposes only, and I bear no responsibility for any misuse or illegal activities carried out using this tool. The user is solely responsible for how they choose to use it. ‼️</tg-spoiler></blockquote>\n\n<b>Speak...</b>'
    welcome_photo = "https://i.ibb.co/PZj2j89T/maxresdefault.jpg"
    
    if message_id:
        try:
            edit_message_caption(chat_id, message_id, text, reply_markup=main_buttons(lang), parse_mode='HTML')
        except:
            send_photo(chat_id, welcome_photo, caption=text, reply_markup=main_buttons(lang), parse_mode='HTML')
    else:
        send_photo(chat_id, welcome_photo, caption=text, reply_markup=main_buttons(lang), parse_mode='HTML')

def process_ai_response(chat_id, user_id, query, is_code=False, model='v2', _is_retry=False):
    """معالجة رد الذكاء الاصطناعي مع نظام التبديل التلقائي الكامل:
    1) V2 (gemma3.cc) مع Silent Failover إلى V2_FALLBACK_URLS (روابط ملف TXT)
    2) عند فشل V2 بسبب نفاد الرصيد/الحد → إبلاغ المستخدم + تحويل إلى V1
    3) عند فشل V2 لأسباب أخرى → تحويل صامت إلى V1
    4) عند فشل V1 → عرض زر "إعادة المحاولة" (الذي يعيد التنفيذ فعلياً)

    تُشغَّل في Thread منفصل. الوسيط _is_retry يُستخدم داخلياً لإعادة المحاولة."""
    from bot_logger import log_error as _log_err
    from buttons import retry_button as _retry
    lang = get_user_language(user_id)

    # حفظ آخر طلب لإعادة التفعيل من زر "إعادة المحاولة"
    if not _is_retry:
        try:
            store_last_query(user_id, query, is_code=is_code, model=model)
        except Exception:
            pass

    # تجهيز prompt وتعزيزه إذا كان طلب كود
    if is_code:
        add_to_context(user_id, 'user', f"طلب كود: {query}")
        actual_query = f"اكتب كود كامل لـ: {query} مع شرح المكتبات وطريقة التشغيل"
        use_search = False
    else:
        add_to_context(user_id, 'user', query)
        actual_query = query
        use_search = True

    response = None
    v2_balance_exhausted = False  # هل السبب نفاد رصيد V2؟

    # ===== المرحلة 1: V2 مع Silent Failover (إذا كان النموذج المطلوب V2) =====
    if model == 'v2':
        try:
            response = ask_wormgpt_v2(actual_query, user_id, is_search_query=use_search)
        except NoBalanceError as nbe:
            v2_balance_exhausted = True
            _log_err(f"V2 balance exhausted (source={nbe.source}), falling back to V1", user_id=user_id)
        except Exception as e:
            _log_err(f"V2 unexpected error, falling back to V1: {e}", user_id=user_id, exc=e)

    if not response and not v2_balance_exhausted:
        # ===== المرحلة 1.5: V1 (Silent Fallback عند فشل V2 لأسباب غير الرصيد) =====
        # إذا كان المستخدم اختار V2 لكن V2 فشل، نُجرب V1 بصمت بدون إشعار.
        # المستخدم لن يلاحظ أي تبديل في هذه الحالة (التجربة سلسة كما طلبت).
        try:
            response = ask_wormgpt_v1(actual_query, user_id, is_search_query=use_search)
        except Exception as e:
            _log_err(f"V1 (silent fallback) error: {e}", user_id=user_id, exc=e)

    # ===== المرحلة 2: إذا كان السبب الحقيقي هو نفاد الرصيد، أبلغ المستخدم ثم جرّب V1 =====
    if not response and v2_balance_exhausted:
        try:
            send_message(chat_id, t('v2_balance_exhausted', lang), parse_mode='HTML')
        except Exception as e:
            _log_err(f"Failed to send v2_balance_exhausted notification: {e}", user_id=user_id, exc=e)
        # الآن نُجرب V1
        try:
            response = ask_wormgpt_v1(actual_query, user_id, is_search_query=use_search)
        except Exception as e:
            _log_err(f"V1 (after balance error) error: {e}", user_id=user_id, exc=e)

    # ===== المرحلة 3: فشل كل شيء → عرض زر إعادة المحاولة =====
    if not response:
        try:
            send_message(chat_id, t('err_connection', lang),
                         reply_markup=_retry(lang), parse_mode='HTML')
        except Exception:
            pass
        return

    # ===== تسليم الرد الناجح =====
    if is_code:
        add_to_context(user_id, 'assistant', response[:300])
        formatted_response, code_blocks = format_ai_response_with_codes(response, lang)

        for code_type, code_lang, code in code_blocks:
            if code_type == 'file':
                ext = get_language_extension(code_lang)
                clean = code.strip()
                file_path = save_code_to_file(clean, ext)
                if file_path:
                    try:
                        with open(file_path, 'rb') as fobj:
                            file_label = code_lang.upper() if code_lang else t('generic_file_label', lang)
                            caption = t('code_file_caption', lang, label=file_label, query=query[:50])
                            # copy_button يمرر الكود النظيف (بدون HTML) لزر النسخ
                            send_document(chat_id, fobj, caption=caption, reply_markup=copy_button(clean))
                    except Exception as fe:
                        _log_err(f"Error sending file: {fe}", user_id=user_id, exc=fe)
                    finally:
                        try:
                            os.unlink(file_path)
                        except Exception:
                            pass

        if formatted_response and formatted_response.strip():
            send_typing_effect(chat_id, formatted_response, reply_markup=None,
                               parse_mode='HTML', user_id=user_id)
    else:
        add_to_context(user_id, 'assistant', response[:500])
        formatted_response, _ = format_ai_response_with_codes(response, lang)
        send_typing_effect(chat_id, formatted_response or response,
                           reply_markup=None, parse_mode='HTML', user_id=user_id)



def handle_photo_message(chat_id, user_id, file_id, caption=''):
    """معالجة الصورة المرسلة من المستخدم.
    تعتمد على نموذج البحث المختار:
      - إذا كان user في وضع البحث V2 + رفع صورة → يبدأ البحث بالصور (يحتاج تأكيد النص).
      - إذا كان user في وضع AI (V1/V2) → يحلل الصورة (النظام القديم).

    قواعد المعالجة (المحدّثة):
      - بحث V2 بالصور: متاح فقط لـ VIP / الأدمن.
      - تحليل الصور العادي (AI): أصبح متاحاً لجميع المستخدمين (V1 و V2).
        كان مقصوراً على V2 فقط، الآن تم رفع القيد ليتمكن المستخدم في النموذج الأساسي (V1)
        من تحليل الصور أيضاً (الأزرار الشفافة تظهر وتعمل لجميع المستخدمين).
    """
    from vip_system import get_user_model, is_vip
    from i18n import get_user_language, t
    from bot_logger import log_error as _le

    lang = get_user_language(user_id)
    ai_model = get_user_model(user_id)
    research_model = get_research_model(user_id)

    # ===== فحص هل المستخدم في وضع بحث (waiting_search أو waiting_research_v2_text)؟ =====
    # الكشف التلقائي عن نوع البحث:
    # - إذا رفع صورة مع caption -> ابحث بالصورة + النص مباشرة (بدون سؤال)
    # - إذا رفع صورة فقط -> اطلب منه النص المراد البحث عنه
    is_in_search_state = (
        user_id in user_states and user_states.get(user_id) in (
            'waiting_research_v2_text',
            'waiting_search',
        )
    )

    if research_model == 'research_v2' and (is_in_search_state or (caption and caption.strip())) and can_use_research_v2(user_id):
        # المستخدم في وضع البحث V2 -> البحث بالصور
        try:
            file_info = get_file(file_id)
            if not file_info:
                send_message(chat_id, t('err_connection', lang), parse_mode='HTML')
                return
            file_path = file_info.get('file_path')
            if not file_path:
                send_message(chat_id, t('err_connection', lang), parse_mode='HTML')
                return
            img_bytes = download_file_bytes(file_path)
            if not img_bytes:
                send_message(chat_id, t('err_connection', lang), parse_mode='HTML')
                return
            import base64
            img_b64 = base64.b64encode(img_bytes).decode('utf-8')
            if file_path.lower().endswith('.png'):
                mime = 'image/png'
            elif file_path.lower().endswith('.webp'):
                mime = 'image/webp'
            else:
                mime = 'image/jpeg'

            # تخزين مؤقت للصورة
            research_image_pending[user_id] = {
                'file_id': file_id,
                'mime': mime,
                'b64': img_b64,
                'caption': caption or '',
                'ts': time.time(),
            }

            # إذا وُجد caption: ابدأ البحث فوراً مع الصورة والنص
            if caption and caption.strip():
                handle_research_v2_photo_resume(chat_id, user_id, caption.strip())
                return

            # بدون caption: اطلب من المستخدم إرسال النص
            send_message(chat_id, t('research_v2_image_no_caption', lang),
                          parse_mode='HTML', reply_markup=cancel_search_button(lang))
            user_states[user_id] = 'waiting_research_v2_text'
            return

        except Exception as e:
            _le(f"photo handling for research v2 error: {e}", user_id=user_id, exc=e)
            # في حال الفشل، نُعالجها كصورة تحليل عادية

    # ===== السلوك الافتراضي: تحليل صورة (متاح الآن لجميع المستخدمين V1/V2/Admin) =====
    # تم رفع القيد السابق الذي كان يمنع V1 من تحليل الصور.
    # analyze_image_v2 يستخدم cascade V2 → Fallback → V1، مما يعني أن المستخدمين في النموذج
    # الأساسي (V1) يمكنهم الآن تحليل صورهم وستعمل الأزرار الشفافة (نعم/لا) كما هو مطلوب.

    # إذا أُرسلت صورة مع caption: حلّلها مباشرة بدون سؤال
    if caption and caption.strip():
        photo_pending[user_id] = {'file_id': file_id, 'caption': caption}
        do_analyze_photo(chat_id, user_id, None)
        return

    # إذا أُرسلت صورة بدون caption: خزّنها واسأل المستخدم
    photo_pending[user_id] = {'file_id': file_id, 'caption': ''}
    send_message(
        chat_id,
        t('photo_ask_analyze', lang),
        reply_markup=photo_analyze_buttons(lang),
        parse_mode='HTML'
    )


def do_analyze_photo(chat_id, user_id, message_id):
    """تنفيذ تحليل الصورة بعد تأكيد المستخدم"""
    from i18n import get_user_language, t
    lang = get_user_language(user_id)

    pending = photo_pending.pop(user_id, None)
    if not pending:
        # لا توجد صورة معلقة — أبلغ المستخدم بدلاً من الفشل الصامت (إصلاح الأزرار الشفافة)
        try:
            from telegram_api import edit_message_text
            edit_message_text(chat_id, message_id, t('photo_analyze_error', lang),
                              parse_mode='HTML', reply_markup=main_buttons(lang))
        except Exception:
            send_message(chat_id, t('photo_analyze_error', lang), parse_mode='HTML',
                         reply_markup=main_buttons(lang))
        return

    file_id = pending.get('file_id', '')
    caption = pending.get('caption', '')

    # تعديل رسالة التأكيد → "جاري التحليل..." (إذا وُجد message_id)
    # إذا استُدعيت مباشرة (صورة + نص): أرسل رسالة جديدة
    if message_id:
        try:
            from telegram_api import edit_message_text
            edit_message_text(chat_id, message_id, t('photo_analyzing', lang), parse_mode='HTML')
        except Exception:
            pass
    else:
        try:
            from telegram_api import send_message
            send_message(chat_id, t('photo_analyzing', lang), parse_mode='HTML')
        except Exception:
            pass

    # مؤشر الكتابة
    send_chat_action(chat_id, 'typing')

    def _run():
        result = analyze_image_v2(file_id, caption, user_id)
        if result:
            from ai_engine import send_typing_effect
            send_typing_effect(chat_id, result, parse_mode='HTML', user_id=user_id)
        else:
            send_message(chat_id, t('photo_analyze_error', lang), parse_mode='HTML',
                         reply_markup=main_buttons(lang))

    import threading
    t_thread = threading.Thread(target=_run)
    t_thread.daemon = True
    t_thread.start()


def handle_photo_description_input(chat_id, user_id, text):
    """معالجة الوصف/السؤال الذي يرسله المستخدم بعد الضغط على 'لا شكراً' لتحليل الصورة.
    يُرسل الصورة المخزنة مؤقتاً مع نص الوصف إلى الذكاء الاصطناعي للتحليل."""
    from i18n import get_user_language, t
    from bot_logger import log_error as _le
    from buttons import main_buttons, retry_button
    from telegram_api import send_chat_action, send_message, delete_message
    from ai_engine import analyze_image_v2, send_typing_effect

    lang = get_user_language(user_id)

    # استرجاع الصورة المعلقة
    pending = photo_pending.pop(user_id, None)
    if not pending:
        send_message(chat_id, t('photo_analyze_error', lang), parse_mode='HTML',
                     reply_markup=main_buttons(lang))
        return

    file_id = pending.get('file_id', '')

    # إرسال مؤشر "جاري التحليل..."
    send_chat_action(chat_id, 'typing')

    def _run():
        try:
            result = analyze_image_v2(file_id, text, user_id)
            if result:
                send_typing_effect(chat_id, result, parse_mode='HTML', user_id=user_id)
            else:
                send_message(chat_id, t('photo_analyze_error', lang), parse_mode='HTML',
                             reply_markup=main_buttons(lang))
        except Exception as e:
            _le(f"handle_photo_description_input error: {e}", user_id=user_id, exc=e)
            send_message(chat_id, t('err_connection', lang), parse_mode='HTML',
                         reply_markup=retry_button(lang))

    import threading
    th = threading.Thread(target=_run)
    th.daemon = True
    th.start()


def handle_normal_message(chat_id, user_id, text):
    lang = get_user_language(user_id)

    # ===== الأدمن: لا حد للرسائل ولا وقت انتظار — يُعالَج مباشرة =====
    if user_id in ADMIN:
        increment_message_count(user_id)
        _dispatch_ai_processing(chat_id, user_id, text)
        return

    is_subscribed, channel = subscs(user_id)
    if not is_subscribed and channel:
        send_message(chat_id, t('subscribe_required', lang), reply_markup=not_subscribe_buttons(channel, lang))
        return

    user_is_vip = is_vip(user_id)

    # ===== التحقق من رصيد الرسائل (لغير VIP) =====
    if not user_is_vip:
        remaining = get_messages_left(user_id)
        if remaining <= 0:
            send_message(chat_id, t('quota_exceeded', lang, owner=OWNER_USER),
                         parse_mode='HTML', reply_markup=main_buttons(lang))
            return

    # ===== التحقق من رصيد V2 إذا كان المستخدم يستخدمه =====
    selected_model = get_user_model(user_id)
    if selected_model == 'v2' and not user_is_vip:
        if not has_v2_access(user_id):
            send_message(chat_id, t('v2_trial_exhausted', lang), parse_mode='HTML',
                         reply_markup=main_buttons(lang))
            return

    # ===== عداد إجمالي الرسائل =====
    increment_message_count(user_id)

    # ===== الوقت الفاصل بين الرسائل (25 ثانية للعاديين، بدون وقت لـ VIP) =====
    if not user_is_vip:
        now = time.time()
        last_time = last_message_time.get(user_id, 0)
        elapsed = now - last_time

        if elapsed < COOLDOWN_SECONDS:
            wait_time = COOLDOWN_SECONDS - elapsed
            last_message_time[user_id] = now
            consume_message(user_id)
            if selected_model == 'v2':
                consume_v2_trial(user_id)

            cooldown_resp = send_message(chat_id, t('cooldown_wait', lang, seconds=int(wait_time) + 1), parse_mode='HTML', reply_markup=wait_subscribe_buttons(lang))
            cooldown_msg_id = None
            if cooldown_resp and cooldown_resp.status_code == 200:
                cooldown_msg_id = cooldown_resp.json().get('result', {}).get('message_id')

            def delayed_processing(_wait=wait_time, _cooldown_msg=cooldown_msg_id):
                time.sleep(_wait)
                # حذف رسالة الانتظار فور انتهاء المدة
                if _cooldown_msg:
                    try:
                        delete_message(chat_id, _cooldown_msg)
                    except Exception:
                        pass
                _dispatch_ai_processing(chat_id, user_id, text)

            thread = threading.Thread(target=delayed_processing)
            thread.daemon = True
            thread.start()
            return
        else:
            last_message_time[user_id] = now
            consume_message(user_id)
            if selected_model == 'v2':
                consume_v2_trial(user_id)

    _dispatch_ai_processing(chat_id, user_id, text)


def _dispatch_ai_processing(chat_id, user_id, text):
    """تشغيل معالجة الرسالة: مؤشر كتابة ← معالجة الذكاء الاصطناعي (بدون رسالة انتظار)"""
    from bot_logger import log_error
    lang = get_user_language(user_id)

    # ① مؤشر "يكتب..." الفوري في رأس المحادثة
    send_chat_action(chat_id, "typing")

    model = get_user_model(user_id)
    code_keywords = ['كود', 'code', 'برنامج', 'python', 'سكريبت', 'script']
    is_code = any(kw in text.lower() for kw in code_keywords)

    # ② حدث إيقاف للخيط الفرعي لمؤشر الكتابة
    stop_typing = threading.Event()

    def _keep_typing():
        """إبقاء مؤشر "يكتب..." نشطاً كل 4 ثوانٍ طوال مدة انتظار رد الذكاء الاصطناعي"""
        while not stop_typing.wait(timeout=4):
            try:
                send_chat_action(chat_id, "typing")
            except Exception:
                pass

    _typing_thread = threading.Thread(target=_keep_typing)
    _typing_thread.daemon = True
    _typing_thread.start()

    def run():
        try:
            process_ai_response(chat_id, user_id, text, is_code=is_code, model=model)
        except Exception as e:
            log_error(f"process_ai_response error: {e}", user_id=user_id, exc=e)
            from buttons import retry_button as _rb
            send_message(chat_id, t('err_connection', get_user_language(user_id)),
                         reply_markup=_rb(get_user_language(user_id)), parse_mode='HTML')
        finally:
            # إيقاف مؤشر الكتابة فقط
            stop_typing.set()

    thread = threading.Thread(target=run)
    thread.daemon = True
    thread.start()

def handle_search(chat_id, user_id, query):
    """بحث نصي عبر WORMGPT-research-V1 (DuckDuckGo). متاح للجميع.
    هذا الـ handler يُستدعى بعد اختيار 'بحث كلام' في القائمة، أو في حالة الـ V1 الافتراضية.
    لا يستخدم context - DuckDuckGo يبحث مباشرة في الإنترنت."""
    lang = get_user_language(user_id)
    is_subscribed, channel = subscs(user_id)
    if not is_subscribed and channel:
        send_message(chat_id, t('subscribe_required', lang), reply_markup=not_subscribe_buttons(channel, lang))
        return

    if not query:
        send_message(chat_id, t('search_prompt', lang), parse_mode='HTML')
        return

    # ===== فحص الاشتراك في VIP إذا كان يبحث V2 =====
    research_model = get_research_model(user_id)
    if research_model == 'research_v2' and not can_use_research_v2(user_id):
        # المستخدم غير VIP و V2 متاح فقط لهم -> تجاهل بصمت وارجع إلى V1
        set_research_model(user_id, 'research_v1')
        research_model = 'research_v1'

    # ===== اشترك في الـ V2 =====
    if research_model == 'research_v2':
        # استخدام ask_wormgpt_research_v2 (يدعم الصور أيضاً)
        # زر الإلغاء + مؤشر كتابة
        cancel_msg = send_message(
            chat_id, t('search_in_progress', lang),
            parse_mode='HTML', reply_markup=cancel_search_button(lang)
        )
        cancel_msg_id = None
        try:
            if cancel_msg and cancel_msg.status_code == 200:
                cancel_msg_id = cancel_msg.json().get('result', {}).get('message_id')
        except Exception:
            pass
        # المعالجة في thread منفصل لاحترام الضغط على زر الإلغاء
        import threading as _threading
        stop_event = _threading.Event()

        def _v2_search():
            try:
                reply = ask_wormgpt_research_v2(query, user_id=user_id)
                # حذف زر الإلغاء أولاً
                if cancel_msg_id:
                    try:
                        delete_message(chat_id, cancel_msg_id)
                    except Exception:
                        pass
                if reply:
                    send_typing_effect(chat_id, reply, reply_markup=None, parse_mode='HTML', user_id=user_id)
                else:
                    send_message(chat_id, t('err_connection', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
            except Exception as e:
                from bot_logger import log_error as _le
                _le(f"research_v2 chat error: {e}", user_id=user_id, exc=e)
                if cancel_msg_id:
                    try:
                        delete_message(chat_id, cancel_msg_id)
                    except Exception:
                        pass
                send_message(chat_id, t('err_connection', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
            finally:
                stop_event.set()

        th = _threading.Thread(target=_v2_search)
        th.daemon = True
        th.start()
        return

    # ===== بحث V1 (DuckDuckGo) - للجميع =====
    # إرسال رسالة "جاري البحث..." مع زر الإلغاء الأحمر
    cancel_msg = send_message(
        chat_id, t('search_in_progress', lang),
        parse_mode='HTML', reply_markup=cancel_search_button(lang)
    )
    cancel_msg_id = None
    try:
        if cancel_msg and cancel_msg.status_code == 200:
            cancel_msg_id = cancel_msg.json().get('result', {}).get('message_id')
    except Exception:
        pass

    try:
        results = search_web(query, 6)
        formatted = format_search_results(results, query, lang)
        # حذف زر الإلغاء قبل إرسال النتيجة
        if cancel_msg_id:
            try:
                delete_message(chat_id, cancel_msg_id)
            except Exception:
                pass
        if not results:
            send_message(chat_id, formatted, parse_mode='HTML')
        else:
            send_typing_effect(chat_id, formatted, reply_markup=None, parse_mode='HTML')
    except Exception as e:
        from bot_logger import log_error as _le
        _le(f"handle_search v1 error: {e}", user_id=user_id, exc=e)
        if cancel_msg_id:
            try:
                delete_message(chat_id, cancel_msg_id)
            except Exception:
                pass
        send_message(chat_id, t('err_connection', lang), parse_mode='HTML', reply_markup=main_buttons(lang))


def handle_research_v2_photo_resume(chat_id, user_id, text):
    """يُستدعى عندما يرسل المستخدم نصاً بعد رفع صورة لبحث V2.
    يستخدم الصورة المعلقة المخزنة في research_image_pending + نص الرسالة.
    (إذا رفع صورة بدون caption كان قد تم تخزينها في research_image_pending قبل ظهور هذه الدالة)."""
    from bot_logger import log_error as _le
    lang = get_user_language(user_id)

    pending = research_image_pending.pop(user_id, None)
    if not pending:
        # لا توجد صورة معلقة - تجاهل
        send_message(chat_id, t('main_menu_title', lang), reply_markup=main_buttons(lang), parse_mode='HTML')
        return

    # تحقق اشتراك / حالة VIP (احتياط)
    user_is_vip = is_vip(user_id)
    if not can_use_research_v2(user_id):
        # المستخدم العادي لا ينبغي أن يصل إلى هنا (تم التحقق مسبقاً)، لكنه احتياط
        send_message(chat_id, t('research_v2_vip_only', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
        return

    # تحقق رصيد الرسائل
    if not user_is_vip:
        remaining = get_messages_left(user_id)
        if remaining <= 0:
            send_message(chat_id, t('quota_exceeded', lang, owner=OWNER_USER),
                         parse_mode='HTML', reply_markup=main_buttons(lang))
            return

    increment_message_count(user_id)
    if not user_is_vip:
        consume_message(user_id)

    # إرسال رسالة البحث مع زر الإلغاء الأحمر
    cancel_msg = send_message(
        chat_id, t('search_in_progress', lang),
        parse_mode='HTML', reply_markup=cancel_search_button(lang)
    )
    cancel_msg_id = None
    try:
        if cancel_msg and cancel_msg.status_code == 200:
            cancel_msg_id = cancel_msg.json().get('result', {}).get('message_id')
    except Exception:
        pass

    image_b64 = pending.get('b64', '')
    image_mime = pending.get('mime', 'image/jpeg')

    import threading as _threading
    def _run():
        try:
            reply = ask_wormgpt_research_v2(
                text.strip(),
                user_id=user_id,
                image_b64=image_b64,
                image_mime=image_mime,
            )
            # حذف زر الإلغاء قبل إرسال الرد
            if cancel_msg_id:
                try:
                    delete_message(chat_id, cancel_msg_id)
                except Exception:
                    pass
            if reply:
                send_typing_effect(chat_id, reply, reply_markup=None, parse_mode='HTML', user_id=user_id)
            else:
                send_message(chat_id, t('err_connection', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
        except Exception as e:
            _le(f"research_v2 photo+text error: {e}", user_id=user_id, exc=e)
            if cancel_msg_id:
                try:
                    delete_message(chat_id, cancel_msg_id)
                except Exception:
                    pass
            send_message(chat_id, t('err_connection', lang), parse_mode='HTML', reply_markup=main_buttons(lang))

    th = _threading.Thread(target=_run)
    th.daemon = True
    th.start()

def handle_clear(chat_id, user_id):
    lang = get_user_language(user_id)
    clear_context(user_id)
    send_message(chat_id, t('clear_confirm', lang), parse_mode='HTML', reply_markup=main_buttons(lang))

def handle_info(chat_id, user_id):
    lang = get_user_language(user_id)
    is_subscribed, channel = subscs(user_id)
    if not is_subscribed and channel:
        send_message(chat_id, t('subscribe_required', lang), reply_markup=not_subscribe_buttons(channel, lang))
        return
    
    text = t('info_text', lang, owner=OWNER_USER, channel=CHANNEL)
    
    send_message(chat_id, text, parse_mode='HTML', reply_markup=main_buttons(lang))

def handle_admin(chat_id, user_id):
    if user_id not in ADMIN:
        from i18n import get_user_language as _gl
        send_message(chat_id, t('err_not_admin', _gl(user_id)), parse_mode='HTML')
        return

    send_message(chat_id, t('admin_panel_title', get_user_language(user_id)), parse_mode='HTML', reply_markup=admin_buttons(get_user_language(user_id)))

# ========================================================================
#                      أمر تغيير اللغة وتدفق التواصل مع الدعم
# ========================================================================

def handle_language_command(chat_id, user_id):
    """أمر /language: عرض أزرار اختيار اللغة"""
    lang = get_user_language(user_id)
    send_message(chat_id, t('language_picker_prompt', lang), parse_mode='HTML', reply_markup=language_picker_buttons(lang))

def handle_support_message_input(chat_id, user_id, username, first_name, message):
    """معالجة رسالة الدعم المرسلة من المستخدم (نص/صورة/فيديو/كليهما) وتمريرها للأدمن، مع معلومات
    إضافية عن المُرسل: حالة الاشتراك (عادي/VIP)، صورة الحساب (إن توفرت)، وتوقيت الإرسال،
    وزر "رد على الرسالة" تحت الرسالة المُمررة لتسهيل رد الأدمن المباشر على هذا المستخدم بالتحديد"""
    lang = get_user_language(user_id)
    message_id = message.get('message_id')
    
    has_content = any([
        message.get('text'), message.get('caption'), message.get('photo'),
        message.get('video'), message.get('document'), message.get('voice'),
        message.get('animation'), message.get('sticker')
    ])
    
    if not has_content or not message_id:
        send_message(chat_id, t('support_invalid', lang), parse_mode='HTML', reply_markup=cancel_button())
        return
    
    user_states.pop(user_id, None)

    username_display = f"@{username}" if username else "—"
    if is_vip(user_id):
        status_display = t('status_vip_active', lang, expiry=get_vip_expiry_text(user_id))
    else:
        status_display = t('status_normal_user', lang)
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    header = t('admin_support_forward_header', lang, name=first_name, username=username_display, user_id=user_id, status=status_display, timestamp=timestamp)

    photo_file_id = get_best_profile_photo_file_id(user_id)
    reply_button = {
        "inline_keyboard": [
            [{"text": t('btn_support_reply', lang), "callback_data": f"support_reply_{user_id}", "style": "primary"}]
        ]
    }

    for admin_id in ADMIN:
        try:
            admin_lang = get_user_language(admin_id)
            send_message(admin_id, header, parse_mode='HTML')
            if photo_file_id:
                send_photo(admin_id, photo_file_id, caption=t('admin_support_photo_caption', admin_lang), parse_mode='HTML')
            copy_message(admin_id, chat_id, message_id, reply_markup=reply_button)
        except Exception as e:
            print(f"Error forwarding support message to admin {admin_id}: {e}")

    send_message(chat_id, t('support_sent_confirmation', lang), parse_mode='HTML', reply_markup=main_buttons(lang))

def handle_support_reply_input(chat_id, admin_id, message):
    """معالجة رد الأدمن على مستخدم تواصل مع الدعم (نص/صورة/فيديو/كليهما) وإرساله للمستخدم المستهدف"""
    message_id = message.get('message_id')
    target_user_id = admin_context.get(admin_id, {}).get('support_reply_target')
    admin_lang = get_user_language(admin_id)

    if not target_user_id:
        send_message(chat_id, t('support_reply_no_target', admin_lang), parse_mode='HTML', reply_markup=admin_buttons(admin_lang))
        user_states.pop(admin_id, None)
        admin_context.pop(admin_id, None)
        return

    has_content = any([
        message.get('text'), message.get('caption'), message.get('photo'),
        message.get('video'), message.get('document'), message.get('voice'),
        message.get('animation'), message.get('sticker')
    ])

    if not has_content or not message_id:
        send_message(chat_id, t('support_reply_invalid', admin_lang), parse_mode='HTML', reply_markup=cancel_button())
        return

    user_states.pop(admin_id, None)
    admin_context.pop(admin_id, None)

    target_lang = get_user_language(target_user_id)
    try:
        send_message(int(target_user_id), t('support_reply_header', target_lang), parse_mode='HTML')
        copy_message(int(target_user_id), chat_id, message_id)
        send_message(chat_id, t('support_reply_sent', admin_lang), parse_mode='HTML', reply_markup=admin_buttons(admin_lang))
    except Exception as e:
        print(f"Error sending support reply to user {target_user_id}: {e}")
        send_message(chat_id, t('support_reply_failed', admin_lang), parse_mode='HTML', reply_markup=admin_buttons(admin_lang))


def show_account_info(chat_id, user_id, message_id, lang):
    """عرض لوحة معلومات حساب المستخدم: الصورة (إن توفرت)، الايدي، اليوزر، حالة الاشتراك،
    الرسائل المتبقية، إجمالي الرسائل المرسلة، وتاريخ الانضمام"""
    user_data = data.get(str(user_id), {})
    username = user_data.get('username', '')
    username_display = f"@{username}" if username else "—"
    
    if is_vip(user_id):
        status_line = t('vip_status_active', lang, expiry=get_vip_expiry_text(user_id))
        messages_left_display = '∞'
    else:
        status_line = t('vip_status_inactive', lang)
        messages_left_display = str(get_messages_left(user_id))
    
    total_sent = user_data.get('total_messages_sent', 0)
    joined_at = user_data.get('joined_at', '—')
    
    body = t(
        'account_info_panel', lang,
        user_id=user_id, username=username_display, status_line=status_line,
        messages_left=messages_left_display, total_sent=total_sent, joined_at=joined_at
    )
    
    photo_file_id = get_best_profile_photo_file_id(user_id)
    if photo_file_id:
        send_photo(chat_id, photo_file_id, caption=body, parse_mode='HTML', reply_markup=cancel_button())
    else:
        edit_message_text(chat_id, message_id, body, parse_mode='HTML', reply_markup=cancel_button())


# ========================================================================
#   ميزة رفع الملفات (V2 File Upload Feature)
# ========================================================================

def _get_supported_extensions_text(lang):
    """تُعيد قائمة الامتدادات المدعومة كسطر واحد قابل للقراءة، بصياغة ملائمة للغة الواجهة"""
    # رتب الامتدادات أبجدياً لتكون القراءة موحدة
    exts = sorted(SUPPORTED_FILE_EXTENSIONS)
    return ' '.join(f"<code>{e}</code>" for e in exts)


def _is_supported_file(file_name):
    """هل اسم الملف ينتهي بامتداد مدعوم؟"""
    if not file_name:
        return False, ''
    file_name_lower = file_name.lower()
    for ext in SUPPORTED_FILE_EXTENSIONS:
        if file_name_lower.endswith(ext):
            return True, ext
    return False, ''


def _decode_file_bytes(raw_bytes):
    """محاولة فك ترميز بايتات الملف كنص UTF-8، مع التراجع عن المحاولات عند الفشل.
    تُعيد النص أو None إذا تعذّرت القراءة (ملف ثنائي أو مشفّر)."""
    if not raw_bytes:
        return None
    # تجربة UTF-8 أولاً
    try:
        return raw_bytes.decode('utf-8')
    except UnicodeDecodeError:
        pass
    # تجربة UTF-8 مع تجاهل الأخطاء (يحافظ على أكبر قدر من المحتوى النصي)
    try:
        return raw_bytes.decode('utf-8', errors='replace')
    except Exception:
        pass
    # تجربة latin-1 كحل أخير (تعمل دائماً على بايتات)
    try:
        return raw_bytes.decode('latin-1')
    except Exception:
        return None


def handle_document_message(chat_id, user_id, file_id, file_name, file_size=0, caption=''):
    """معالجة ملف مرفوع من المستخدم. يدعم ملفات الأكواد والنصوص بإمتدادات محددة.
    - يفحص الامتداد
    - يفحص حجم الملف
    - يحمّل المحتوى ويحسب الأسطر
    - يرفض الملفات الأكبر من FILE_MAX_LINES
    - يخزن الملف في file_pending و يطلب من المستخدم إرسال التعليم (إلا إذا كان الملف مصحوباً بـ caption)"""
    from bot_logger import log_error as _log_err
    lang = get_user_language(user_id)
    
    # 1) فحص الاشتراك في القناة (نفس قواعد الرسائل الأخرى)
    is_subscribed, channel = subscs(user_id)
    if not is_subscribed and channel:
        send_message(chat_id, t('subscribe_required', lang), reply_markup=not_subscribe_buttons(channel, lang))
        return
    
    # 2) فحص رصيد الرسائل (لغير VIP)
    user_is_vip = is_vip(user_id)
    if not user_is_vip:
        remaining = get_messages_left(user_id)
        if remaining <= 0:
            send_message(chat_id, t('quota_exceeded', lang, owner=OWNER_USER),
                         parse_mode='HTML', reply_markup=main_buttons(lang))
            return
    
    # 3) فحص رصيد V2 عند الحاجة
    selected_model = get_user_model(user_id)
    if selected_model == 'v2' and not user_is_vip:
        if not has_v2_access(user_id):
            send_message(chat_id, t('v2_trial_exhausted', lang), parse_mode='HTML',
                         reply_markup=main_buttons(lang))
            return
    
    # 4) فحص الامتداد المدعوم
    supported, ext = _is_supported_file(file_name)
    if not supported:
        # مسح أي ملف معلق سابقاً — المستخدم رفع ملفاً جديداً، حتى لو رُفض
        file_pending.pop(user_id, None)
        user_states.pop(user_id, None)
        supported_list = _get_supported_extensions_text(lang)
        send_message(
            chat_id,
            t('file_type_unsupported', lang, file_name=file_name or '—', ext=(file_name or '').split('.')[-1] if '.' in (file_name or '') else '—',
               supported_list=supported_list),
            parse_mode='HTML',
            reply_markup=main_buttons(lang)
        )
        return

    # 5) فحص الحجم الأقصى (حماية من الملفات الضخمة)
    if file_size and file_size > 200_000:
        file_pending.pop(user_id, None)
        user_states.pop(user_id, None)
        send_message(
            chat_id,
            t('file_too_large', lang, file_name=file_name or '—', line_count='—', max_lines=FILE_MAX_LINES),
            parse_mode='HTML',
            reply_markup=main_buttons(lang)
        )
        return
    
    # 6) تنزيل محتوى الملف
    try:
        file_info = get_file(file_id)
        if not file_info:
            send_message(chat_id, t('file_read_error', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
            return
        file_path_remote = file_info.get('file_path')
        if not file_path_remote:
            send_message(chat_id, t('file_read_error', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
            return
        raw_bytes = download_file_bytes(file_path_remote)
        if not raw_bytes:
            send_message(chat_id, t('file_read_error', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
            return
    except Exception as e:
        _log_err(f"handle_document_message download error: {e}", user_id=user_id, exc=e)
        send_message(chat_id, t('file_read_error', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
        return
    
    # 7) فك ترميز المحتوى
    content = _decode_file_bytes(raw_bytes)
    if content is None:
        send_message(chat_id, t('file_read_error', lang), parse_mode='HTML', reply_markup=main_buttons(lang))
        return
    
    # 8) حساب عدد الأسطر
    line_count = content.count('\n') + (1 if content and not content.endswith('\n') else 0)
    if not content:
        line_count = 0
    
    # 9) فحص الحد الأقصى للأسطر
    if line_count > FILE_MAX_LINES:
        file_pending.pop(user_id, None)
        user_states.pop(user_id, None)
        send_message(
            chat_id,
            t('file_too_large', lang, file_name=file_name or '—', line_count=line_count, max_lines=FILE_MAX_LINES),
            parse_mode='HTML',
            reply_markup=main_buttons(lang)
        )
        return
    
    # 10) استلام ناجح: تخزين المحتوى في file_pending
    file_pending[user_id] = {
        'file_id': file_id,
        'file_name': file_name or f'file{ext}',
        'content': content,
        'line_count': line_count,
        'extension': ext,
        'caption': caption or '',
    }
    
    # 11) إن كان الملف مصحوباً بـ caption، عالجه فوراً بدون طلب تعليم منفصل
    if caption and caption.strip():
        increment_message_count(user_id)
        if not user_is_vip:
            consume_message(user_id)
            if selected_model == 'v2':
                consume_v2_trial(user_id)
        send_message(
            chat_id,
            t('file_caption_used', lang, file_name=file_name, line_count=line_count, instruction=caption.strip()),
            parse_mode='HTML'
        )
        _process_file_with_ai(chat_id, user_id, caption.strip())
        return
    
    # 12) بدون caption: اطلب من المستخدم إرسال التعليم
    user_states[user_id] = 'waiting_file_instruction'
    send_message(
        chat_id,
        t('file_upload_welcome', lang, file_name=file_name, line_count=line_count),
        parse_mode='HTML',
        reply_markup=cancel_button()
    )


def handle_file_instruction_input(chat_id, user_id, text):
    """معالجة رسالة التعليم التي يرسلها المستخدم بعد رفع ملف (بدون caption).
    تُرسل محتوى الملف + التعليم إلى الذكاء الاصطناعي."""
    from bot_logger import log_error as _log_err
    lang = get_user_language(user_id)
    
    pending = file_pending.get(user_id)
    if not pending:
        # لا يوجد ملف معلق — إنهاء الحالة والعودة للقائمة الرئيسية
        user_states.pop(user_id, None)
        send_message(chat_id, t('main_menu_title', lang), reply_markup=main_buttons(lang), parse_mode='HTML')
        return
    
    # تنظيف الحالة (تم استلام التعليم)
    user_states.pop(user_id, None)
    
    # التحقق من الرصيد أيضاً (لأن المستخدم قد استهلك رصيده منذ رفع الملف)
    user_is_vip = is_vip(user_id)
    if not user_is_vip:
        remaining = get_messages_left(user_id)
        if remaining <= 0:
            file_pending.pop(user_id, None)
            send_message(chat_id, t('quota_exceeded', lang, owner=OWNER_USER),
                         parse_mode='HTML', reply_markup=main_buttons(lang))
            return
    
    selected_model = get_user_model(user_id)
    if selected_model == 'v2' and not user_is_vip:
        if not has_v2_access(user_id):
            file_pending.pop(user_id, None)
            send_message(chat_id, t('v2_trial_exhausted', lang), parse_mode='HTML',
                         reply_markup=main_buttons(lang))
            return
    
    increment_message_count(user_id)
    if not user_is_vip:
        consume_message(user_id)
        if selected_model == 'v2':
            consume_v2_trial(user_id)
    
    send_message(
        chat_id,
        t('file_processing_started', lang, file_name=pending['file_name'], instruction=text.strip()),
        parse_mode='HTML'
    )
    _process_file_with_ai(chat_id, user_id, text.strip())


def _process_file_with_ai(chat_id, user_id, instruction):
    """إرسال محتوى الملف + تعليم المستخدم إلى الذكاء الاصطناعي.
    يبني prompt واضحاً مع علامات [FILE] و [INSTRUCTION] ليعرف الـ API حدود كل قسم."""
    from bot_logger import log_error as _log_err
    lang = get_user_language(user_id)
    pending = file_pending.pop(user_id, None)
    if not pending:
        return
    
    model = get_user_model(user_id)
    file_name = pending.get('file_name', 'file')
    content = pending.get('content', '')
    line_count = pending.get('line_count', 0)
    extension = pending.get('extension', '')
    
    # بناء الـ prompt بصيغة واضحة يفهمها الذكاء الاصطناعي
    combined_prompt = (
        f"[FILE_UPLOAD]\n"
        f"filename: {file_name}\n"
        f"lines: {line_count}\n"
        f"extension: {extension}\n"
        f"--- BEGIN FILE CONTENT ---\n"
        f"{content}\n"
        f"--- END FILE CONTENT ---\n"
        f"[USER_INSTRUCTION]\n"
        f"{instruction}"
    )
    
    # إضافة إلى السياق باسم الملف كجزء من رسالة المستخدم
    context_entry = f"[ملف: {file_name} ({line_count} سطر)] {instruction}"
    add_to_context(user_id, 'user', context_entry[:500])
    
    # مؤشر كتابة
    send_chat_action(chat_id, "typing")
    stop_typing = threading.Event()
    
    def _keep_typing():
        while not stop_typing.wait(timeout=4):
            try:
                send_chat_action(chat_id, "typing")
            except Exception:
                pass
    
    typing_thread = threading.Thread(target=_keep_typing)
    typing_thread.daemon = True
    typing_thread.start()
    
    def _run_ai():
        try:
            # نظام التبديل التلقائي الكامل: V2 → Fallback URLs → V1
            response = None
            v2_balance_exhausted = False
            if model == 'v2':
                try:
                    response = ask_wormgpt_v2(combined_prompt, user_id, is_search_query=False)
                except NoBalanceError as nbe:
                    v2_balance_exhausted = True
                    _log_err(f"V2 balance exhausted (file upload, source={nbe.source})", user_id=user_id)
                except Exception as e:
                    _log_err(f"V2 (file upload) error: {e}", user_id=user_id, exc=e)

            if not response and not v2_balance_exhausted:
                try:
                    response = ask_wormgpt_v1(combined_prompt, user_id, is_search_query=False)
                except Exception as e:
                    _log_err(f"V1 (file upload, silent fallback) error: {e}", user_id=user_id, exc=e)

            if not response and v2_balance_exhausted:
                try:
                    send_message(chat_id, t('v2_balance_exhausted', lang), parse_mode='HTML')
                except Exception:
                    pass
                try:
                    response = ask_wormgpt_v1(combined_prompt, user_id, is_search_query=False)
                except Exception as e:
                    _log_err(f"V1 (file upload, after balance) error: {e}", user_id=user_id, exc=e)

            if not response:
                send_message(chat_id, t('err_connection', lang), parse_mode='HTML',
                             reply_markup=retry_button(lang))
                return
            add_to_context(user_id, 'assistant', response[:500])
            formatted_response, _ = format_ai_response_with_codes(response, lang)
            send_typing_effect(chat_id, formatted_response or response, parse_mode='HTML', user_id=user_id)
        except Exception as e:
            _log_err(f"_process_file_with_ai error: {e}", user_id=user_id, exc=e)
            send_message(chat_id, t('err_connection', lang), parse_mode='HTML',
                         reply_markup=retry_button(lang))
        finally:
            stop_typing.set()
    
    thread = threading.Thread(target=_run_ai)
    thread.daemon = True
    thread.start()

