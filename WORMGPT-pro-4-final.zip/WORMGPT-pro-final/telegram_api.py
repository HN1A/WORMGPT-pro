import re
import json
from config import session, URL

# ========================================================================
#                 تحسين تنسيق رسائل Telegram (المطلوب 6)
# ========================================================================

# أنماط اكتشاف الروابط (HTTP/HTTPS + domain، وروابط تيليجرام t.me/...)
_URL_RE = re.compile(
    r'(https?://[^\s<>"\')\]]+|t\.me/\w+|telegram\.me/\w+|@\w+)',
    re.IGNORECASE
)
# أنماط تحسين التنسيق — تحويل العناوين التلقائية إلى <b>...</b>
_HEADER_RE = re.compile(r'^(#{1,6})\s+(.+)$', re.MULTILINE)
# أنماط القوائم — تحويل "- item" أو "* item" إلى "• item"
_LIST_RE = re.compile(r'^[\-\*]\s+(.+)$', re.MULTILINE)


def auto_link_urls(text):
    """يكتشف الروابط في النص ويحوّلها إلى وسوم HTML <a href=...> إن لم تكن مُحوّلة مسبقاً.
    
    يتحقق من:
    1) الروابط ليست داخل وسم <a> مسبقاً
    2) الروابط ليست داخل وسم <code> أو <pre>
    3) يدعم روابط HTTP/HTTPS وروابط Telegram (t.me/...) ومعرفات @username
    """
    if not text or '<a href=' in text:
        return text
    
    def _replace_url(match):
        url = match.group(0)
        # تخطي إذا كان داخل وسم HTML
        return f'<a href="{url}">{url}</a>'
    
    # استبدال بسيط: نتجنب الاستبدال داخل وسوم HTML
    # تقسيم النص إلى أجزاء: وسوم HTML vs نص عادي
    parts = re.split(r'(<[^>]+>)', text)
    result = []
    for part in parts:
        if part.startswith('<') and part.endswith('>'):
            # وسم HTML — نتركه كما هو
            result.append(part)
        else:
            # نص عادي — نكتشف الروابط
            result.append(_URL_RE.sub(lambda m: f'<a href="{m.group(0)}">{m.group(0)}</a>', part))
    return ''.join(result)


def format_telegram_message(text, auto_link=True, enhance_markdown=True):
    """تُحسّن تنسيق رسالة Telegram بشكل شامل:
    
    1. <b>auto_link</b>: اكتشاف الروابط التلقائي وتحويلها لوسوم <a href>
    2. <b>enhance_markdown</b>: تحسين التنسيق العام (عناوين، قوائم، إلخ)
    
    يُستخدم في جميع دوال الإرسال (send_message, edit_message_text, إلخ)
    لضمان توافق الرسائل مع أحدث Telegram Bot API.
    """
    if not text:
        return text
    
    if enhance_markdown:
        # تحسين العناوين: ## Title → <b>Title</b>
        text = _HEADER_RE.sub(lambda m: f'<b>{m.group(2)}</b>', text)
        # تحسين القوائم: - item → • item
        text = _LIST_RE.sub(lambda m: f'• {m.group(1)}', text)
    
    if auto_link:
        text = auto_link_urls(text)
    
    return text


# ========================================================================
#                      دوال إرسال الرسائل (مُحسَّنة)
# ========================================================================

def send_message(chat_id, text, reply_markup=None, parse_mode='HTML', disable_web_page_preview=False):
    # تحسين التنسيق تلقائياً (المطلوب 6)
    if parse_mode == 'HTML' and text:
        text = format_telegram_message(text)
    payload = {
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": disable_web_page_preview
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    
    try:
        return session.post(f"{URL}/sendMessage", json=payload)
    except Exception as e:
        print(f"Error sending message: {e}")
        return None

def send_photo(chat_id, photo, caption=None, reply_markup=None, parse_mode='HTML'):
    # تحسين تنسيق التعليق تلقائياً (المطلوب 6)
    if parse_mode == 'HTML' and caption:
        caption = format_telegram_message(caption)
    payload = {
        "chat_id": chat_id,
        "photo": photo
    }
    if caption:
        payload["caption"] = caption
    if reply_markup:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    
    try:
        return session.post(f"{URL}/sendPhoto", json=payload)
    except Exception as e:
        print(f"Error sending photo: {e}")
        return None

def send_document(chat_id, document, caption=None, reply_markup=None):
    files = {'document': document}
    data = {'chat_id': chat_id}
    if caption:
        data['caption'] = caption
    if reply_markup:
        data['reply_markup'] = json.dumps(reply_markup)
    
    try:
        return session.post(f"{URL}/sendDocument", data=data, files=files)
    except Exception as e:
        print(f"Error sending document: {e}")
        return None

def edit_message_text(chat_id, message_id, text, reply_markup=None, parse_mode='HTML'):
    # تحسين التنسيق تلقائياً (المطلوب 6)
    if parse_mode == 'HTML' and text:
        text = format_telegram_message(text)
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    
    try:
        response = session.post(f"{URL}/editMessageText", json=payload)
        # إذا كانت الرسالة الأصلية صورة/فيديو (تحتوي على caption لا على نص)، تلجرام يرفض editMessageText
        # برسالة "there is no text in the message to edit" - في هذه الحالة يجب استخدام editMessageCaption بدلاً منه
        # (هذا هو سبب عدم عمل بعض الأزرار عند الضغط عليها من رسالة الترحيب التي تُرسل كصورة)
        if response is not None and response.status_code != 200:
            try:
                description = response.json().get('description', '')
            except Exception:
                description = ''
            if 'no text in the message to edit' in description.lower():
                return edit_message_caption(chat_id, message_id, text, reply_markup=reply_markup, parse_mode=parse_mode)
        return response
    except Exception as e:
        print(f"Error editing message: {e}")
        return None

def edit_message_caption(chat_id, message_id, caption, reply_markup=None, parse_mode='HTML'):
    # تحسين تنسيق التعليق تلقائياً (المطلوب 6)
    if parse_mode == 'HTML' and caption:
        caption = format_telegram_message(caption)
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "caption": caption
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    
    try:
        return session.post(f"{URL}/editMessageCaption", json=payload)
    except Exception as e:
        print(f"Error editing caption: {e}")
        return None

def send_invoice(chat_id, title, description, payload, amount_stars):
    """إرسال فاتورة دفع عبر نجوم تلجرام (XTR) - عملة نجوم تلجرام لا تحتاج إلى provider_token"""
    try:
        return session.post(f"{URL}/sendInvoice", json={
            "chat_id": chat_id,
            "title": title,
            "description": description,
            "payload": payload,
            "provider_token": "",
            "currency": "XTR",
            "prices": [{"label": title, "amount": amount_stars}]
        })
    except Exception as e:
        print(f"Error sending invoice: {e}")
        return None

def answer_callback_query(callback_id, text=None, show_alert=False):
    payload = {"callback_query_id": callback_id}
    if text:
        payload["text"] = text
        payload["show_alert"] = show_alert
    
    try:
        return session.post(f"{URL}/answerCallbackQuery", json=payload)
    except Exception as e:
        print(f"Error answering callback: {e}")
        return None

def delete_message(chat_id, message_id):
    try:
        return session.post(f"{URL}/deleteMessage", json={"chat_id": chat_id, "message_id": message_id})
    except Exception as e:
        print(f"Error deleting message: {e}")
        return None

def copy_message(chat_id, from_chat_id, message_id, reply_markup=None):
    """نسخ رسالة (نص/صورة/فيديو/أي نوع) من محادثة إلى أخرى - تُستخدم لتمرير رسائل الدعم والإذاعة،
    مع إمكانية إضافة أزرار شفافة اختيارية تحت الرسالة المنسوخة (مثل زر "رد على الرسالة")"""
    payload = {
        "chat_id": chat_id,
        "from_chat_id": from_chat_id,
        "message_id": message_id
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        return session.post(f"{URL}/copyMessage", json=payload)
    except Exception as e:
        print(f"Error copying message: {e}")
        return None

def pin_chat_message(chat_id, message_id, disable_notification=True):
    """تثبيت رسالة في محادثة معينة (تُستخدم اختيارياً بعد الإذاعة)"""
    try:
        return session.post(f"{URL}/pinChatMessage", json={
            "chat_id": chat_id,
            "message_id": message_id,
            "disable_notification": disable_notification
        })
    except Exception as e:
        print(f"Error pinning message: {e}")
        return None

def delete_message(chat_id, message_id):
    """حذف رسالة من المحادثة — تُستخدم لحذف رسالة الانتظار بعد انتهاء معالجة الذكاء الاصطناعي"""
    try:
        return session.post(f"{URL}/deleteMessage", json={
            "chat_id": chat_id,
            "message_id": message_id
        })
    except Exception as e:
        print(f"Error deleting message: {e}")
        return None

def get_file(file_id):
    """استخراج معلومات الملف (مسار التنزيل) من تيليجرام"""
    try:
        resp = session.get(f"{URL}/getFile", params={"file_id": file_id})
        if resp.status_code == 200:
            return resp.json().get('result', {})
    except Exception as e:
        print(f"Error getFile: {e}")
    return None


def download_file_bytes(file_path):
    """تنزيل محتوى الملف كـ bytes من خوادم تيليجرام"""
    try:
        token = URL.split('/bot')[1].split('/')[0]
        url = f"https://api.telegram.org/file/bot{token}/{file_path}"
        resp = session.get(url, timeout=30)
        if resp.status_code == 200:
            return resp.content
    except Exception as e:
        print(f"Error download_file_bytes: {e}")
    return None


def get_user_profile_photos(user_id, limit=1):
    """جلب صور حساب مستخدم تلجرام (تُستخدم في لوحة معلومات الحساب وفي رسائل الدعم للأدمن)"""
    try:
        response = session.get(f"{URL}/getUserProfilePhotos", params={"user_id": user_id, "limit": limit})
        return response.json()
    except Exception as e:
        print(f"Error fetching profile photos: {e}")
        return None

def get_best_profile_photo_file_id(user_id):
    """استخراج file_id لأكبر نسخة من أحدث صورة حساب متوفرة لمستخدم معين، أو None إذا لم تتوفر صورة
    (المستخدم بلا صورة حساب، أو إعدادات الخصوصية تمنع البوت من الوصول إليها)"""
    photos_data = get_user_profile_photos(user_id, limit=1)
    if not photos_data or not photos_data.get('ok'):
        return None
    result = photos_data.get('result', {})
    if result.get('total_count', 0) <= 0:
        return None
    photo_sizes_list = result.get('photos', [])
    if not photo_sizes_list or not photo_sizes_list[0]:
        return None
    return photo_sizes_list[0][-1].get('file_id')

def send_chat_action(chat_id, action):
    try:
        return session.post(f"{URL}/sendChatAction", json={"chat_id": chat_id, "action": action})
    except Exception as e:
        print(f"Error sending action: {e}")
        return None

