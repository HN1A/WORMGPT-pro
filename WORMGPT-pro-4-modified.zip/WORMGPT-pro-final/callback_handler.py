import threading
from config import (ADMIN, CHANNEL, OWNER_NAME, OWNER_USER, STARS_PRICES, DURATION_LABELS,
                     admin_context, user_states, research_image_pending,
                     is_maintenance_mode, set_maintenance_mode, save_user_page)
from i18n import get_user_language, set_user_language, t, LANGUAGES
from telegram_api import edit_message_text, answer_callback_query, send_invoice, send_message, delete_message
from buttons import (main_buttons, vip_info_buttons, stars_duration_buttons, cancel_button,
                      language_picker_buttons, admin_buttons, broadcast_pin_buttons,
                      model_choice_buttons, research_models_buttons,
                      search_type_picker_buttons, search_active_buttons, search_model_inline_buttons)
from vip_system import (is_vip, get_vip_expiry_text, get_user_model, set_user_model,
                         get_v2_trials_left, get_research_model, set_research_model,
                         can_use_research_v2)
from channels_db import show_channels, delete_all_channels
from admin_flows import (show_stats, show_vip_list, start_broadcast_flow, do_broadcast,
                          start_renew_flow, start_vip_flow, apply_vip_duration, toggle_referral,
                          start_ban_flow, start_unban_flow, start_change_stars_flow,
                          start_cancel_vip_flow, confirm_cancel_vip)
from ai_engine import clear_context, pop_last_query, clear_research_v2_context
from user_handlers import show_account_info, do_analyze_photo, process_ai_response


def _do_retry_ai(callback_id, chat_id, user_id, message_id, lang):
    """تنفيذ فعلي لزر 'إعادة المحاولة':
    1) استرجاع آخر طلب محفوظ للمستخدم من last_ai_query (في config.py).
    2) إعادة تنفيذ process_ai_response في Thread منفصل حتى لا نعلق callback_handler.
    3) إذا انتهت صلاحية الحالة أو لم تكن محفوظة، نطلب من المستخدم إعادة الإرسال.
    """
    state = pop_last_query(user_id)
    if not state:
        answer_callback_query(callback_id, t('retry_state_lost', lang), show_alert=True)
        return

    query = state.get('query', '')
    is_code = bool(state.get('is_code', False))
    model = state.get('model', 'v2')

    if not query:
        answer_callback_query(callback_id, t('retry_state_lost', lang), show_alert=True)
        return

    answer_callback_query(callback_id, t('admin_action_retry_msg', lang), show_alert=False)

    # حذف رسالة الخطأ القديمة (مع زر إعادة المحاولة) لتجربة أنظف
    try:
        from telegram_api import delete_message
        delete_message(chat_id, message_id)
    except Exception:
        pass

    # مؤشر الكتابة وتشغيل المعالجة
    try:
        from telegram_api import send_chat_action
        send_chat_action(chat_id, 'typing')
    except Exception:
        pass

    def _runner():
        try:
            process_ai_response(chat_id, user_id, query, is_code=is_code, model=model, _is_retry=True)
        except Exception as exc:
            from bot_logger import log_error
            log_error(f"_do_retry_ai runner error: {exc}", user_id=user_id, exc=exc)
            try:
                send_message(chat_id, t('err_connection', lang), parse_mode='HTML')
            except Exception:
                pass

    thread = threading.Thread(target=_runner)
    thread.daemon = True
    thread.start()

def handle_callback(callback):
    callback_id = callback.get('id')
    user_id = callback.get('from', {}).get('id')
    message = callback.get('message', {})
    chat_id = message.get('chat', {}).get('id')
    message_id = message.get('message_id')
    data = callback.get('data')
    
    lang = get_user_language(user_id)
    
    # تلجرام يسمح بالرد على كل callback_query مرة واحدة فقط، لذلك يجب تحديد نص التنبيه (Toast) هنا
    # قبل الدخول في سلسلة if/elif، وليس باستدعاء answer_callback_query إضافي داخل فرع "new_chat"
    if data == 'new_chat':
        answer_callback_query(callback_id, t('new_chat_toast', lang))
    else:
        answer_callback_query(callback_id)
    
    if data == 'back_to_main':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        edit_message_text(chat_id, message_id, t('main_menu_title', lang), reply_markup=main_buttons(lang))
    
    elif data == 'new_chat':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        clear_context(user_id)
        edit_message_text(chat_id, message_id, t('new_chat_confirm', lang), reply_markup=main_buttons(lang), parse_mode='HTML')
    
    elif data == 'search_general':
        # ===== البحث المباشر: لا تظهر أزرار اختيار النوع، يتم الكشف تلقائياً =====
        # - إذا أرسل المستخدم نصاً فقط -> بحث نصي
        # - إذا أرسل صورة فقط -> يسأله عن النص المراد البحث عنه
        # - إذا أرسل صورة مع نص (caption) -> بحث بالصورة + النص مباشرة
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        from vip_system import get_research_model as _grm
        current_research = _grm(user_id)
        if current_research == 'research_v2':
            prompt_text = t('research_v2_text_prompt', lang)
        else:
            prompt_text = t('search_text_v1_prompt', lang)
        edit_message_text(
            chat_id, message_id, prompt_text,
            parse_mode='HTML',
            reply_markup=search_active_buttons(lang)
        )
        # حالة موحّدة: النص والصورة كلاهما يستخدمان نفس الحالة
        user_states[user_id] = 'waiting_search'
        answer_callback_query(callback_id, t('new_chat_toast', lang), show_alert=False)

    elif data == 'search_pick_text':
        # ===== بحث كلام (متاح للجميع) - يطلب النص =====
        # (تم الإبقاء على هذا المعالج للحفاظ على التوافق الخلفي، لكن الزر لم يعد يظهر في القائمة)
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        rmodel = get_research_model(user_id)
        if rmodel == 'research_v2':
            edit_message_text(
                chat_id, message_id,
                t('research_v2_text_prompt', lang),
                parse_mode='HTML', reply_markup=cancel_button(back_to='main')
            )
            user_states[user_id] = 'waiting_research_v2_text_only'
        else:
            edit_message_text(
                chat_id, message_id,
                t('search_text_v1_prompt', lang),
                parse_mode='HTML', reply_markup=cancel_button(back_to='main')
            )
            user_states[user_id] = 'waiting_search_text'
        answer_callback_query(callback_id, t('new_chat_toast', lang), show_alert=False)

    elif data == 'search_pick_image':
        # ===== بحث صور - V2 فقط (VIP/Admin) =====
        # (تم الإبقاء على هذا المعالج للحفاظ على التوافق الخلفي، لكن الزر لم يعد يظهر في القائمة)
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        if not can_use_research_v2(user_id):
            answer_callback_query(callback_id, t('research_v2_vip_only', lang), show_alert=True)
            return
        if get_research_model(user_id) != 'research_v2':
            set_research_model(user_id, 'research_v2')
        edit_message_text(
            chat_id, message_id,
            t('research_v2_text_prompt', lang),
            parse_mode='HTML', reply_markup=cancel_button(back_to='main')
        )
        user_states[user_id] = 'waiting_research_v2_text'
        answer_callback_query(callback_id, t('new_chat_toast', lang), show_alert=False)

    elif data == 'cancel_search':
        # ===== إلغاء البحث - إعادة القائمة الرئيسية =====
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        user_states.pop(user_id, None)
        research_image_pending.pop(user_id, None)
        # مسح سياق البحث V2 أيضاً
        try:
            clear_research_v2_context(user_id)
        except Exception:
            pass
        edit_message_text(chat_id, message_id, t('main_menu_title', lang),
                          reply_markup=main_buttons(lang), parse_mode='HTML')
        answer_callback_query(callback_id, t('search_cancel_button_toast', lang), show_alert=False)

    elif data == 'change_search_model':
        # ===== تغيير نموذج البحث أثناء البحث - عرض أزرار الاختيار المضمنة =====
        # لا يتم تغيير الصفحة أو مسح حالة البحث - فقط عرض خيارات النماذج
        from config import user_research_model as _urm
        current_research = _urm.get(user_id, 'research_v1')
        edit_message_text(
            chat_id, message_id,
            t('research_models_prompt', lang),
            parse_mode='HTML',
            reply_markup=search_model_inline_buttons(lang, current_research=current_research)
        )
        answer_callback_query(callback_id, t('new_chat_toast', lang), show_alert=False)

    elif data == 'inline_select_research_v1':
        # ===== اختيار V1 من داخل صفحة البحث (بدون مغادرة البحث) =====
        set_research_model(user_id, 'research_v1')
        # العودة إلى وضع البحث مباشرة مع الحفاظ على الحالة
        edit_message_text(
            chat_id, message_id,
            t('search_model_changed_inline', lang, model='WORMGPT Research V1'),
            parse_mode='HTML',
            reply_markup=search_active_buttons(lang)
        )
        # التأكد من أن المستخدم لا يزال في وضع البحث
        if user_id not in user_states or user_states.get(user_id) not in (
            'waiting_search', 'waiting_search_text', 'waiting_research_v2_text',
            'waiting_research_v2_text_only', 'waiting_search_type'
        ):
            user_states[user_id] = 'waiting_search'
        answer_callback_query(callback_id, t('new_chat_toast', lang), show_alert=False)

    elif data == 'inline_select_research_v2':
        # ===== اختيار V2 من داخل صفحة البحث (VIP/Admin فقط) =====
        if not can_use_research_v2(user_id):
            answer_callback_query(callback_id, t('research_v2_vip_only', lang), show_alert=True)
            return
        set_research_model(user_id, 'research_v2')
        # العودة إلى وضع البحث V2 مباشرة مع الحفاظ على الحالة
        edit_message_text(
            chat_id, message_id,
            t('search_model_changed_inline', lang, model='WORMGPT-research-V2'),
            parse_mode='HTML',
            reply_markup=search_active_buttons(lang)
        )
        # التأكد من أن المستخدم لا يزال في وضع البحث
        if user_id not in user_states or user_states.get(user_id) not in (
            'waiting_search', 'waiting_search_text', 'waiting_research_v2_text',
            'waiting_research_v2_text_only', 'waiting_search_type'
        ):
            user_states[user_id] = 'waiting_research_v2_text'
        answer_callback_query(callback_id, t('new_chat_toast', lang), show_alert=False)

    elif data == 'back_to_search':
        # ===== العودة إلى وضع البحث من قائمة تغيير النموذج =====
        # استعادة حالة البحث المناسبة بناءً على النموذج المختار
        current_research = get_research_model(user_id)
        if current_research == 'research_v2':
            prompt_text = t('research_v2_text_prompt', lang)
            if user_id not in user_states or user_states.get(user_id) not in (
                'waiting_search', 'waiting_search_text', 'waiting_research_v2_text',
                'waiting_research_v2_text_only', 'waiting_search_type'
            ):
                user_states[user_id] = 'waiting_research_v2_text'
        else:
            prompt_text = t('search_text_v1_prompt', lang)
            if user_id not in user_states or user_states.get(user_id) not in (
                'waiting_search', 'waiting_search_text', 'waiting_research_v2_text',
                'waiting_research_v2_text_only', 'waiting_search_type'
            ):
                user_states[user_id] = 'waiting_search'
        edit_message_text(
            chat_id, message_id, prompt_text,
            parse_mode='HTML',
            reply_markup=search_active_buttons(lang)
        )
        answer_callback_query(callback_id, t('new_chat_toast', lang), show_alert=False)

    elif data == 'end_search':
        # ===== إنهاء البحث - مسح السياق الحالي =====
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        clear_context(user_id)
        user_states.pop(user_id, None)
        research_image_pending.pop(user_id, None)
        try:
            clear_research_v2_context(user_id)
        except Exception:
            pass
        answer_callback_query(callback_id, t('end_search_toast', lang), show_alert=False)
        edit_message_text(chat_id, message_id, t('end_search_confirm', lang),
                          reply_markup=main_buttons(lang), parse_mode='HTML')

    elif data == 'research_models':
        # ===== عرض قائمة نماذج البحث =====
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        from config import user_research_model as _urm
        current_research = _urm.get(user_id, 'research_v1')
        edit_message_text(
            chat_id, message_id, t('research_models_prompt', lang),
            parse_mode='HTML',
            reply_markup=research_models_buttons(lang, current_research=current_research)
        )

    elif data == 'select_research_v1':
        # ===== اختيار V1 (متاح للجميع) =====
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        set_research_model(user_id, 'research_v1')
        edit_message_text(
            chat_id, message_id,
            t('research_model_v1_selected', lang),
            parse_mode='HTML', reply_markup=main_buttons(lang)
        )

    elif data == 'select_research_v2':
        # ===== اختيار V2 (VIP/Admin فقط) =====
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        if not can_use_research_v2(user_id):
            edit_message_text(
                chat_id, message_id,
                t('research_v2_vip_only', lang),
                parse_mode='HTML', reply_markup=vip_info_buttons(lang)
            )
            return
        set_research_model(user_id, 'research_v2')
        edit_message_text(
            chat_id, message_id,
            t('research_model_v2_selected', lang),
            parse_mode='HTML', reply_markup=main_buttons(lang)
        )
    
    elif data == 'copy_code':
        answer_callback_query(callback_id, t('copy_code_alert', lang), show_alert=True)
    elif data == 'retry_ai':
        # زر إعادة المحاولة: يُعيد تنفيذ آخر طلب AI محفوظ للمستخدم فعلاً.
        # (الإصلاح الرئيسي هنا: الكود السابق كان يكتفي بعرض toast فقط).
        _do_retry_ai(callback_id, chat_id, user_id, message_id, lang)
    
    elif data == 'developer':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        text = t('developer_text', lang, name=OWNER_NAME, owner=OWNER_USER, channel=CHANNEL)
        edit_message_text(chat_id, message_id, text, parse_mode='HTML', reply_markup=main_buttons(lang))
    
    # ===== تبديل نموذج الذكاء الاصطناعي =====
    elif data == 'switch_model':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        current_model = get_user_model(user_id)
        edit_message_text(chat_id, message_id, t('model_switch_prompt', lang),
                          parse_mode='HTML', reply_markup=model_choice_buttons(lang, current_model))

    elif data == 'select_model_v1':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        set_user_model(user_id, 'v1')
        edit_message_text(chat_id, message_id, t('model_switched_v1', lang),
                          parse_mode='HTML', reply_markup=main_buttons(lang))

    elif data == 'select_model_v2':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        from vip_system import has_v2_access
        if not has_v2_access(user_id):
            # لا يملك وصولاً لـ V2 (انتهت التجارب ولا اشتراك)
            body = t('v2_trial_exhausted', lang)
            edit_message_text(chat_id, message_id, body,
                              parse_mode='HTML', reply_markup=vip_info_buttons(lang))
        else:
            set_user_model(user_id, 'v2')
            trials_left = get_v2_trials_left(user_id)
            from vip_system import is_vip as _is_vip
            if user_id in ADMIN or _is_vip(user_id):
                # أدمن أو مشترك: وصول كامل
                edit_message_text(chat_id, message_id, t('model_switched_v2', lang, trials='∞'),
                                  parse_mode='HTML', reply_markup=main_buttons(lang))
            else:
                edit_message_text(chat_id, message_id,
                                  t('model_switched_v2', lang, trials=trials_left),
                                  parse_mode='HTML', reply_markup=main_buttons(lang))

    # ===== اختيار اللغة عند أول دخول =====
    elif data.startswith('set_lang_'):
        selected_lang = data.replace('set_lang_', '')
        from user_handlers import handle_language_selection
        handle_language_selection(chat_id, user_id, selected_lang)
        return

    # ===== معلومات حساب المستخدم =====
    elif data == 'account_info':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        show_account_info(chat_id, user_id, message_id, lang)
    
    # ===== اشتراك VIP (للمستخدم العادي) =====
    elif data == 'vip_info':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        if is_vip(user_id):
            status_line = t('vip_status_active', lang, expiry=get_vip_expiry_text(user_id))
        else:
            status_line = t('vip_status_inactive', lang)
        body = t('vip_panel_body', lang, status_line=status_line)
        edit_message_text(chat_id, message_id, body, parse_mode='HTML', reply_markup=vip_info_buttons(lang))
    
    # ===== اشتراك VIP عبر نجوم تلجرام =====
    elif data == 'stars_subscribe_menu':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        edit_message_text(chat_id, message_id, t('stars_picker_prompt', lang), parse_mode='HTML', reply_markup=stars_duration_buttons(lang))
    
    elif data.startswith('stars_duration_'):
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        duration_key = data.replace('stars_duration_', '')
        amount = STARS_PRICES.get(duration_key)
        if amount:
            duration_label = DURATION_LABELS.get(duration_key, {}).get(lang, duration_key)
            title = t('invoice_title', lang, duration=duration_label)
            description = t('invoice_description', lang, duration=duration_label)
            payload = f"vip_stars_{duration_key}_{user_id}"
            send_invoice(chat_id, title, description, payload, amount)
    
    # ===== تواصل مع الدعم =====
    elif data == 'contact_support':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        user_states[user_id] = 'waiting_support_message'
        edit_message_text(chat_id, message_id, t('support_prompt', lang), parse_mode='HTML', reply_markup=cancel_button(back_to='main'))
    
    # ===== رد الأدمن على رسالة دعم محددة =====
    elif data.startswith('support_reply_'):
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن الأدمن في لوحة الأدمن
            target_user_id = data.replace('support_reply_', '')
            admin_context[user_id] = {'support_reply_target': target_user_id}
            user_states[user_id] = 'waiting_support_reply'
            send_message(chat_id, t('support_reply_prompt_admin', lang), parse_mode='HTML', reply_markup=cancel_button(back_to='admin'))
    
    # ===== تغيير اللغة =====
    elif data == 'language_menu':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        edit_message_text(chat_id, message_id, t('language_picker_prompt', lang), parse_mode='HTML', reply_markup=language_picker_buttons(lang))
    
    elif data.startswith('set_lang_'):
        new_lang = data.replace('set_lang_', '')
        if new_lang in LANGUAGES:
            set_user_language(user_id, new_lang)
            lang_info = LANGUAGES[new_lang]
            confirm_text = t('language_set_confirmation', new_lang, flag=lang_info['flag'], lang_name=lang_info['name'])
            edit_message_text(chat_id, message_id, confirm_text, parse_mode='HTML', reply_markup=main_buttons(new_lang))
    
    elif data == 'stats':
        save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
        show_stats(chat_id, user_id, message_id)
    
    elif data == 'list_vip_users':
        save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
        show_vip_list(chat_id, user_id, message_id)
    
    elif data == 'add_channel':
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            edit_message_text(chat_id, message_id, t('admin_add_channel_prompt', lang), parse_mode='HTML')
            user_states[user_id] = 'waiting_add_channel'

    elif data == 'remove_channel':
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            edit_message_text(chat_id, message_id, t('admin_remove_channel_prompt', lang), parse_mode='HTML')
            user_states[user_id] = 'waiting_remove_channel'
    
    elif data == 'show_channels':
        save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
        show_channels(chat_id, user_id, message_id)
    
    elif data == 'delete_all_channels':
        save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
        delete_all_channels(chat_id, user_id, message_id)
    
    # ===== الإذاعة =====
    elif data == 'broadcast_menu':
        start_broadcast_flow(chat_id, user_id, message_id)
    
    elif data in ('broadcast_normal', 'broadcast_vip', 'broadcast_all'):
        if user_id in ADMIN:
            ctx = admin_context.get(user_id, {})
            if ctx.get('broadcast_chat_id') and ctx.get('broadcast_message_id'):
                admin_context[user_id]['broadcast_target'] = data
                edit_message_text(
                    chat_id, message_id,
                    t('broadcast_pin_prompt', lang),
                    parse_mode='HTML',
                    reply_markup=broadcast_pin_buttons(lang)
                )
            else:
                edit_message_text(chat_id, message_id, t('admin_action_generic_error', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')

    elif data in ('broadcast_pin_yes', 'broadcast_pin_no'):
        if user_id in ADMIN:
            ctx = admin_context.get(user_id, {})
            source_chat_id = ctx.get('broadcast_chat_id')
            source_message_id = ctx.get('broadcast_message_id')
            target = ctx.get('broadcast_target')
            pin = (data == 'broadcast_pin_yes')
            if source_chat_id and source_message_id and target:
                thread = threading.Thread(target=do_broadcast, args=(chat_id, user_id, message_id, source_chat_id, source_message_id, target, pin))
                thread.daemon = True
                thread.start()
            else:
                edit_message_text(chat_id, message_id, t('admin_action_generic_error', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')
    
    # ===== تجديد رصيد الرسائل =====
    elif data == 'renew_messages_menu':
        start_renew_flow(chat_id, user_id, message_id)
    
    # ===== اشتراك VIP (من لوحة تحكم الأدمن) =====
    elif data == 'vip_subscription_menu':
        start_vip_flow(chat_id, user_id, message_id)
    
    elif data.startswith('vip_duration_'):
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            duration_key = data.replace('vip_duration_', '')
            apply_vip_duration(chat_id, user_id, message_id, duration_key)

    # ===== إلغاء اشتراك VIP (أدمن) =====
    elif data == 'cancel_vip_menu':
        if user_id in ADMIN:
            start_cancel_vip_flow(chat_id, user_id, message_id)

    elif data == 'confirm_cancel_vip':
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            from admin_flows import confirm_cancel_vip
            confirm_cancel_vip(chat_id, user_id, message_id)

    # ===== تعديل أسعار النجوم - اختيار الباقة (أدمن) =====
    elif data.startswith('stars_edit_'):
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            duration_key = data.replace('stars_edit_', '')
            from admin_flows import handle_stars_package_selection
            handle_stars_package_selection(chat_id, user_id, message_id, duration_key)

    # ===== تبديل وضع الصيانة (أدمن فقط) =====
    elif data == 'toggle_maintenance':
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            set_maintenance_mode(not is_maintenance_mode())
            if is_maintenance_mode():
                status_text = t('maintenance_enabled_text', lang)
            else:
                status_text = t('maintenance_disabled_text', lang)
            edit_message_text(chat_id, message_id, status_text, reply_markup=admin_buttons(lang), parse_mode='HTML')
    
    # ===== حظر مستخدم (أدمن) =====
    elif data == 'ban_user_menu':
        if user_id in ADMIN:
            start_ban_flow(chat_id, user_id, message_id)

    # ===== إلغاء حظر مستخدم (أدمن) =====
    elif data == 'unban_user_menu':
        if user_id in ADMIN:
            start_unban_flow(chat_id, user_id, message_id)

    # ===== تغيير أسعار النجوم (أدمن) =====
    elif data == 'change_stars_prices':
        if user_id in ADMIN:
            start_change_stars_flow(chat_id, user_id, message_id)

    # ===== تأكيد تغيير سعر نجوم =====
    elif data == 'confirm_stars_price_change':
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            from admin_flows import confirm_stars_price_change
            confirm_stars_price_change(chat_id, user_id, message_id)

    # ===== نظام الإحالة =====
    elif data == 'show_referral':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        from vip_system import get_referral_link, get_ref_count, get_ref_bonus_v2
        from buttons import referral_info_buttons
        ref_link  = get_referral_link(user_id)
        ref_count = get_ref_count(user_id)
        ref_bonus = get_ref_bonus_v2(user_id)
        msg = t('referral_panel', lang, ref_link=ref_link, ref_count=ref_count, ref_bonus=ref_bonus)
        edit_message_text(chat_id, message_id, msg,
                          reply_markup=referral_info_buttons(lang), parse_mode='HTML')

    elif data == 'admin_toggle_referral':
        if user_id in ADMIN:
            save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
            toggle_referral(chat_id, user_id, message_id)

    # ===== تحليل الصور (V2) =====
    elif data == 'analyze_photo_yes':
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        do_analyze_photo(chat_id, user_id, message_id)

    elif data == 'analyze_photo_no':
        # عند الضغط على "لا شكراً": انتقل لوضع انتظار وصف/سؤال للصورة
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        from buttons import cancel_photo_description_button
        user_states[user_id] = 'waiting_photo_description'
        answer_callback_query(callback_id, t('photo_ask_description_toast', lang), show_alert=False)
        edit_message_text(
            chat_id, message_id,
            t('photo_description_prompt', lang),
            parse_mode='HTML',
            reply_markup=cancel_photo_description_button(lang)
        )

    elif data == 'cancel_photo_description':
        # ===== إلغاء وصف الصورة — مسح الصورة المعلقة والحالة والرجوع للقائمة الرئيسية =====
        save_user_page(user_id, 'main')  # حفظ أن المستخدم في الصفحة الرئيسية
        from config import photo_pending
        photo_pending.pop(user_id, None)
        user_states.pop(user_id, None)
        edit_message_text(chat_id, message_id, t('main_menu_title', lang),
                          reply_markup=main_buttons(lang), parse_mode='HTML')
        answer_callback_query(callback_id, t('photo_description_cancelled_toast', lang), show_alert=False)

    # ===== الغاء أي إجراء أدمن متعدد الخطوات والرجوع للصفحة السابقة (ذكي) =====
    elif data == 'cancel_admin_action' or data.startswith('cancel_admin_action:'):
        # استخراج الصفحة المطلوب العودة إليها من callback_data (إن وُجدت)
        # الصيغة: cancel_admin_action:page  حيث page = 'admin' أو 'main'
        requested_page = None
        if ':' in data:
            requested_page = data.split(':', 1)[1]

        user_states.pop(user_id, None)
        admin_context.pop(user_id, None)
        # تنظيف أي ملف معلق إن وُجد (عند إلغاء المستخدم لتدفّق التعليم بعد رفع ملف)
        from config import file_pending
        file_pending.pop(user_id, None)

        # تحديد الصفحة التي يجب العودة إليها
        # الأولوية: 1) الصفحة المطلوبة صراحةً، 2) الصفحة المحفوظة، 3) الصفحة الافتراضية
        from config import get_user_last_page
        if requested_page in ('admin', 'main'):
            target_page = requested_page
        else:
            target_page = get_user_last_page(user_id, default='main' if user_id not in ADMIN else 'admin')

        if target_page == 'admin' and user_id in ADMIN:
            edit_message_text(chat_id, message_id, t('admin_cancel_text', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')
        else:
            edit_message_text(chat_id, message_id, t('main_menu_title', lang), reply_markup=main_buttons(lang), parse_mode='HTML')

