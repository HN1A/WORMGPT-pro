# WORMGPT Pro - Summary of Changes

## Date: 2026-07-10

---

## Request 1: Separate Chat and Search Models
**Goal**: Ensure search models are ONLY used when user explicitly clicks the search button. Normal chat should NEVER trigger search.

### Files Modified:

#### 1. `user_handlers.py` - `process_ai_response()` (line ~373)
**Before:**
```python
if is_code:
    ...
    use_search = False
else:
    ...
    use_search = True
```
**After:**
```python
if is_code:
    ...
else:
    ...
# Search is ONLY used in explicit search mode (button click)
# Normal chat NEVER uses search
use_search = False
```

#### 2. `ai_engine.py` - `ask_wormgpt()` (line ~1739)
**Before:**
```python
if is_search_query or any(kw in prompt.lower() for kw in ['موقع', 'رابط', 'عنوان', 'search', 'ابحث', 'find']):
    search_results = search_web(prompt, 4)
```
**After:**
```python
# Search ONLY when is_search_query=True (explicit search mode)
# No auto-detection based on keywords in normal chat
if is_search_query:
    search_results = search_web(prompt, 4)
```

#### 3. `ai_engine.py` - `ask_wormgpt_v2()` (line ~1837)
**Before:**
```python
if is_search_query or any(kw in prompt.lower() for kw in ['موقع', 'رابط', 'search', 'ابحث']):
    search_results = search_web(prompt, 3)
```
**After:**
```python
# Search ONLY in explicit search mode (is_search_query=True)
# Normal chat never triggers search
if is_search_query:
    search_results = search_web(prompt, 3)
```

### Verification:
- All callers of `ask_wormgpt` and `ask_wormgpt_v2` in normal chat pass `is_search_query=False`
- Search handler (`handle_search`) uses `ask_wormgpt_research_v2` directly - completely separate path
- No keyword-based auto-detection remains in normal chat flow

---

## Request 2: Add "🔄 Change Search Model" Button to Search Page
**Goal**: Add a button inside the search page to change the search model without leaving search mode.

### Files Modified:

#### 1. `buttons.py` - Added new button functions (after line ~115)

**`search_active_buttons()`**: New function that returns both "Change Model" and "Cancel" buttons side by side.

**`search_model_inline_buttons()`**: New function that shows research model selection (V1/V2) with back button.

#### 2. `i18n.py` - Added new translations (after line ~444)
New translation keys:
- `btn_change_search_model` - Button label (5 languages)
- `btn_back_to_search` - Back button label (5 languages)
- `search_model_changed_inline` - Confirmation message (5 languages)

#### 3. `callback_handler.py` - Added new callback handlers (after line ~170)

**`change_search_model`**: Shows inline model selection without changing page or state.

**`inline_select_research_v1`**: Selects V1 model, returns to search mode.

**`inline_select_research_v2`**: Selects V2 model (VIP/Admin only), returns to search mode.

**`back_to_search`**: Returns to search mode from model selection.

#### 4. `user_handlers.py` - Updated button usage
Replaced `cancel_search_button` with `search_active_buttons` in:
- Initial search state (line ~377)
- V2 search in progress (line ~649)
- V1 search in progress (line ~698)
- Photo research resume (line ~768)

#### 5. `callback_handler.py` - Updated initial search setup (line ~117)
Changed from `cancel_button(back_to='main')` to `search_active_buttons(lang)` for the initial search prompt.

### Features:
- User can change search model without leaving search page
- Current search state is preserved
- No data loss or session restart
- Works for both V1 and V2 search models
- VIP/Admin check enforced for V2 selection

---

## Request 3: Fix Image Analysis Bug
**Bug**: When user sends an image, system shows "Analyzing image..." then multiple "⚡" lines, then stops forever.

### Root Causes Fixed:
1. `send_typing_effect` sent "⚡" message but failed to edit it, leaving orphan messages
2. Thread in `do_analyze_photo` had no comprehensive error handling - died silently on exceptions
3. No timeout protection in `analyze_image_v2` - could hang indefinitely
4. Edge case: empty/whitespace results from `analyze_image_v2` not handled properly

### Files Modified:

#### 1. `ai_engine.py` - `send_typing_effect()` (complete rewrite)
Improvements:
- Added input validation (`full_text.strip()`)
- Track orphan "⚡" message IDs for cleanup on failure
- If `message_id` extraction fails: delete orphan + send text directly as fallback
- If edit fails mid-way: catch exception, continue, attempt final edit
- If final edit fails: delete "⚡", send text as new message
- Outer exception handler: delete orphan + send text as new message
- Guaranteed delivery: user always receives the result or an error message

#### 2. `ai_engine.py` - `analyze_image_v2()` (enhanced)
Improvements:
- Added total execution timeout (5 minutes) with `_check_timeout()` function
- Timeout checks before every network operation (file download, API calls)
- `TimeoutError` catch in main exception block
- Graceful degradation: returns `None` on timeout, triggers error message to user

#### 3. `user_handlers.py` - `do_analyze_photo()` (enhanced)
Improvements:
- Added comprehensive try/except around entire `_run()` thread function
- Check for empty/whitespace results: `if result and result.strip()`
- On empty result: send error message with retry buttons
- On any exception: log error, send error message to user (no silent failures)
- Thread never dies silently - always sends feedback to user

#### 4. `user_handlers.py` - `handle_photo_description_input()` (enhanced)
Improvements:
- Same empty/whitespace result check
- Consistent error handling with retry buttons

---

## Files Modified Summary

| File | Changes |
|------|---------|
| `ai_engine.py` | 4 modifications: `ask_wormgpt`, `ask_wormgpt_v2`, `send_typing_effect`, `analyze_image_v2` |
| `user_handlers.py` | 5 modifications: `process_ai_response`, `do_analyze_photo`, `handle_photo_description_input`, `handle_search`, `handle_research_v2_photo_resume`, imports |
| `callback_handler.py` | 6 modifications: 4 new handlers + import update + initial search button |
| `buttons.py` | 2 new functions: `search_active_buttons`, `search_model_inline_buttons` |
| `i18n.py` | 3 new translation keys: `btn_change_search_model`, `btn_back_to_search`, `search_model_changed_inline` |

## Backward Compatibility
- All existing functions preserved
- All existing callbacks preserved
- `cancel_search_button` function kept for backward compatibility
- No files deleted
- No features removed
- All existing behaviors maintained except: search no longer auto-triggers in normal chat

## Testing Checklist
- [x] Syntax check passed for all modified files
- [x] All imports verified
- [x] No duplicate function definitions
- [x] No circular import issues
- [x] All callback data strings are unique
- [x] All translation keys defined in all 5 languages
