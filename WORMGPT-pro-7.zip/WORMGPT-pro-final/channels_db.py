import sqlite3
from config import session, URL, ADMIN
from telegram_api import send_message, edit_message_text
from buttons import admin_buttons
from i18n import get_user_language, t

# ========================================================================
#                      تهيئة قاعدة البيانات
# ========================================================================

conn = sqlite3.connect('channels.db', check_same_thread=False)
cursor = conn.cursor()

cursor.execute('''CREATE TABLE IF NOT EXISTS channels (id INTEGER PRIMARY KEY, channel_name TEXT, invite_link TEXT)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS banned_users (user_id INTEGER PRIMARY KEY, banned_at TEXT, reason TEXT)''')
conn.commit()

# ========================================================================
#                      دوال الاشتراك
# ========================================================================

def subscs(user_id):
    channels = cursor.execute("SELECT channel_name, invite_link FROM channels").fetchall()
    for channel in channels:
        channel_username, invite_link = channel
        try:
            response = session.get(f"{URL}/getChatMember", params={"chat_id": channel_username, "user_id": user_id})
            if response.status_code == 200:
                data = response.json()
                if data.get('ok'):
                    status = data.get('result', {}).get('status')
                    if status not in ["member", "administrator", "creator"]:
                        return False, invite_link
        except:
            continue
    return True, None


# ========================================================================
#                      إدارة القنوات (للا أدمن)
# ========================================================================

def add_channel(chat_id, user_id, channel_name):
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)

    if not channel_name.startswith('@'):
        channel_name = '@' + channel_name

    try:
        response = session.get(f"{URL}/getChat", params={"chat_id": channel_name})
        if response.status_code == 200:
            chat_info = response.json().get('result', {})
            invite_response = session.post(f"{URL}/exportChatInviteLink", json={"chat_id": chat_info.get('id')})
            if invite_response.status_code == 200:
                invite_link = invite_response.json().get('result')
                cursor.execute("INSERT INTO channels (channel_name, invite_link) VALUES (?, ?)", (channel_name, invite_link))
                conn.commit()
                send_message(chat_id, t('admin_channel_added', lang, channel_name=channel_name), reply_markup=admin_buttons(lang), parse_mode='HTML')
            else:
                send_message(chat_id, t('admin_channel_invite_failed', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')
        else:
            send_message(chat_id, t('admin_channel_not_found', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')
    except Exception as e:
        send_message(chat_id, f"❌ {str(e)}", reply_markup=admin_buttons(lang), parse_mode='HTML')

def remove_channel(chat_id, user_id, channel_name):
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    cursor.execute("DELETE FROM channels WHERE channel_name = ?", (channel_name,))
    conn.commit()
    send_message(chat_id, t('admin_channel_removed', lang, channel_name=channel_name), reply_markup=admin_buttons(lang), parse_mode='HTML')

def show_channels(chat_id, user_id, message_id):
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    channels = cursor.execute("SELECT channel_name FROM channels").fetchall()
    if channels:
        text = t('admin_channels_list_header', lang) + "\n\n"
        for ch in channels:
            text += f"• {ch[0]}\n"
        edit_message_text(chat_id, message_id, text, reply_markup=admin_buttons(lang), parse_mode='HTML')
    else:
        edit_message_text(chat_id, message_id, t('admin_channels_list_empty', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')

def delete_all_channels(chat_id, user_id, message_id):
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    cursor.execute("DELETE FROM channels")
    conn.commit()
    edit_message_text(chat_id, message_id, t('admin_channels_all_deleted', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')


# ========================================================================
#                      نظام الحظر (Ban/Unban)
# ========================================================================

def ban_user(user_id_to_ban, reason=''):
    """حظر مستخدم بواسطة الأدمن. تُعيد True عند النجاح."""
    try:
        from time import strftime
        banned_at = strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute(
            "INSERT OR REPLACE INTO banned_users (user_id, banned_at, reason) VALUES (?, ?, ?)",
            (int(user_id_to_ban), banned_at, reason)
        )
        conn.commit()
        return True
    except Exception:
        return False


def unban_user(user_id_to_unban):
    """إلغاء حظر مستخدم. تُعيد True عند النجاح."""
    try:
        cursor.execute("DELETE FROM banned_users WHERE user_id = ?", (int(user_id_to_unban),))
        conn.commit()
        return cursor.rowcount > 0
    except Exception:
        return False


def is_user_banned(user_id_to_check):
    """التحقق مما إذا كان المستخدم محظوراً."""
    try:
        result = cursor.execute(
            "SELECT 1 FROM banned_users WHERE user_id = ?", (int(user_id_to_check),)
        ).fetchone()
        return result is not None
    except Exception:
        return False


def get_banned_users_list():
    """جلب قائمة بالمستخدمين المحظورين."""
    try:
        return cursor.execute(
            "SELECT user_id, banned_at, reason FROM banned_users ORDER BY banned_at DESC"
        ).fetchall()
    except Exception:
        return []

