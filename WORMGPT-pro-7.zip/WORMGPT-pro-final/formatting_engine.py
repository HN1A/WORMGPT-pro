# ========================================================================
#                      Telegram Formatting Engine
# ========================================================================
#      وحدة مركزية مستقلة لمعالجة وتنسيق جميع ردود الذكاء الاصطناعي
#      قبل إرسالها عبر Telegram Bot API. تدعم HTML و Markdown و
#      MarkdownV2 مع حماية كاملة لكتل الأكواد وتهريب المحارف المحجوزة.
# ========================================================================

import re
import html

# ====================================================================
#                  محارف Telegram المحجوزة لكل نمط
# ====================================================================

# محارف HTML المحجوزة في Telegram (دائماً تُهرَّب خارج كتل الأكواد)
HTML_RESERVED = {
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
}

# محارف MarkdownV2 المحجوزة (يجب تهريبها بـ \)
MARKDOWN_V2_RESERVED_CHARS = [
    '_', '*', '[', ']', '(', ')', '~', '`', '>', '#',
    '+', '-', '=', '|', '{', '}', '.', '!'
]

# أنماط التحليل المدعومة
SUPPORTED_PARSE_MODES = ['HTML', 'Markdown', 'MarkdownV2']

# النمط الافتراضي
DEFAULT_PARSE_MODE = 'HTML'

# ====================================================================
#               كاشف كتل الأكواد (Code Block Detection)
# ====================================================================

# نمط Regex لكشف كتل الأكواد الثلاثية (```lang\ncode\n```)
# يدعم اللغة الاختيارية بعد علامات البداية
CODE_BLOCK_TRIPLE_RE = re.compile(
    r'```([\w+\-]*)(?:\s*\n|\s+)'
    r'(.*?)'
    r'```',
    re.DOTALL
)

# نمط Regex لكشف كتل الأكواد المغلقة بثلاث علامات بدون لغة على السطر نفسه
CODE_BLOCK_TRIPLE_SIMPLE_RE = re.compile(
    r'```'
    r'(.*?)'
    r'```',
    re.DOTALL
)

# نمط Regex للكود المضمن (`inline code`)
INLINE_CODE_RE = re.compile(r'`([^`\n]+?)`')

# ====================================================================
#                  حماية كتل الأكواد (Code Block Protection)
# ====================================================================

class _CodeProtector:
    """آلية حماية مؤقتة لكتل الأكواد أثناء المعالجة.
    
    تعمل باستبدال كتل الأكواد بعلامات placeholder فريدة،
    ثم استعادتها بعد انتهاء عمليات التهريب والتحويل.
    هذا يضمن عدم تلف الأكواد أبداً أثناء المعالجة."""

    def __init__(self):
        self._placeholders = {}
        self._counter = 0

    def _make_placeholder(self, code_type='block'):
        """إنشاء علامة placeholder فريدة"""
        self._counter += 1
        return f"\x00{code_type}_{self._counter:04d}\x00"

    def protect_code_blocks(self, text):
        """استبدال جميع كتل الأكواد (ثلاثية ومضمنة) بعلامات placeholder.
        
        تُعاد النص المحمي وقاموس الاستعادة."""
        if not text:
            return text, {}

        self._placeholders = {}
        protected = text

        # 1) حماية كتل الأكواد الثلاثية (مع لغة)
        def replace_triple_with_lang(match):
            lang = match.group(1) or ''
            code = match.group(2)
            placeholder = self._make_placeholder('triple')
            self._placeholders[placeholder] = ('triple', lang.strip(), code)
            return placeholder

        protected = CODE_BLOCK_TRIPLE_RE.sub(replace_triple_with_lang, protected)

        # 2) حماية كتل الأكواد الثلاثية البسيطة (بقايا)
        def replace_triple_simple(match):
            code = match.group(1)
            placeholder = self._make_placeholder('triple')
            self._placeholders[placeholder] = ('triple', '', code)
            return placeholder

        # نتجنب استبدال الـ placeholders أنفسهم
        remaining_blocks = re.findall(r'```(.*?)```', protected, re.DOTALL)
        for block_content in remaining_blocks:
            if '\x00' not in block_content:
                full_block = f'```{block_content}```'
                placeholder = self._make_placeholder('triple')
                self._placeholders[placeholder] = ('triple', '', block_content)
                protected = protected.replace(full_block, placeholder, 1)

        # 3) حماية الكود المضمن (inline)
        def replace_inline(match):
            code = match.group(1)
            placeholder = self._make_placeholder('inline')
            self._placeholders[placeholder] = ('inline', '', code)
            return placeholder

        # نتجنب استبدال ما داخل placeholders
        parts = []
        i = 0
        while i < len(protected):
            if protected[i:i+1] == '\x00':
                # نصل إلى placeholder موجود مسبقاً
                end_idx = protected.find('\x00', i+1)
                if end_idx != -1:
                    parts.append(protected[i:end_idx+1])
                    i = end_idx + 1
                    continue
            # ابحث عن كود مضمن في هذا الجزء
            match = INLINE_CODE_RE.search(protected[i:])
            if match and match.start() == 0:
                code = match.group(1)
                placeholder = self._make_placeholder('inline')
                self._placeholders[placeholder] = ('inline', '', code)
                parts.append(placeholder)
                i += len(match.group(0))
            else:
                parts.append(protected[i:i+1])
                i += 1
        protected = ''.join(parts)

        return protected, self._placeholders

    def restore_code_blocks(self, text, placeholders, parse_mode='HTML'):
        """استعادة كتل الأكواد من placeholders بتنسيق Telegram المناسب."""
        if not placeholders:
            return text

        result = text
        for placeholder, (code_type, lang, code) in placeholders.items():
            if code_type == 'triple':
                # تنسيق كتلة الكود لـ Telegram HTML
                formatted = _format_code_block_to_telegram_html(code, lang, parse_mode)
                result = result.replace(placeholder, formatted, 1)
            elif code_type == 'inline':
                # تنسيق الكود المضمن
                formatted = _format_inline_code_to_telegram_html(code, parse_mode)
                result = result.replace(placeholder, formatted, 1)

        return result


# ====================================================================
#               تحويل كتل الأكواد إلى HTML تلغرام
# ====================================================================

def _format_code_block_to_telegram_html(code, lang='', parse_mode='HTML'):
    """تحويل كتلة كود إلى تنسيق Telegram HTML.
    
    يحافظ على المسافات البادئة والأسطر الفارغة والمحارف الخاصة داخل الكود."""
    if not code:
        if parse_mode == 'HTML':
            return '<pre><code></code></pre>'
        return '```\n```'

    # تنظيف الكود: إزالة مسافات/أسطر زائدة فقط من البداية والنهاية
    code = code.rstrip('\n').lstrip('\n')

    if parse_mode == 'HTML':
        # تهريب HTML داخل الكود
        escaped_code = html.escape(code, quote=False)
        if lang:
            return f'<pre><code class="language-{html.escape(lang, quote=False)}">{escaped_code}</code></pre>'
        return f'<pre><code>{escaped_code}</code></pre>'
    elif parse_mode == 'MarkdownV2':
        escaped_code = _escape_markdown_v2(code)
        return f'```{lang}\n{escaped_code}\n```'
    else:  # Markdown
        return f'```{lang}\n{code}\n```'


def _format_inline_code_to_telegram_html(code, parse_mode='HTML'):
    """تحويل كود مضمن إلى تنسيق Telegram HTML."""
    if not code:
        if parse_mode == 'HTML':
            return '<code></code>'
        return '``'

    if parse_mode == 'HTML':
        escaped = html.escape(code, quote=False)
        return f'<code>{escaped}</code>'
    elif parse_mode == 'MarkdownV2':
        escaped = _escape_markdown_v2(code)
        return f'`{escaped}`'
    else:  # Markdown
        return f'`{code}`'


# ====================================================================
#               التهريب الآمن (Safe Escaping)
# ====================================================================

def _escape_html_except_tags(text):
    """تهريب محارف HTML مع الاحتفاظ بوسوم Telegram المسموحة.
    
    الوسوم المسموحة: <b>, <strong>, <i>, <em>, <u>, <ins>, <s>, <strike>,
    <del>, <code>, <pre>, <a href="...">, <blockquote>"""
    if not text:
        return text

    allowed_tags_re = re.compile(
        r'(<(/?)(tg-spoiler|b|strong|i|em|u|ins|s|strike|del|code|pre|a|blockquote)'
        r'(\s+href=["\'][^"\']*["\'])?\s*/?>)',
        re.IGNORECASE
    )

    # استبدال مؤقت للوسوم المسموحة
    tag_placeholders = {}
    counter = [0]

    def replace_tag(match):
        counter[0] += 1
        placeholder = f"\x01TAG_{counter[0]:04d}\x01"
        tag_placeholders[placeholder] = match.group(0)
        return placeholder

    # أولاً: نحول الوسوم الحقيقية إلى HTML entities مؤقتاً للحماية
    # ثم نهرّب كل المحارف
    # ثم نستعيد الوسوم المسموحة

    # الخطوة 1: حماية الوسوم المسموحة
    protected = allowed_tags_re.sub(replace_tag, text)

    # الخطوة 2: تهريب كل ما تبقى
    escaped = (protected
               .replace('&', '&amp;')
               .replace('<', '&lt;')
               .replace('>', '&gt;'))

    # الخطوة 3: استعادة الوسوم المسموحة
    for placeholder, original_tag in tag_placeholders.items():
        escaped = escaped.replace(placeholder, original_tag, 1)

    return escaped


def _escape_markdown_v2(text):
    """تهريب محارف MarkdownV2 المحجوزة بشرطة مائلة عكسية."""
    if not text:
        return text
    for char in MARKDOWN_V2_RESERVED_CHARS:
        text = text.replace(char, '\\' + char)
    return text


def _escape_telegram_html(text):
    """تهريب نص للاستخدام في Telegram HTML parse_mode.
    
    يهرّب < > & لكنه يحافظ على وسوم Telegram المسموحة."""
    return _escape_html_except_tags(text)


# ====================================================================
#          تحويل Markdown إلى Telegram HTML
# ====================================================================

def _convert_markdown_to_html(text):
    """تحويل تنسيق Markdown شائع إلى Telegram HTML.
    
    يدعم:
    - **bold** → <b>bold</b>
    - *italic* → <i>italic</i>
    - __underline__ → <u>underline</u>
    - ~~strikethrough~~ → <s>strikethrough</s>
    - [link](url) → <a href="url">link</a>
    - `inline code` → <code>inline code</code>
    - > quote → <blockquote>quote</blockquote>
    - # heading → <b>heading</b>
    - قوائم نقطية ومرقمة
    """
    if not text:
        return text

    lines = text.split('\n')
    result_lines = []
    in_list = False
    list_type = None  # 'ul' or 'ol'
    list_items = []

    for line in lines:
        stripped = line.strip()

        # اكتشاف الاقتباسات (blockquotes)
        if stripped.startswith('>'):
            quote_text = stripped[1:].strip()
            result_lines.append(f'<blockquote>{html.escape(quote_text, quote=False)}</blockquote>')
            continue

        # اكتشاف العناوين
        if re.match(r'^#{1,6}\s', stripped):
            heading_text = re.sub(r'^#{1,6}\s*', '', stripped)
            result_lines.append(f'<b>{html.escape(heading_text, quote=False)}</b>')
            continue

        # اكتشاف القوائم النقطية
        if re.match(r'^[-*•]\s', stripped):
            item_text = re.sub(r'^[-*•]\s*', '', stripped)
            item_html = _convert_inline_markdown(item_text)
            list_items.append(f'• {item_html}')
            continue

        # اكتشاف القوائم المرقمة
        numbered_match = re.match(r'^(\d+)\.\s+(.*)', stripped)
        if numbered_match:
            item_html = _convert_inline_markdown(numbered_match.group(2))
            list_items.append(f'{numbered_match.group(1)}. {item_html}')
            continue

        # إذا وصلنا هنا ولدينا عناصر قائمة متراكمة، أضفها
        if list_items:
            result_lines.extend(list_items)
            list_items = []

        # السطر العادي - تحويل inline markdown
        if stripped:
            result_lines.append(_convert_inline_markdown(line))
        else:
            result_lines.append('')

    # أضف أي عناصر قائمة متبقية
    if list_items:
        result_lines.extend(list_items)

    return '\n'.join(result_lines)


def _convert_inline_markdown(text):
    """تحويل inline Markdown إلى Telegram HTML."""
    if not text:
        return text

    # ||spoiler|| → <tg-spoiler>...</tg-spoiler>
    text = re.sub(r'\|\|(.+?)\|\|', r'<tg-spoiler>\1</tg-spoiler>', text)

    # **bold** → <b>...</b>
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)

    # __underline__ → <u>...</u>
    text = re.sub(r'__(.+?)__', r'<u>\1</u>', text)

    # ~~strikethrough~~ → <s>...</s>
    text = re.sub(r'~~(.+?)~~', r'<s>\1</s>', text)

    # *italic* → <i>...</i> (ولكن ليس داخل وسوم موجودة)
    # نتجنب تكرار ما سبق تحويله من **bold**
    text = re.sub(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)', r'<i>\1</i>', text)

    # [link](url) → <a href="url">link</a>
    text = re.sub(
        r'\[([^\]]+)\]\(([^)]+)\)',
        lambda m: f'<a href="{html.escape(m.group(2), quote=True)}">{html.escape(m.group(1), quote=False)}</a>',
        text
    )

    return text


# ====================================================================
#            معالجة الجداول (Table Support)
# ====================================================================

def _convert_tables_to_html(text):
    """تحويل جداول Markdown إلى HTML بسيط.
    
    | Header 1 | Header 2 |
    |----------|----------|
    | Cell 1   | Cell 2   |
    """
    if not text or '|' not in text:
        return text

    lines = text.split('\n')
    result_lines = []
    table_buffer = []
    in_table = False

    for line in lines:
        stripped = line.strip()

        # هل هذا سطر جدول؟
        if stripped.startswith('|') and stripped.endswith('|'):
            in_table = True
            # تخطي سطر الفاصل (|---|---|)
            if re.match(r'\|[\s\-:]+\|', stripped):
                continue
            # استخراج الخلايا
            cells = [cell.strip() for cell in stripped[1:-1].split('|')]
            table_buffer.append(cells)
        else:
            if in_table and table_buffer:
                # انتهى الجدول، حوّله إلى HTML
                result_lines.append(_render_table_html(table_buffer))
                table_buffer = []
                in_table = False
            result_lines.append(line)

    # جدول متبقي في نهاية النص
    if table_buffer:
        result_lines.append(_render_table_html(table_buffer))

    return '\n'.join(result_lines)


def _render_table_html(rows):
    """تصيير جدول كـ HTML تلغرام."""
    if not rows:
        return ''

    lines = ['<pre>']
    for i, row in enumerate(rows):
        escaped_cells = [html.escape(str(cell), quote=False) for cell in row]
        if i == 0:
            # السطر الأول كعنوان
            lines.append(' | '.join(escaped_cells))
            lines.append('-' * max(len(' | '.join(escaped_cells)), 10))
        else:
            lines.append(' | '.join(escaped_cells))
    lines.append('</pre>')
    return '\n'.join(lines)


# ====================================================================
#             دالة التنسيق الرئيسية (Core API)
# ====================================================================

def format_for_telegram(text, parse_mode='HTML', protect_code=True):
    """الدالة الرئيسية لتنسيق أي نص لإرساله عبر Telegram.
    
    تقوم بـ:
    1. حماية كتل الأكواد (إذا protect_code=True)
    2. تحويل Markdown إلى HTML (إذا كان النمط HTML)
    3. تهريب المحارف المحجوزة للنمط المختار
    4. استعادة كتل الأكواد بتنسيقها الصحيح
    5. تحويل الجداول إن وجدت
    
    المعاملات:
        text: النص المراد تنسيقه
        parse_mode: 'HTML', 'Markdown', أو 'MarkdownV2'
        protect_code: حماية كتل الأكواد من التعديل
    
    تُعاد: النص المُنسَّق الجاهز للإرسال
    """
    if not text:
        return text

    parse_mode = (parse_mode or DEFAULT_PARSE_MODE).strip()
    if parse_mode not in SUPPORTED_PARSE_MODES:
        parse_mode = DEFAULT_PARSE_MODE

    protector = _CodeProtector()

    # الخطوة 1: حماية كتل الأكواد
    protected_text, placeholders = protector.protect_code_blocks(text) if protect_code else (text, {})

    # الخطوة 2: تحويل الجداول (قبل التهريب)
    if '|' in protected_text and '\n' in protected_text:
        protected_text = _convert_tables_to_html(protected_text)

    # الخطوة 3: تحويل/تهريب حسب نمط التحليل
    if parse_mode == 'HTML':
        # تحويل Markdown إلى HTML أولاً
        processed = _convert_markdown_to_html(protected_text)
        # تهريب HTML للنص العادي (مع الحفاظ على وسوم Telegram)
        processed = _escape_telegram_html(processed)
    elif parse_mode == 'MarkdownV2':
        # تهريب محارف MarkdownV2
        processed = _escape_markdown_v2(protected_text)
    elif parse_mode == 'Markdown':
        # Markdown العادي لا يحتاج تهريباً كبيراً
        processed = protected_text
    else:
        processed = protected_text

    # الخطوة 4: استعادة كتل الأكواد
    if protect_code and placeholders:
        processed = protector.restore_code_blocks(processed, placeholders, parse_mode)

    # الخطوة 5: تنظيف نهائي
    processed = _final_cleanup(processed)

    return processed


def format_ai_response(text, parse_mode='HTML', lang='ar'):
    """تنسيق رد الذكاء الاصطناعي للإرسال عبر Telegram.
    
    هذه الدالة مخصصة لردود AI وتضمن:
    - حماية كاملة لكتل الأكواد
    - تحويل Markdown إلى HTML
    - تهريب آمن لجميع المحارف
    - الحفاظ على معنى النص الأصلي
    
    إذا فشل التنسيق، تُعاد النص الأصلي كما هو."""
    try:
        if not text:
            return text
        return format_for_telegram(text, parse_mode=parse_mode, protect_code=True)
    except Exception:
        # فشل التنسيق → أعد النص الأصلي دون تعديل
        return text


def escape_telegram_text(text, parse_mode='HTML'):
    """تهريب نص عادي للاستخدام في Telegram.
    
    مفيد للرسائل الثابتة والنصوص التي لا تحتوي على تنسيق مقصود."""
    if not text:
        return text

    parse_mode = (parse_mode or DEFAULT_PARSE_MODE).strip()

    if parse_mode == 'HTML':
        return html.escape(str(text), quote=False)
    elif parse_mode == 'MarkdownV2':
        return _escape_markdown_v2(str(text))
    return text


def safe_format(text, parse_mode='HTML', fallback=None):
    """تنسيق آمن مع قيمة احتياطية عند الفشل.
    
    تُعاد fallback إذا فشل التنسيق، أو النص الأصلي إذا لم تُحدد fallback."""
    try:
        return format_for_telegram(text, parse_mode=parse_mode, protect_code=True)
    except Exception:
        return fallback if fallback is not None else text


# ====================================================================
#              التنظيف النهائي (Final Cleanup)
# ====================================================================

def _final_cleanup(text):
    """تنظيف نهائي للنص قبل الإرسال."""
    if not text:
        return text

    # إزالة أي null bytes تبقّت
    text = text.replace('\x00', '')
    text = text.replace('\x01', '')

    # إزالة أسطر فارغة متكررة (أكثر من 2 متتالية)
    while '\n\n\n\n' in text:
        text = text.replace('\n\n\n\n', '\n\n\n')

    return text


# ====================================================================
#         تكامل مع send_message و edit_message_text
# ====================================================================

def prepare_message_text(text, parse_mode='HTML', auto_escape=True):
    """تحضير نص الرسالة قبل الإرسال عبر Telegram API.
    
    تُستخدم في send_message و edit_message_text في telegram_api.py
    لضمان أن جميع الرسائل تمر عبر محرك التنسيق.
    
    المعاملات:
        text: النص المراد إرساله
        parse_mode: نمط التحليل
        auto_escape: تفعيل التهريج التلقائي
    
    تُعاد: النص المُحضَّر الجاهز للإرسال
    """
    if not text or not auto_escape:
        return text

    # إذا كان parse_mode HTML، نطبق محرك التنسيق
    if parse_mode == 'HTML':
        return format_ai_response(text, parse_mode='HTML')
    elif parse_mode == 'MarkdownV2':
        return format_ai_response(text, parse_mode='MarkdownV2')
    elif parse_mode == 'Markdown':
        return format_ai_response(text, parse_mode='Markdown')

    return text


# ====================================================================
#              اختصارات للاستخدام السريع
# ====================================================================

fmt = format_for_telegram  # اختصار
fmt_ai = format_ai_response  # اختصار لردود AI
esc = escape_telegram_text  # اختصار للتهريب


# ====================================================================
#              نهاية الملف
# ====================================================================
