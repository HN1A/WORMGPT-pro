import time
from config import session, URL, ADMIN, VIP_DURATIONS, DURATION_LABELS, data
from i18n import get_user_language, t
from telegram_api import send_message, send_photo, get_best_profile_photo_file_id
from buttons import main_buttons
from vip_system import add_vip

# ========================================================================
#                      معالجة دفعات نجوم تلجرام (Telegram Stars)
# ========================================================================

# رسائل خاصة بخدمة معالجة الدفع (تظهر للمستخدم/الأدمن في سياقات دقيقة)
PAYMENT_ERROR_UNKNOWN = {
    'ar': 'حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى.',
    'en': 'An unexpected error occurred, please try again.',
    'ru': 'Произошла непредвиденная ошибка, попробуйте ещё раз.',
    'zh': '发生意外错误，请重试。',
    'fa': 'خطای غیرمنتظره‌ای رخ داد، لطفاً دوباره تلاش کنید.',
}

def handle_pre_checkout_query(pre_checkout_query):
    """الرد الفوري (إلزامي ضمن 10 ثوان) على استعلام الدفع المسبق لتأكيد إمكانية إتمام الدفع"""
    query_id = pre_checkout_query.get('id')
    payload = pre_checkout_query.get('invoice_payload', '')
    try:
        if payload.startswith('vip_stars_'):
            session.post(f"{URL}/answerPreCheckoutQuery", json={"pre_checkout_query_id": query_id, "ok": True})
        else:
            session.post(f"{URL}/answerPreCheckoutQuery", json={
                "pre_checkout_query_id": query_id, "ok": False,
                "error_message": PAYMENT_ERROR_UNKNOWN.get('ar', PAYMENT_ERROR_UNKNOWN['ar'])
            })
    except Exception as e:
        print(f"Error answering pre-checkout query: {e}")

def handle_successful_payment(chat_id, user_id, username, first_name, payment_info):
    """معالجة دفعة نجوم تلجرام المكتملة: تفعيل اشتراك VIP، إشعار الأدمن، وإرسال رسالة ترحيبية للمستخدم"""
    lang = get_user_language(user_id)
    payload = payment_info.get('invoice_payload', '')

    duration_key = None
    parts = payload.split('_')
    if payload.startswith('vip_stars_') and len(parts) >= 3:
        candidate = parts[2]
        if candidate in VIP_DURATIONS:
            duration_key = candidate

    if not duration_key:
        print(f"[Stars Payment] payload غير معروف أو غير صالح: {payload}")
        return

    new_expiry = add_vip(user_id, VIP_DURATIONS[duration_key])
    expiry_text = time.strftime('%Y-%m-%d %H:%M', time.localtime(new_expiry))

    welcome_text = t('vip_payment_welcome', lang, expiry=expiry_text)
    send_message(chat_id, welcome_text, parse_mode='HTML', reply_markup=main_buttons(lang, user_id=user_id))

    username_display = f"@{username}" if username else "—"
    subscribed_at = time.strftime('%Y-%m-%d %H:%M:%S')
    user_info = data.get(str(user_id), {})
    joined_at = user_info.get('joined_at', '—')
    total_sent = user_info.get('total_messages_sent', 0)
    charge_id = payment_info.get('telegram_payment_charge_id', '—')

    for admin_id in ADMIN:
        admin_lang = get_user_language(admin_id)
        duration_label_admin = DURATION_LABELS.get(duration_key, {}).get(admin_lang, duration_key)
        admin_notice = t(
            'admin_vip_payment_notice', admin_lang,
            name=first_name, username=username_display, user_id=user_id,
            duration=duration_label_admin, amount=payment_info.get('total_amount', 0),
            charge_id=charge_id, subscribed_at=subscribed_at, expiry=expiry_text,
            joined_at=joined_at, total_sent=total_sent
        )
        photo_file_id = get_best_profile_photo_file_id(user_id)
        try:
            if photo_file_id:
                send_photo(admin_id, photo_file_id, caption=admin_notice, parse_mode='HTML')
            else:
                send_message(admin_id, admin_notice, parse_mode='HTML')
        except Exception as e:
            print(f"Error notifying admin of payment: {e}")

