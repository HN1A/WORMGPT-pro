import time
from config import (ADMIN, data, save_data, DEFAULT_MESSAGES_LIMIT, V2_TRIAL_LIMIT,
                     MAX_HISTORY, MAX_HISTORY_VIP, BOT_USERNAME, user_research_model)

# ========================================================================
#                      إعادة تعيين رصيد V2 كل 24 ساعة
# ========================================================================
_V2_DAILY_RESET_SECONDS = 24 * 60 * 60   # 24 ساعة بالثواني

def _reset_v2_trials_if_needed(user_id):
    """يفحص آخر وقت تعيين لـ V2 — إذا مرّت 24 ساعة يُعيد الرصيد إلى 3 مؤات"""
    uid = str(user_id)
    if uid not in data:
        return
    now = time.time()
    last_reset = data[uid].get('v2_last_reset', 0)
    if now - last_reset >= _V2_DAILY_RESET_SECONDS:
        data[uid]['v2_trials_used'] = 0
        data[uid]['v2_last_reset'] = now
        save_data()

# ========================================================================
#                      دوال VIP ورصيد الرسائل وتجديدها
# ========================================================================

def is_vip(user_id):
    """التحقق إذا كان المستخدم VIP وغير منتهي الصلاحية"""
    user_data = data.get(str(user_id))
    if not user_data:
        return False
    vip_until = user_data.get('vip_until', 0)
    return vip_until > time.time()

def get_vip_expiry_text(user_id):
    """نص يوضح تاريخ ووقت انتهاء اشتراك VIP للمستخدم (أو None إذا لم يكن VIP)"""
    user_data = data.get(str(user_id), {})
    vip_until = user_data.get('vip_until', 0)
    if vip_until <= time.time():
        return None
    return time.strftime('%Y-%m-%d %H:%M', time.localtime(vip_until))

def get_all_vip_users():
    """تُعيد قائمة بكل مستخدمي VIP النشطين حالياً (غير منتهيي الصلاحية)، كل عنصر عبارة عن
    قاموس يحتوي: uid, name, username, expiry_text, vip_until (مرتبة تصاعدياً حسب وقت الانتهاء)"""
    now = time.time()
    vip_list = []
    for uid, info in data.items():
        vip_until = info.get('vip_until', 0)
        if vip_until > now:
            vip_list.append({
                'uid': uid,
                'name': info.get('name') or 'غير معروف',
                'username': info.get('username', ''),
                'vip_until': vip_until,
                'expiry_text': time.strftime('%Y-%m-%d %H:%M', time.localtime(vip_until))
            })
    vip_list.sort(key=lambda x: x['vip_until'])
    return vip_list

def add_vip(user_id, seconds):
    """تفعيل أو تمديد اشتراك VIP لمستخدم معين، تُعيد تاريخ انتهاء الاشتراك الجديد"""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': DEFAULT_MESSAGES_LIMIT, 'vip_until': 0}
    current = data[uid].get('vip_until', 0)
    base = max(current, time.time())
    data[uid]['vip_until'] = base + seconds
    save_data()
    return data[uid]['vip_until']

def get_messages_left(user_id):
    """رصيد الرسائل المتبقي للمستخدم"""
    user_data = data.get(str(user_id))
    if not user_data:
        return DEFAULT_MESSAGES_LIMIT
    return user_data.get('messages_left', DEFAULT_MESSAGES_LIMIT)

def consume_message(user_id):
    """خصم رسالة واحدة من رصيد المستخدم (تُستخدم لغير VIP فقط)"""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': DEFAULT_MESSAGES_LIMIT, 'vip_until': 0}
    current = data[uid].get('messages_left', DEFAULT_MESSAGES_LIMIT)
    current = max(0, current - 1)
    data[uid]['messages_left'] = current
    save_data()
    return current

def increment_message_count(user_id):
    """زيادة عداد إجمالي الرسائل التي أرسلها المستخدم (يُحسب لجميع المستخدمين، VIP وغير VIP، بخلاف
    consume_message الذي يخص رصيد غير VIP فقط) - يُستخدم في عرض لوحة معلومات الحساب"""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': DEFAULT_MESSAGES_LIMIT, 'vip_until': 0, 'total_messages_sent': 0}
    data[uid]['total_messages_sent'] = data[uid].get('total_messages_sent', 0) + 1
    save_data()
    return data[uid]['total_messages_sent']

def renew_messages(user_id, amount):
    """تجديد (إضافة) عدد رسائل لمستخدم معين، تُعيد الرصيد القديم والرصيد الجديد"""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': DEFAULT_MESSAGES_LIMIT, 'vip_until': 0}
    old_count = data[uid].get('messages_left', DEFAULT_MESSAGES_LIMIT)
    new_count = old_count + amount
    data[uid]['messages_left'] = new_count
    save_data()
    return old_count, new_count

def find_user_by_identifier(identifier):
    """
    البحث عن مستخدم بواسطة الايدي (أرقام) أو اليوزر (مع أو بدون @)
    تُعيد ايدي المستخدم (نص) إذا تم العثور عليه، أو None إذا لم يتم العثور على شيء
    """
    identifier = identifier.strip().lstrip('@')
    if not identifier:
        return None
    
    # إذا كان المدخل أرقاماً فقط -> اعتباره ايدي مباشرة
    if identifier.isdigit():
        return identifier
    
    # البحث عن طريق اليوزر المخزن في بيانات المستخدمين
    for uid, info in data.items():
        stored_username = (info.get('username') or '')
        if stored_username and stored_username.lower() == identifier.lower():
            return uid
    
    return None

def get_user_display(user_id):
    """ارجاع اسم ويوزر المستخدم جاهزين للعرض"""
    uid = str(user_id)
    info = data.get(uid, {})
    name = info.get('name') or 'غير معروف'
    username = info.get('username', '')
    username_display = f"@{username}" if username else "—"
    return name, username_display

# ========================================================================
#                      نظام النماذج (V1 / V2)
# ========================================================================

def get_user_model(user_id):
    """يُعيد النموذج المختار من المستخدم: 'v1' أو 'v2'. الافتراضي 'v2'
    (متطلب نظام التبديل التلقائي: البوت يعتمد افتراضياً على V2، ويتحوّل إلى V1
    تلقائياً عند فشل V2 أو نفاد رصيده عبر آلية Silent Failover في ai_engine)."""
    return data.get(str(user_id), {}).get('model', 'v2')

def set_user_model(user_id, model):
    """يحفظ اختيار النموذج للمستخدم"""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': DEFAULT_MESSAGES_LIMIT, 'vip_until': 0}
    data[uid]['model'] = model
    save_data()

# ========================================================================
#                      نظام الإحالة (Referral)
# ========================================================================

def get_referral_link(user_id):
    """رابط الإحالة الخاص بالمستخدم"""
    return f"https://t.me/{BOT_USERNAME}?start={user_id}"


def get_ref_count(user_id):
    """عدد المستخدمين الذين انضموا عبر رابط هذا المستخدم"""
    return data.get(str(user_id), {}).get('ref_count', 0)


def get_ref_bonus_v2(user_id):
    """إجمالي رسائل V2 الإضافية المكتسبة من الإحالات"""
    return data.get(str(user_id), {}).get('ref_bonus_v2', 0)


def add_referral_bonus(referrer_id):
    """يُضاف +2 رسالة V2 يومية للمُحيل عند كل انضمام ناجح عبر رابطه"""
    uid = str(referrer_id)
    if uid not in data:
        return False
    data[uid]['ref_count']    = data[uid].get('ref_count', 0) + 1
    data[uid]['ref_bonus_v2'] = data[uid].get('ref_bonus_v2', 0) + 2
    save_data()
    return True


def process_referral(new_user_id, referrer_id):
    """معالجة رابط الإحالة عند أول /start — لا تُطبَّق إلا مرة واحدة"""
    new_uid = str(new_user_id)
    ref_uid = str(referrer_id)
    # تجنّب الإحالة الذاتية أو التكرار
    if str(new_user_id) == str(referrer_id):
        return False
    if data.get(new_uid, {}).get('ref_by'):
        return False   # سبق تسجيل إحالة لهذا المستخدم
    if ref_uid not in data:
        return False
    data[new_uid]['ref_by'] = referrer_id
    save_data()
    add_referral_bonus(referrer_id)
    return True


def get_v2_trials_left(user_id):
    """عدد رسائل V2 اليومية المتبقية (4 أساسية + مكافآت الإحالة، تُجدَّد كل 24 ساعة)"""
    _reset_v2_trials_if_needed(user_id)
    used  = data.get(str(user_id), {}).get('v2_trials_used', 0)
    bonus = get_ref_bonus_v2(user_id)
    daily_limit = V2_TRIAL_LIMIT + bonus
    return max(0, daily_limit - used)

def consume_v2_trial(user_id):
    """خصم رسالة تجريبية واحدة من رصيد V2 للمستخدم. تُعيد العدد المتبقي."""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': DEFAULT_MESSAGES_LIMIT, 'vip_until': 0}
    _reset_v2_trials_if_needed(user_id)   # تحقق من الإعادة اليومية قبل الخصم
    used = data[uid].get('v2_trials_used', 0)
    data[uid]['v2_trials_used'] = used + 1
    save_data()
    return max(0, V2_TRIAL_LIMIT - (used + 1))

def has_v2_access(user_id):
    """يُعيد True إذا كان المستخدم يملك حق استخدام V2:
    • الأدمن: دائماً ✓
    • مشترك VIP: ✓
    • لم تنته رسائله التجريبية: ✓
    """
    if user_id in ADMIN:
        return True
    if is_vip(user_id):
        return True
    return get_v2_trials_left(user_id) > 0

def get_history_limit(user_id):
    """يُعيد حد الذاكرة (عدد الرسائل) بحسب حالة الاشتراك:
    • أدمن: MAX_HISTORY_VIP × 2 (ذاكرة مضاعفة)
    • مشترك VIP: MAX_HISTORY_VIP (20)
    • غير مشترك: MAX_HISTORY (10)
    """
    if user_id in ADMIN:
        return MAX_HISTORY_VIP * 2   # الأدمن لديه ذاكرة مضاعفة مقارنةً بـ VIP
    if is_vip(user_id):
        return MAX_HISTORY_VIP
    return MAX_HISTORY


# ========================================================================
#                      نظام نماذج البحث (WORMGPT-research-V1/V2)
# ========================================================================

def get_research_model(user_id):
    """يُعيد نموذج البحث المختار للمستخدم: 'research_v1' (افتراضي) أو 'research_v2'
    كل المستخدمين يبدأون بـ V1، ولا يُحدَّث النموذج تلقائياً."""
    return user_research_model.get(user_id, 'research_v1')


def set_research_model(user_id, model):
    """يحفظ نموذج البحث المختار. لا يخصم من رصيد المستخدم — فقط تحديث التفضيل."""
    user_research_model[user_id] = model


def can_use_research_v2(user_id):
    """يُعيد True إذا كان المستخدم يستطيع استخدام WORMGPT-research-V2.
    V2 مقصور على الأدمن والمشتركين VIP فقط."""
    if user_id in ADMIN:
        return True
    if is_vip(user_id):
        return True
    return False


# ============================================================================================
#                      نظام حدود التفكير (WORMGPT Thinking — 3 مجانية / يوم)
# ============================================================================================

_THINKING_DAILY_RESET_SECONDS = 24 * 60 * 60   # 24 ساعة بالثواني


def _reset_thinking_trials_if_needed(user_id):
    """يفحص آخر وقت تعيين لرسائل التفكير — إذا مرّت 24 ساعة يُعيد الرصيد إلى 0"""
    uid = str(user_id)
    if uid not in data:
        return
    now = time.time()
    last_reset = data[uid].get('thinking_last_reset', 0)
    if now - last_reset >= _THINKING_DAILY_RESET_SECONDS:
        data[uid]['thinking_trials_used'] = 0
        data[uid]['thinking_last_reset'] = now
        save_data()


def get_thinking_trials_left(user_id):
    """عدد رسائل التفكير اليومية المتبقية (3 للمجاني، ∞ للـ VIP/أدمن)."""
    from config import THINKING_FREE_DAILY_LIMIT
    if user_id in ADMIN:
        return 999999  # الأدمن: غير محدود
    if is_vip(user_id):
        return 999999  # VIP: غير محدود
    _reset_thinking_trials_if_needed(user_id)
    used = data.get(str(user_id), {}).get('thinking_trials_used', 0)
    return max(0, THINKING_FREE_DAILY_LIMIT - used)


def consume_thinking_trial(user_id):
    """خصم رسالة تفكير واحدة من رصيد المستخدم. تُعيد True إذا نجح، False إذا انتهى الرصيد."""
    uid = str(user_id)
    if uid not in data:
        data[uid] = {'name': '', 'username': '', 'joined_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                      'messages_left': 20, 'vip_until': 0}
    # الأدمن و VIP لا يحتاجون خصماً
    if user_id in ADMIN or is_vip(user_id):
        data[uid]['thinking_trials_used'] = data[uid].get('thinking_trials_used', 0)
        save_data()
        return True
    _reset_thinking_trials_if_needed(user_id)
    used = data[uid].get('thinking_trials_used', 0)
    from config import THINKING_FREE_DAILY_LIMIT
    if used >= THINKING_FREE_DAILY_LIMIT:
        return False
    data[uid]['thinking_trials_used'] = used + 1
    save_data()
    return True


def has_thinking_access(user_id):
    """يُعيد True إذا كان المستخدم يملك حق استخدام وضع التفكير:
    • الأدمن: دائماً ✓
    • مشترك VIP: دائماً ✓
    • لم تنتهِ رسائله التجريبية (3/يوم): ✓
    """
    if user_id in ADMIN:
        return True
    if is_vip(user_id):
        return True
    return get_thinking_trials_left(user_id) > 0


def get_thinking_context_limit(user_id):
    """يُعيد حد سياق التفكير (عدد الرسائل المحفوظة):
    • أدمن/VIP: 10+
    • غير مشترك: 3
    """
    from config import THINKING_VIP_CONTEXT_LIMIT, THINKING_FREE_CONTEXT_LIMIT
    if user_id in ADMIN or is_vip(user_id):
        return THINKING_VIP_CONTEXT_LIMIT
    return THINKING_FREE_CONTEXT_LIMIT

