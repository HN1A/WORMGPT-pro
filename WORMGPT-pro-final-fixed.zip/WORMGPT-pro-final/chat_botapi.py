import time
import traceback
from bot_logger import log_error, log_info, log_warning
from config import (OWNER_NAME, CHANNEL, OWNER_USER, URL, session, ADMIN, user_states,
                     photo_pending, is_maintenance_mode, file_pending,
                     research_image_pending)
from i18n import get_user_language, ensure_user_language_detected, t
from buttons import main_buttons
from telegram_api import send_message, answer_callback_query
from channels_db import add_channel, remove_channel, is_user_banned
from admin_flows import handle_renew_user_input, handle_renew_amount_input, handle_vip_user_input, handle_broadcast_message_input, handle_cancel_vip_user_input
from payments import handle_pre_checkout_query, handle_successful_payment
from user_handlers import (handle_start, handle_clear, handle_info, handle_admin, handle_help, handle_photo_message, handle_language_command,
                            handle_normal_message, handle_search, handle_support_message_input, handle_support_reply_input,
                            handle_document_message, handle_file_instruction_input,
                            handle_research_v2_photo_resume, handle_thinking_message, handle_thinking_file)
from callback_handler import handle_callback
from bot_commands import register_bot_commands

offset = None

# ===== تسجيل أوامر البوت عند بدء التشغيل =====
try:
    register_bot_commands(admin_ids=ADMIN)
except Exception as e:
    log_error(f"Failed to register bot commands on startup: {e}")

# ========================================================================
#                      الحلقة الرئيسية
# ========================================================================

print('=' * 60)
print(f'   {OWNER_NAME} — وورم جي بي تي V24')
print('   غير مقيد • بحث مدمج • ذاكرة قوية')
print(f'   CH: {CHANNEL} • DEV: {OWNER_USER}')
print('=' * 60)
print()
print('[✓] البوت شغال - وورم جي بي تي')
print('[✓] الوضع: غير مقيد بالكامل')
print('[✓] الذاكرة: 20 رسالة')
print('[✓] فهم السياق: مفعل')
print('[✓] البحث مدمج ذكياً')
print('[✓] الاكواد: ملفات + زر نسخ')
print('[✓] الاكواد الصغيرة تظهر مباشرة')
print('[✓] الاكواد الكبيرة تحفظ كملف')
print('[✓] تنسيق الاكواد: HTML/Pre (محسن)')
print('[✓] الكتابة التدريجية: مفعلة (فائقة السرعة 0.03 ثانية)')
print(f'[✓] المطور: {OWNER_USER}')
print()
print('💀 وورم جي بي تي جاهز')
print('🧠 يتذكر المحادثة ويفهم السياق')
print('🔍 بحث مدمج يفهم طلبك')
print('📎 الكود: صغير يظهر | كبير ملف')
print('📝 تنسيق الأكواد باستخدام علامات HTML/Pre مع تنظيف تلقائي')
print('✍️ الكتابة التدريجية سريعة جداً')
print('🚀 البوت شغال 24/7')
print('📢 زر شفاف لقناة المطور')
print('🎨 الأزرار ملونة: success أخضر | danger أحمر | primary أزرق')
print()
print('🔄 التعديلات الجديدة:')
print('   ✅ تم تحسين تنسيق الأكواد باستخدام HTML مع علامات pre/code')
print('   ✅ الأكواد الصغيرة (≤15 أسطر، ≤800 حرف) تظهر مباشرة')
print('   ✅ الأكواد الكبيرة تحفظ كملف')
print('   ✅ تنظيف تلقائي للأكواد من المسافات الزائدة')
print('   ✅ الحفاظ على المسافات البادئة للكود')
print('   ✅ إزالة التكرارات في كتل الأكواد')
print('   ✅ تحسين استخراج كتل الأكواد من الرد')
print()

while True:
    try:
        response = session.get(f"{URL}/getUpdates", params={"timeout": 100, "offset": offset})
        updates = response.json().get("result", [])

        for update in updates:
            try:
                offset = update["update_id"] + 1

                # معالجة callback_query (الأزرار)
                if "callback_query" in update:
                    cb_user_id = update["callback_query"].get('from', {}).get('id')
                    ensure_user_language_detected(cb_user_id, update["callback_query"].get('from', {}).get('language_code'))
                    # فحص الحظر
                    if is_user_banned(cb_user_id) and cb_user_id not in ADMIN:
                        answer_callback_query(update["callback_query"].get('id'), t('user_banned_message', get_user_language(cb_user_id)), show_alert=True)
                        continue
                    if is_maintenance_mode() and cb_user_id not in ADMIN:
                        cb_lang = get_user_language(cb_user_id)
                        answer_callback_query(update["callback_query"].get('id'), t('maintenance_notice_alert', cb_lang), show_alert=True)
                        continue
                    handle_callback(update["callback_query"])

                # معالجة استعلام الدفع المسبق (نجوم تلجرام) - يجب الرد خلال 10 ثوان
                elif "pre_checkout_query" in update:
                    handle_pre_checkout_query(update["pre_checkout_query"])

                # معالجة الرسائل
                elif "message" in update:
                    message = update["message"]
                    chat_id = message["chat"]["id"]
                    user_id = message["from"]["id"]
                    username = message["from"].get("username", "")
                    first_name = message["from"].get("first_name", "")
                    text = message.get("text", "")

                    # ===== دعم Reply في Telegram =====
                    # اكتشاف إذا كانت الرسالة رداً على رسالة سابقة للبوت
                    reply_context = None
                    reply_to = message.get("reply_to_message")
                    if reply_to:
                        # جلب نص الرسالة الأصلية (التي رد عليها المستخدم)
                        replied_text = reply_to.get("text", "")
                        replied_caption = reply_to.get("caption", "")
                        original_text = replied_text or replied_caption or ""
                        # جلب معرف المرسل الأصلي للتحقق من أنها رسالة البوت
                        reply_from_id = reply_to.get("from", {}).get("id")
                        # نحفظ السياق حتى لو لم تكن رسالة البوت (لأن المستخدم قد يرد على رسالة أخرى)
                        if original_text:
                            reply_context = {
                                'original_text': original_text,
                                'reply_from_id': reply_from_id,
                                'reply_message_id': reply_to.get('message_id'),
                                'reply_date': reply_to.get('date'),
                                'is_bot_message': bool(reply_from_id and reply_from_id != user_id)
                            }

                    # ===== فحص الحظر (قبل أي معالجة) =====
                    if is_user_banned(user_id) and user_id not in ADMIN:
                        send_message(chat_id, t('user_banned_message', get_user_language(user_id)), parse_mode='HTML')
                        continue

                    # ===== معالجة الصور =====
                    if "photo" in message:
                        # اختيار أعلى جودة (آخر عنصر في القائمة)
                        photo_list = message["photo"]
                        best_photo = photo_list[-1]
                        file_id    = best_photo.get("file_id", "")
                        caption    = message.get("caption", "")
                        handle_photo_message(chat_id, user_id, file_id, caption)
                        continue

                    # ===== معالجة الملفات المرفوعة (V2 File Upload + وضع التفكير) =====
                    if "document" in message:
                        doc = message["document"]
                        file_id   = doc.get("file_id", "")
                        file_name = doc.get("file_name", "") or ""
                        file_size = doc.get("file_size", 0) or 0
                        caption   = message.get("caption", "") or ""
                        # فحص إذا كان المستخدم في وضع التفكير
                        if user_id in user_states and user_states.get(user_id) == 'waiting_thinking':
                            # معالجة الملف في وضع التفكير
                            from config import SUPPORTED_FILE_EXTENSIONS, FILE_MAX_BYTES, FILE_MAX_LINES
                            import os
                            lang = get_user_language(user_id)
                            # فحص الامتداد
                            file_ext = os.path.splitext(file_name)[1].lower()
                            if file_ext not in SUPPORTED_FILE_EXTENSIONS:
                                send_message(chat_id, f"⚠️ امتداد الملف غير مدعوم في وضع التفكير: {file_ext}",
                                             parse_mode='HTML')
                                continue
                            # فحص الحجم
                            if file_size > FILE_MAX_BYTES:
                                send_message(chat_id, t('thinking_file_too_large', lang),
                                             parse_mode='HTML')
                                continue
                            # تنزيل وقراءة الملف
                            from telegram_api import get_file, download_file_bytes
                            try:
                                file_info = get_file(file_id)
                                if not file_info or not file_info.get('file_path'):
                                    send_message(chat_id, "❌ تعذر تنزيل الملف.", parse_mode='HTML')
                                    continue
                                file_bytes = download_file_bytes(file_info['file_path'])
                                if not file_bytes:
                                    send_message(chat_id, "❌ تعذر قراءة الملف.", parse_mode='HTML')
                                    continue
                                file_content = file_bytes.decode('utf-8', errors='replace')
                                lines = file_content.splitlines()
                                line_count = len(lines)
                                # إرسال للتفكير
                                handle_thinking_file(chat_id, user_id, file_id, file_name, file_content, line_count)
                            except Exception as e:
                                log_error(f"Error processing thinking file: {e}", user_id=user_id, exc=e)
                                send_message(chat_id, "❌ خطأ في معالجة الملف.", parse_mode='HTML')
                            continue
                        else:
                            handle_document_message(chat_id, user_id, file_id, file_name, file_size, caption)
                        continue

                    # تحديد لغة المستخدم تلقائياً عند أول تواصل
                    ensure_user_language_detected(user_id, message.get('from', {}).get('language_code'))

                    # دفعة نجوم تلجرام مكتملة - تُعالَج دائماً بصرف النظر عن وضع الصيانة
                    if message.get('successful_payment'):
                        handle_successful_payment(chat_id, user_id, username, first_name, message['successful_payment'])
                        continue

                    # وضع الصيانة: يستثني الأدمن فقط
                    if is_maintenance_mode() and user_id not in ADMIN:
                        send_message(chat_id, t('maintenance_notice', get_user_language(user_id)), parse_mode='HTML')
                        continue

                    # معالجة حالات انتظار الإدخال
                    if user_id in user_states:
                        state = user_states[user_id]
                        # ===== وضع البحث — مُحسَّن (المطلوب 5) =====
                        # المستخدم يبقى في وضع البحث حتى يضغط "إنهاء البحث" أو يلغي.
                        # لا نحذف user_states[user_id] بعد كل رسالة — فقط cancel_search يفعل ذلك.
                        if state == 'waiting_search':
                            lang = get_user_language(user_id)
                            handle_search(chat_id, user_id, text, reply_context=reply_context)
                            # المحافظة على وضع البحث — لا تحذف user_states[user_id]
                            # لا يُرسل القائمة الرئيسية هنا — البحث يدير أزراره بنفسه
                        elif state == 'waiting_search_text':
                            # ===== بحث نصي V1 عبر WORMGPT Research V1 =====
                            lang = get_user_language(user_id)
                            handle_search(chat_id, user_id, text, reply_context=reply_context)
                            # المحافظة على وضع البحث — لا تحذف user_states[user_id]
                            # لا يُرسل القائمة الرئيسية هنا — البحث يدير أزراره بنفسه
                        elif state == 'waiting_search_type':
                            # المستخدم اختار 'بحث كلام' ولم يحدد نصاً، أو كتب نصاً بعد اختيار النوع
                            # السلوك الافتراضي: تعامل النص كنص بحث
                            lang = get_user_language(user_id)
                            from vip_system import get_research_model as _grm
                            rmodel = _grm(user_id)
                            # إذا كان V2: أرسل النص للبحث V2 مباشرة
                            handle_search(chat_id, user_id, text, reply_context=reply_context)
                            # المحافظة على وضع البحث — لا تحذف user_states[user_id]
                            # لا يُرسل القائمة الرئيسية هنا — البحث يدير أزراره بنفسه
                        elif state == 'waiting_research_v2_text':
                            # المستخدم رفع صورة (في وضع بحث V2) ثم كتب نص -> ابحث بالصورة + النص
                            lang = get_user_language(user_id)
                            handle_research_v2_photo_resume(chat_id, user_id, text, reply_context=reply_context)
                            # المحافظة على وضع البحث — لا تحذف user_states[user_id]
                            # لا يُرسل القائمة الرئيسية هنا — البحث يدير أزراره بنفسه
                        elif state == 'waiting_research_v2_text_only':
                            # المستخدم اختار 'بحث كلام' مع V2 -> أرسل النص للبحث V2
                            lang = get_user_language(user_id)
                            from vip_system import set_research_model as _srm
                            _srm(user_id, 'research_v2')
                            handle_search(chat_id, user_id, text, reply_context=reply_context)
                            # المحافظة على وضع البحث — لا تحذف user_states[user_id]
                            # لا يُرسل القائمة الرئيسية هنا — البحث يدير أزراره بنفسه
                        elif state == 'waiting_add_channel':
                            add_channel(chat_id, user_id, text)
                            del user_states[user_id]
                        elif state == 'waiting_remove_channel':
                            remove_channel(chat_id, user_id, text)
                            del user_states[user_id]
                        elif state == 'waiting_broadcast_message':
                            handle_broadcast_message_input(chat_id, user_id, message)
                        elif state == 'waiting_renew_user':
                            handle_renew_user_input(chat_id, user_id, text)
                        elif state == 'waiting_renew_amount':
                            handle_renew_amount_input(chat_id, user_id, text)
                        elif state == 'waiting_vip_user':
                            handle_vip_user_input(chat_id, user_id, text)
                        elif state == 'waiting_support_message':
                            handle_support_message_input(chat_id, user_id, username, first_name, message)
                        elif state == 'waiting_support_reply':
                            handle_support_reply_input(chat_id, user_id, message)
                        elif state == 'waiting_file_instruction':
                            handle_file_instruction_input(chat_id, user_id, text)
                        elif state == 'waiting_ban_user':
                            from admin_flows import handle_ban_user_input
                            handle_ban_user_input(chat_id, user_id, text)
                            del user_states[user_id]
                        elif state == 'waiting_ban_reason':
                            from admin_flows import handle_ban_reason_input
                            handle_ban_reason_input(chat_id, user_id, text)
                        elif state == 'waiting_unban_user':
                            from admin_flows import handle_unban_user_input
                            handle_unban_user_input(chat_id, user_id, text)
                            del user_states[user_id]
                        elif state == 'waiting_stars_new_price':
                            from admin_flows import handle_stars_new_price_input
                            handle_stars_new_price_input(chat_id, user_id, text)
                        elif state == 'waiting_cancel_vip_user':
                            from admin_flows import handle_cancel_vip_user_input
                            handle_cancel_vip_user_input(chat_id, user_id, text)
                            user_states.pop(user_id, None)  # pop آمن لأن الدالة قد تزيل الحالة داخلياً
                        elif state == 'waiting_photo_description':
                            # المستخدم أرسل وصف/سؤال للصورة بعد الضغط على "لا شكراً"
                            from user_handlers import handle_photo_description_input
                            handle_photo_description_input(chat_id, user_id, text)
                            user_states.pop(user_id, None)
                        elif state == 'waiting_thinking':
                            # ===== وضع التفكير (WORMGPT Thinking) =====
                            # المستخدم في وضع التفكير — إرسال الرسالة لنظام التفكير مع دعم Reply
                            if text and text.strip():
                                handle_thinking_message(chat_id, user_id, text.strip(), reply_context=reply_context)
                            # المحافظة على وضع التفكير — لا تحذف user_states[user_id]
                            # المستخدم يبقى في وضع التفكير حتى يضغط "إنهاء التفكير"
                        continue

                    # الأوامر: /start /clear /info /admin /language
                    if text == '/start' or text.startswith('/start '):
                        # استخراج معامل الإحالة من /start USER_ID
                        start_param = text[7:].strip() if text.startswith('/start ') else None
                        handle_start(chat_id, user_id, username, first_name, start_param=start_param)
                    elif text == '/clear':
                        handle_clear(chat_id, user_id)
                    elif text == '/info' or text == '/i':
                        handle_info(chat_id, user_id)
                    elif text == '/admin':
                        handle_admin(chat_id, user_id)
                    elif text == '/language':
                        handle_language_command(chat_id, user_id)
                    elif text == '/help':
                        handle_help(chat_id, user_id)
                    elif text == '/thinking':
                        # ===== أمر /thinking — بدء وضع التفكير مباشرة =====
                        from buttons import thinking_active_buttons
                        from config import user_states
                        lang = get_user_language(user_id)
                        welcome_photo = "https://i.ibb.co/PZj2j89T/maxresdefault.jpg"
                        welcome_text = t('thinking_mode_welcome', lang)
                        user_states[user_id] = 'waiting_thinking'
                        try:
                            from telegram_api import send_photo
                            send_photo(chat_id, welcome_photo, caption=welcome_text,
                                       reply_markup=thinking_active_buttons(lang), parse_mode='HTML')
                        except Exception:
                            send_message(chat_id, welcome_text,
                                         reply_markup=thinking_active_buttons(lang), parse_mode='HTML')
                    elif text:
                        handle_normal_message(chat_id, user_id, text, reply_context=reply_context)

            except Exception as update_err:
                # خطأ في تحديث واحد — نسجّله ونكمل (البوت لا يتوقف أبداً)
                log_error(f"Error processing update {update.get('update_id', '?')}: {update_err}", exc=update_err)

    except Exception as e:
        log_error(f"Main loop connection error: {e}", exc=e)
        time.sleep(1)
