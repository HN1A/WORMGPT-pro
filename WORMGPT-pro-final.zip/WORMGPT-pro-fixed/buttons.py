from config import is_maintenance_mode
from i18n import t, DEFAULT_LANGUAGE, LANGUAGES

# ========================================================================
#                      دوال الأزرار (ملونة حسب API)
# ========================================================================

def main_buttons(lang=None, user_id=None):
    """الأزرار الرئيسية ملونة (مترجمة بحسب لغة المستخدم)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    try:
        from config import is_referral_enabled as _ref_on
        show_ref = _ref_on()
    except Exception:
        show_ref = False

    rows = [
        [
            {"text": t('btn_new_chat', lang), "callback_data": "new_chat", "style": "primary"},
            {"text": t('btn_search', lang), "callback_data": "search_general", "style": "primary"}
        ],
        # تم إزالة زر "نماذج البحث" المستقل من القائمة الرئيسية — أصبح داخل قائمة "تغيير النموذج"
        # (تم نقله إلى model_choice_buttons أدناه كما طلب المستخدم)
        [
            {"text": t('btn_vip', lang), "callback_data": "vip_info", "style": "success"},
            {"text": t('btn_support', lang), "callback_data": "contact_support", "style": "primary"}
        ],
        [
            {"text": t('btn_developer', lang), "callback_data": "developer", "style": "success"},
            {"text": t('btn_language', lang), "callback_data": "language_menu", "style": "primary"}
        ],
        [
            {"text": t('btn_switch_model', lang), "callback_data": "switch_model", "style": "danger"}
        ],
        [
            {"text": t('btn_account_info', lang), "callback_data": "account_info", "style": "danger"}
        ],
    ]
    # زر الإحالة الأحمر الشفاف — يظهر فقط إذا كان مفعّلاً من الأدمن
    if show_ref:
        rows.append([
            {"text": t('btn_referral_link', lang), "callback_data": "show_referral", "style": "danger"}
        ])
    rows.append([
        {"text": t('btn_channel', lang), "url": "https://t.me/IQCyber1"}
    ])
    return {"inline_keyboard": rows}


def referral_info_buttons(lang=None):
    """زر الرجوع بعد عرض رابط الإحالة"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [[
            {"text": t('btn_back', lang), "callback_data": "back_to_main", "style": "primary"}
        ]]
    }

def model_choice_buttons(lang=None, current_model='v1'):
    """أزرار اختيار النموذج (V1/V2 + نماذج البحث) مع تمييز النموذج النشط حالياً.
    تم إضافة زر "نماذج البحث" داخل هذه القائمة كما طلب المستخدم."""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    active = '✅'
    v1_label = t('model_v1_label', lang, active=active if current_model == 'v1' else '')
    v2_label = t('model_v2_label', lang, active=active if current_model == 'v2' else '')
    return {
        "inline_keyboard": [
            [{"text": v1_label.strip(), "callback_data": "select_model_v1", "style": "primary"}],
            [{"text": v2_label.strip(), "callback_data": "select_model_v2", "style": "success"}],
            # تم نقل زر "نماذج البحث" إلى هنا (داخل قائمة تغيير النماذج) كما طلب المستخدم
            [{"text": t('btn_research_models', lang), "callback_data": "research_models", "style": "primary"}],
            [{"text": t('btn_back', lang), "callback_data": "back_to_main", "style": "danger"}]
        ]
    }


def research_models_buttons(lang=None, current_research='research_v1'):
    """أزرار اختيار نموذج البحث (V1 للجميع / V2 للمشتركين VIP والأدمن فقط)
    مع تمييز النموذج النشط حالياً."""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    active = '✅'
    v1_label = t('model_research_v1_label', lang, active=active if current_research == 'research_v1' else '')
    v2_label = t('model_research_v2_label', lang, active=active if current_research == 'research_v2' else '')
    return {
        "inline_keyboard": [
            [{"text": v1_label.strip(), "callback_data": "select_research_v1", "style": "primary"}],
            [{"text": v2_label.strip(), "callback_data": "select_research_v2", "style": "success"}],
            [{"text": t('btn_back', lang), "callback_data": "back_to_main", "style": "danger"}]
        ]
    }


def cancel_search_button(lang=None):
    """زر إلغاء أحمر يظهر أثناء البحث (تحت رسالة في انتظار الرد).
    callback_data: cancel_search -> يُرجع إلى القائمة الرئيسية ويُمسح الحالة."""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_search_cancel', lang), "callback_data": "cancel_search", "style": "danger"}]
        ]
    }


def end_search_button(lang=None):
    """زر 'إنهاء البحث' أحمر يظهر أسفل رد النموذج بعد انتهاء الإرسال.
    callback_data: end_search -> يُنهي جلسة البحث الحالية ويمسح السياق."""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_end_search', lang), "callback_data": "end_search", "style": "danger"}]
        ]
    }


def cancel_photo_description_button(lang=None):
    """زر إلغاء أحمر يظهر عند طلب وصف/سؤال للصورة بعد الضغط على 'لا شكراً'.
    callback_data: cancel_photo_description -> يُرجع إلى القائمة الرئيسية ويُمسح الحالة والصورة المعلقة."""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_cancel_photo_description', lang), "callback_data": "cancel_photo_description", "style": "danger"}]
        ]
    }


def error_action_buttons(lang=None):
    """أزرار شاشة الخطأ: إعادة المحاولة، التواصل مع الدعم، فتح تذكرة، إلغاء.
    تُعرض عند حدوث أي خطأ للمستخدم."""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_retry', lang), "callback_data": "retry_ai", "style": "primary"}],
            [{"text": t('btn_contact_support_error', lang), "url": "https://t.me/BotsupportWormGPT_ai_1bot"}],
            [{"text": t('btn_open_ticket', lang), "url": "https://t.me/BotsupportWormGPT_ai_1bot?start=ticket"}],
            [{"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}]
        ]
    }


def search_type_picker_buttons(lang=None, vip_only=False):
    """أزرار اختيار نوع البحث (نص / صورة) - تظهر بعد الضغط على زر 'بحث' في القائمة الرئيسية.
    إذا كان المستخدم عادي (غير VIP): زر الصورة مخفي. السبب: البحث بالصور متاح فقط لـ V2.
    """
    if lang is None:
        lang = DEFAULT_LANGUAGE
    rows = []
    rows.append([{"text": "📝 بحث كلام" if lang == 'ar' else "📝 Text Search",
                  "callback_data": "search_pick_text", "style": "primary"}])
    if vip_only:
        rows.append([{"text": "🖼️ بحث صور" if lang == 'ar' else "🖼️ Image Search",
                      "callback_data": "search_pick_image", "style": "success"}])
    rows.append([{"text": t('btn_back', lang), "callback_data": "back_to_main", "style": "danger"}])
    return {"inline_keyboard": rows}

def wait_subscribe_buttons(lang=None):
    """زر 'اشتراك' URL مباشر + زر 'الدعم' يظهران تحت رسالة الانتظار أثناء المعالجة"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_subscribe_wait', lang), "url": "https://t.me/BotsupportWormGPT_ai_1bot"}],
            [{"text": t('btn_support_bot', lang), "url": "https://t.me/BotsupportWormGPT_ai_1bot"}]
        ]
    }

def vip_info_buttons(lang=None):
    """أزرار لوحة معلومات VIP: تواصل للاشتراك + اشتراك عبر نجوم تلجرام + رجوع (أحمر)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_contact_subscribe', lang), "callback_data": "contact_support", "style": "success"}],
            [{"text": t('btn_stars_subscribe', lang), "callback_data": "stars_subscribe_menu", "style": "success"}],
            [{"text": t('btn_back', lang), "callback_data": "back_to_main", "style": "danger"}]
        ]
    }

def stars_duration_buttons(lang=None):
    """أزرار اختيار مدة اشتراك VIP عبر نجوم تلجرام (مع الأسعار) + رجوع (أحمر) لقائمة VIP"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_stars_week', lang), "callback_data": "stars_duration_week", "style": "primary"}],
            [{"text": t('btn_stars_2weeks', lang), "callback_data": "stars_duration_2weeks", "style": "primary"}],
            [{"text": t('btn_stars_3weeks', lang), "callback_data": "stars_duration_3weeks", "style": "primary"}],
            [{"text": t('btn_back', lang), "callback_data": "vip_info", "style": "danger"}]
        ]
    }

def language_picker_buttons(lang=None):
    """أزرار اختيار اللغة (5 لغات) + رجوع (أحمر)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [
                {"text": f"{LANGUAGES['ar']['flag']} العربية", "callback_data": "set_lang_ar", "style": "primary"},
                {"text": f"{LANGUAGES['en']['flag']} English", "callback_data": "set_lang_en", "style": "primary"}
            ],
            [
                {"text": f"{LANGUAGES['ru']['flag']} Русский", "callback_data": "set_lang_ru", "style": "primary"},
                {"text": f"{LANGUAGES['zh']['flag']} 中文", "callback_data": "set_lang_zh", "style": "primary"}
            ],
            [
                {"text": f"{LANGUAGES['fa']['flag']} فارسی", "callback_data": "set_lang_fa", "style": "primary"}
            ],
            [{"text": t('btn_back', lang), "callback_data": "back_to_main", "style": "danger"}]
        ]
    }

def admin_buttons(lang=None):
    """أزرار لوحة التحكم ملونة (مترجمة بحسب لغة الأدمن)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    try:
        from config import is_referral_enabled as _ref_enabled
    except Exception:
        _ref_enabled = lambda: False
    if is_maintenance_mode():
        maintenance_row = [{"text": t('btn_maintenance_disable', lang), "callback_data": "toggle_maintenance", "style": "success"}]
    else:
        maintenance_row = [{"text": t('btn_maintenance_enable', lang), "callback_data": "toggle_maintenance", "style": "danger"}]
    ref_label = t('btn_referral_disable', lang) if _ref_enabled() else t('btn_referral_enable', lang)
    ref_style = "danger" if _ref_enabled() else "success"
    return {
        "inline_keyboard": [
            [
                {"text": t('btn_add_channel', lang), "callback_data": "add_channel", "style": "success"},
                {"text": t('btn_remove_channel', lang), "callback_data": "remove_channel", "style": "danger"}
            ],
            [
                {"text": t('btn_show_channels', lang), "callback_data": "show_channels", "style": "primary"},
                {"text": t('btn_delete_all_channels', lang), "callback_data": "delete_all_channels", "style": "danger"}
            ],
            [
                {"text": t('btn_broadcast', lang), "callback_data": "broadcast_menu", "style": "primary"},
                {"text": t('btn_renew_messages', lang), "callback_data": "renew_messages_menu", "style": "success"}
            ],
            [
                {"text": t('btn_vip_subscription_admin', lang), "callback_data": "vip_subscription_menu", "style": "success"},
                {"text": t('btn_vip_list', lang), "callback_data": "list_vip_users", "style": "primary"}
            ],
            [
                {"text": t('btn_cancel_vip', lang), "callback_data": "cancel_vip_menu", "style": "danger"}
            ],
            [
                {"text": t('btn_ban_user', lang), "callback_data": "ban_user_menu", "style": "danger"},
                {"text": t('btn_unban_user', lang), "callback_data": "unban_user_menu", "style": "success"}
            ],
            [
                {"text": t('btn_change_stars_prices', lang), "callback_data": "change_stars_prices", "style": "primary"}
            ],
            maintenance_row,
            [
                {"text": ref_label, "callback_data": "admin_toggle_referral", "style": ref_style}
            ],
            [
                {"text": t('btn_stats', lang), "callback_data": "stats", "style": "primary"},
                {"text": t('btn_back', lang), "callback_data": "back_to_main", "style": "primary"}
            ]
        ]
    }

def cancel_button(lang=None):
    """زر إلغاء أحمر (شفاف) للرجوع إلى لوحة التحكم"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}]
        ]
    }

def broadcast_target_buttons(lang=None):
    """أزرار اختيار جهة الإذاعة (شفافة) مع زر إلغاء أحمر"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_broadcast_normal', lang), "callback_data": "broadcast_normal", "style": "primary"}],
            [{"text": t('btn_broadcast_vip', lang), "callback_data": "broadcast_vip", "style": "success"}],
            [{"text": t('btn_broadcast_all', lang), "callback_data": "broadcast_all", "style": "primary"}],
            [{"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}]
        ]
    }

def broadcast_pin_buttons(lang=None):
    """أزرار تأكيد تثبيت رسالة الإذاعة في محادثات المستخدمين (شفافة) مع زر إلغاء أحمر"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_broadcast_pin_yes', lang), "callback_data": "broadcast_pin_yes", "style": "success"}],
            [{"text": t('btn_broadcast_pin_no', lang), "callback_data": "broadcast_pin_no", "style": "primary"}],
            [{"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}]
        ]
    }

def vip_duration_buttons(lang=None):
    """أزرار اختيار مدة اشتراك VIP (شفافة) مع زر إلغاء أحمر"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_vip_duration_week_admin', lang), "callback_data": "vip_duration_week", "style": "success"}],
            [{"text": t('btn_vip_duration_2weeks_admin', lang), "callback_data": "vip_duration_2weeks", "style": "success"}],
            [{"text": t('btn_vip_duration_3weeks_admin', lang), "callback_data": "vip_duration_3weeks", "style": "success"}],
            [{"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}]
        ]
    }

def cancel_vip_confirm_buttons(lang=None):
    """أزرار تأكيد إلغاء اشتراك VIP (أحمر للتأكيد + أحمر للإلغاء)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [
                {"text": t('btn_confirm_cancel_vip', lang), "callback_data": "confirm_cancel_vip", "style": "danger"},
                {"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}
            ]
        ]
    }

def first_language_picker_buttons():
    """أزرار اختيار اللغة عند أول دخول — تُعرض جميع اللغات المتاحة تلقائياً من LANGUAGES"""
    from i18n import LANGUAGES
    rows = []
    current_row = []
    # ترتيب اللغات: عربي، إنجليزي، روسي، صيني، فارسي
    lang_order = ['ar', 'en', 'ru', 'zh', 'fa']
    for lang_code in lang_order:
        if lang_code in LANGUAGES:
            lang_info = LANGUAGES[lang_code]
            btn = {
                "text": f"{lang_info['flag']} {lang_info['name']}",
                "callback_data": f"set_lang_{lang_code}"
            }
            current_row.append(btn)
            # زرّان في كل صف لعرض جميل ومرتب
            if len(current_row) == 2:
                rows.append(current_row)
                current_row = []
    # إضافة أي أزرار متبقية (لغة فردية في آخر صف)
    if current_row:
        rows.append(current_row)
    return {"inline_keyboard": rows}

def copy_button(code_text='', lang=None):
    """زر نسخ الكود — يستخدم copy_text الأصلي في تيليجرام (Bot API 7.3+)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    if code_text:
        # Telegram copy_text: حد 256 حرف
        safe_text = str(code_text).strip()[:256]
        return {
            "inline_keyboard": [[
                {"text": t('btn_copy_code', lang), "copy_text": {"text": safe_text}}
            ]]
        }
    # لا يوجد نص: زر callback احتياطي
    return {
        "inline_keyboard": [[
            {"text": t('btn_copy_code', lang), "callback_data": "copy_code"}
        ]]
    }


def retry_button(lang=None):
    """زر إعادة المحاولة عند فشل الاتصال بالذكاء الاصطناعي"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [[
            {"text": t('btn_retry', lang), "callback_data": "retry_ai"}
        ]]
    }


def photo_analyze_buttons(lang=None):
    """أزرار تأكيد تحليل الصورة (V2)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [[
            {"text": t('btn_analyze_yes', lang), "callback_data": "analyze_photo_yes", "style": "success"},
            {"text": t('btn_analyze_no', lang),  "callback_data": "analyze_photo_no",  "style": "danger"}
        ]]
    }


def change_stars_confirm_buttons(lang=None):
    """أزرار تأكيد تغيير سعر النجوم (أخضر للتأكيد + أحمر للإلغاء)"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [
                {"text": t('btn_confirm_green', lang), "callback_data": "confirm_stars_price_change", "style": "success"},
                {"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}
            ]
        ]
    }

def not_subscribe_buttons(invite_link, lang=None):
    """زر الاشتراك في القناة"""
    if lang is None:
        lang = DEFAULT_LANGUAGE
    return {
        "inline_keyboard": [
            [{"text": t('btn_join_channel', lang), "url": invite_link, "style": "primary"}]
        ]
    }

