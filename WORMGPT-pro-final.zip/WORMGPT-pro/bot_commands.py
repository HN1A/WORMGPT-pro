"""
==========================
   تسجيل أوامر البوت متعددة اللغات
   Bot Commands Localization
==========================
"""
from telegram_api import bot_api

# ===== أوامر البوت المستخرجة من المشروع =====
# تم استخراجها تلقائياً من جميع ملفات المشروع

COMMANDS_DEFAULT = [
    {"command": "start", "description": "🚀 Start the bot / بدء البوت"},
    {"command": "pay", "description": "💎 VIP subscription / اشتراك VIP"},
    {"command": "search", "description": "🔍 Search the web / البحث في الويب"},
]

COMMANDS_ARABIC = [
    {"command": "start", "description": "🚀 بدء استخدام البوت"},
    {"command": "pay", "description": "💎 الاشتراك في VIP"},
    {"command": "search", "description": "🔍 البحث في الإنترنت"},
]

COMMANDS_ENGLISH = [
    {"command": "start", "description": "🚀 Start using the bot"},
    {"command": "pay", "description": "💎 Subscribe to VIP"},
    {"command": "search", "description": "🔍 Search the web"},
]

# أوامر الأدمن (تُسجل بشكل منفصل)
ADMIN_COMMANDS = [
    {"command": "stats", "description": "📊 Bot statistics"},
    {"command": "ban", "description": "🚫 Ban a user"},
    {"command": "unban", "description": "✅ Unban a user"},
    {"command": "broadcast", "description": "📢 Send broadcast message"},
    {"command": "id", "description": "🔍 Get user info by ID"},
    {"command": "update", "description": "🔄 Check for updates"},
]


def register_bot_commands(admin_ids=None):
    """
    تسجيل أوامر البوت متعددة اللغات باستخدام setMyCommands.
    يتم تسجيل:
    - أوامر افتراضية (بدون لغة محددة)
    - أوامر بالعربية (language_code="ar")
    - أوامر بالإنجليزية (language_code="en")
    """
    success = True

    # 1) أوامر افتراضية
    try:
        url = f"{bot_api}/setMyCommands"
        payload = {
            "commands": COMMANDS_DEFAULT,
            "scope": {"type": "default"}
        }
        import requests
        resp = requests.post(url, json=payload, timeout=15)
        if resp.status_code != 200 or not resp.json().get("ok"):
            print(f"[BotCommands] Error setting default commands: {resp.text}")
            success = False
    except Exception as e:
        print(f"[BotCommands] Exception setting default commands: {e}")
        success = False

    # 2) أوامر عربية
    try:
        url = f"{bot_api}/setMyCommands"
        payload = {
            "commands": COMMANDS_ARABIC,
            "language_code": "ar",
            "scope": {"type": "default"}
        }
        resp = requests.post(url, json=payload, timeout=15)
        if resp.status_code != 200 or not resp.json().get("ok"):
            print(f"[BotCommands] Error setting Arabic commands: {resp.text}")
    except Exception as e:
        print(f"[BotCommands] Exception setting Arabic commands: {e}")

    # 3) أوامر إنجليزية
    try:
        url = f"{bot_api}/setMyCommands"
        payload = {
            "commands": COMMANDS_ENGLISH,
            "language_code": "en",
            "scope": {"type": "default"}
        }
        resp = requests.post(url, json=payload, timeout=15)
        if resp.status_code != 200 or not resp.json().get("ok"):
            print(f"[BotCommands] Error setting English commands: {resp.text}")
    except Exception as e:
        print(f"[BotCommands] Exception setting English commands: {e}")

    # 4) أوامر الأدمن (scope: chat) — لكل أدمن على حدة
    if admin_ids:
        for admin_id in admin_ids:
            try:
                url = f"{bot_api}/setMyCommands"
                payload = {
                    "commands": ADMIN_COMMANDS,
                    "scope": {"type": "chat", "chat_id": admin_id}
                }
                resp = requests.post(url, json=payload, timeout=15)
                if resp.status_code != 200 or not resp.json().get("ok"):
                    print(f"[BotCommands] Error setting admin commands for {admin_id}: {resp.text}")
            except Exception as e:
                print(f"[BotCommands] Exception setting admin commands for {admin_id}: {e}")

    if success:
        print("[BotCommands] ✅ Bot commands registered successfully!")
    return success
