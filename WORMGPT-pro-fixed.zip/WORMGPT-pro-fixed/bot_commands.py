"""
==========================
   تسجيل أوامر البوت متعددة اللغات
   Bot Commands Localization
==========================
"""
from config import URL

# ===================================================================
# ===== أوامر البوت المستخرجة من المشروع بالكامل =====
# تم استخراجها يدوياً من chat_botapi.py و user_handlers.py
# ===================================================================

# ---- الأوامر العامة (لجميع المستخدمين) ----
# /start  - بدء البوت + معالجة الإحالة (chat_botapi.py:228)
# /clear  - مسح سياق المحادثة (chat_botapi.py:232)
# /info   - عرض معلومات البوت (chat_botapi.py:234)
# /language - تغيير لغة الواجهة (chat_botapi.py:238)

COMMANDS_DEFAULT = [
    {"command": "start", "description": "🚀 Start the bot"},
    {"command": "clear", "description": "🗑️ Clear conversation context"},
    {"command": "info", "description": "ℹ️ Bot information"},
    {"command": "language", "description": "🌐 Change language"},
]

COMMANDS_ARABIC = [
    {"command": "start", "description": "🚀 بدء استخدام البوت"},
    {"command": "clear", "description": "🗑️ مسح سياق المحادثة"},
    {"command": "info", "description": "ℹ️ معلومات البوت"},
    {"command": "language", "description": "🌐 تغيير اللغة"},
]

COMMANDS_ENGLISH = [
    {"command": "start", "description": "🚀 Start using the bot"},
    {"command": "clear", "description": "🗑️ Clear conversation context"},
    {"command": "info", "description": "ℹ️ Bot information"},
    {"command": "language", "description": "🌐 Change language"},
]

# ---- أوامر الأدمن (تُسجل بشكل منفصل عبر scope: chat) ----
# /admin - فتح لوحة تحكم الأدمن (chat_botapi.py:236)
ADMIN_COMMANDS = [
    {"command": "admin", "description": "👑 Open admin panel"},
]


def register_bot_commands(admin_ids=None):
    """
    تسجيل أوامر البوت متعددة اللغات باستخدام setMyCommands.
    يتم تسجيل:
    - أوامر افتراضية (بدون لغة محددة)
    - أوامر بالعربية (language_code="ar")
    - أوامر بالإنجليزية (language_code="en")
    """
    success = True

    import requests

    # 1) أوامر افتراضية
    try:
        payload = {
            "commands": COMMANDS_DEFAULT,
            "scope": {"type": "default"}
        }
        resp = requests.post(f"{URL}/setMyCommands", json=payload, timeout=15)
        if resp.status_code != 200 or not resp.json().get("ok"):
            print(f"[BotCommands] Error setting default commands: {resp.text}")
            success = False
    except Exception as e:
        print(f"[BotCommands] Exception setting default commands: {e}")
        success = False

    # 2) أوامر عربية
    try:
        payload = {
            "commands": COMMANDS_ARABIC,
            "language_code": "ar",
            "scope": {"type": "default"}
        }
        resp = requests.post(f"{URL}/setMyCommands", json=payload, timeout=15)
        if resp.status_code != 200 or not resp.json().get("ok"):
            print(f"[BotCommands] Error setting Arabic commands: {resp.text}")
    except Exception as e:
        print(f"[BotCommands] Exception setting Arabic commands: {e}")

    # 3) أوامر إنجليزية
    try:
        payload = {
            "commands": COMMANDS_ENGLISH,
            "language_code": "en",
            "scope": {"type": "default"}
        }
        resp = requests.post(f"{URL}/setMyCommands", json=payload, timeout=15)
        if resp.status_code != 200 or not resp.json().get("ok"):
            print(f"[BotCommands] Error setting English commands: {resp.text}")
    except Exception as e:
        print(f"[BotCommands] Exception setting English commands: {e}")

    # 4) أوامر الأدمن (scope: chat) — لكل أدمن على حدة
    if admin_ids:
        for admin_id in admin_ids:
            try:
                payload = {
                    "commands": ADMIN_COMMANDS,
                    "scope": {"type": "chat", "chat_id": admin_id}
                }
                resp = requests.post(f"{URL}/setMyCommands", json=payload, timeout=15)
                if resp.status_code != 200 or not resp.json().get("ok"):
                    print(f"[BotCommands] Error setting admin commands for {admin_id}: {resp.text}")
            except Exception as e:
                print(f"[BotCommands] Exception setting admin commands for {admin_id}: {e}")

    if success:
        print("[BotCommands] ✅ Bot commands registered successfully!")
    return success
