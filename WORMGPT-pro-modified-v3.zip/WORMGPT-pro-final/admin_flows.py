import time
from config import (ADMIN, VIP_DURATIONS, DURATION_LABELS, admin_context, data, user_conversations,
                     user_states, is_referral_enabled, set_referral_enabled, save_data, save_user_page)
from telegram_api import send_message, edit_message_text, copy_message, pin_chat_message
from buttons import admin_buttons, cancel_button, broadcast_target_buttons, vip_duration_buttons, cancel_vip_confirm_buttons
from vip_system import add_vip, get_all_vip_users, get_messages_left, get_vip_expiry_text, is_vip, renew_messages, find_user_by_identifier, get_user_display
from i18n import get_user_language, t

def show_stats(chat_id, user_id, message_id):
    if user_id not in ADMIN:
        return

    lang = get_user_language(user_id)
    from config import MAX_HISTORY
    stats_text = t('stats_text', lang, users=len(data), convs=len(user_conversations), memory=MAX_HISTORY)
    edit_message_text(chat_id, message_id, stats_text, reply_markup=admin_buttons(lang), parse_mode='HTML')

def show_vip_list(chat_id, user_id, message_id):
    """عرض قائمة بكل مستخدمي VIP النشطين حالياً مع معلومات كل واحد منهم (الايدي، اليوزر،
    الاسم، تاريخ انتهاء الاشتراك). تُقسَّم الرسالة على عدة رسائل عند تجاوز الحد المسموح به
    في تيليجرام (4096 حرف) لتفادي فشل الإرسال عند وجود عدد كبير من المشتركين."""
    if user_id not in ADMIN:
        return

    lang = get_user_language(user_id)
    vip_users = get_all_vip_users()

    if not vip_users:
        edit_message_text(chat_id, message_id, t('vip_list_empty', lang),
                          reply_markup=admin_buttons(lang), parse_mode='HTML')
        return

    header = t('vip_list_header', lang, count=len(vip_users)) + "\n\n"
    entries = []
    for i, vip in enumerate(vip_users, 1):
        username_display = f"@{vip['username']}" if vip['username'] else "—"
        entries.append(
            f"<b>{i}.</b> {vip['name']}\n"
            f"   🆔 <code>{vip['uid']}</code>\n"
            f"   🔗 {username_display}\n"
            f"   ⏳ ينتهي: {vip['expiry_text']}\n"
        )

    # تقسيم القائمة على رسائل متعددة عند تجاوز الحد الآمن لطول رسالة تيليجرام
    chunks = []
    current_chunk = header
    for entry in entries:
        if len(current_chunk) + len(entry) > 3500:
            chunks.append(current_chunk)
            current_chunk = ""
        current_chunk += entry
    if current_chunk:
        chunks.append(current_chunk)

    # تعديل الرسالة الأصلية بالجزء الأول، ثم إرسال البقية كرسائل جديدة منفصلة
    edit_message_text(chat_id, message_id, chunks[0],
                      reply_markup=admin_buttons(lang) if len(chunks) == 1 else None, parse_mode='HTML')
    for i, chunk in enumerate(chunks[1:], 1):
        is_last = (i == len(chunks) - 1)
        send_message(chat_id, chunk, reply_markup=admin_buttons(lang) if is_last else None, parse_mode='HTML')

# ========================================================================
#                      الإذاعة + تجديد الرسائل + اشتراك VIP (للأدمن)
# ========================================================================

# ----- الإذاعة -----

def start_broadcast_flow(chat_id, user_id, message_id):
    """بدء تدفق الإذاعة: طلب محتوى الإذاعة من الأدمن (نص/صورة/فيديو/كليهما)"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    admin_context[user_id] = {}
    user_states[user_id] = 'waiting_broadcast_message'
    edit_message_text(
        chat_id, message_id,
        t('broadcast_prompt', lang),
        reply_markup=cancel_button(back_to='admin'),
        parse_mode='HTML'
    )

def handle_broadcast_message_input(chat_id, user_id, message):
    """استقبال محتوى الإذاعة من الأدمن (نص/صورة/فيديو/كليهما) وعرض أزرار اختيار الفئة المستهدفة"""
    lang = get_user_language(user_id)
    message_id = message.get('message_id')

    has_content = any([
        message.get('text'), message.get('caption'), message.get('photo'),
        message.get('video'), message.get('document'), message.get('animation')
    ])

    if not has_content or not message_id:
        send_message(
            chat_id,
            t('broadcast_invalid', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return

    admin_context[user_id] = {'broadcast_chat_id': chat_id, 'broadcast_message_id': message_id}
    user_states.pop(user_id, None)

    send_message(
        chat_id,
        t('broadcast_received', lang),
        parse_mode='HTML',
        reply_markup=broadcast_target_buttons(lang)
    )

def do_broadcast(chat_id, admin_id, message_id, source_chat_id, source_message_id, target, pin=False):
    """تنفيذ الإذاعة (نص/صورة/فيديو/كليهما) إلى الفئة المحددة من المستخدمين، مع تثبيت اختياري
    للرسالة في كل محادثة تصلها (تعمل في Thread منفصل)"""
    lang = get_user_language(admin_id)
    if target == 'broadcast_vip':
        target_ids = [uid for uid in list(data.keys()) if is_vip(uid)]
        target_label = t('broadcast_target_vip_label', lang)
    elif target == 'broadcast_normal':
        target_ids = [uid for uid in list(data.keys()) if not is_vip(uid)]
        target_label = t('broadcast_target_normal_label', lang)
    else:
        target_ids = list(data.keys())
        target_label = t('broadcast_target_all_label', lang)

    pin_label = t('broadcast_pin_label', lang) if pin else t('broadcast_pin_label_off', lang)
    edit_message_text(
        chat_id, message_id,
        t('broadcast_sending', lang, target_label=target_label, count=len(target_ids), pin_label=pin_label),
        parse_mode='HTML'
    )

    success = 0
    failed = 0
    pinned = 0
    for uid in target_ids:
        try:
            result = copy_message(int(uid), source_chat_id, source_message_id)
            if result is not None and result.status_code == 200:
                success += 1
                if pin:
                    try:
                        new_message_id = result.json().get('result', {}).get('message_id')
                        if new_message_id:
                            pin_result = pin_chat_message(int(uid), new_message_id)
                            if pin_result is not None and pin_result.status_code == 200:
                                pinned += 1
                    except Exception:
                        pass
            else:
                failed += 1
        except:
            failed += 1
        time.sleep(0.05)

    summary = t('broadcast_summary', lang, target_label=target_label, total=len(target_ids), success=success, failed=failed)
    if pin:
        summary += f"\n📌 {t('broadcast_pin_label', lang).capitalize()}: {pinned}"
    send_message(chat_id, summary, parse_mode='HTML', reply_markup=admin_buttons(lang))
    admin_context.pop(admin_id, None)

# ----- تجديد رصيد الرسائل -----

def start_renew_flow(chat_id, user_id, message_id):
    """بدء تدفق تجديد الرسائل: طلب ايدي أو يوزر المستخدم"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    admin_context[user_id] = {}
    user_states[user_id] = 'waiting_renew_user'
    edit_message_text(
        chat_id, message_id,
        t('renew_messages_prompt', lang),
        reply_markup=cancel_button(back_to='admin'),
        parse_mode='HTML'
    )

def handle_renew_user_input(chat_id, user_id, text):
    """استقبال ايدي أو يوزر المستخدم المراد تجديد رسائله"""
    lang = get_user_language(user_id)
    target_uid = find_user_by_identifier(text)

    if target_uid is None:
        send_message(
            chat_id,
            t('renew_user_not_found', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return

    admin_context[user_id] = {'target_user': target_uid}
    user_states[user_id] = 'waiting_renew_amount'

    name, username_display = get_user_display(target_uid)
    current_balance = get_messages_left(target_uid)

    send_message(
        chat_id,
        t('renew_user_found', lang, name=name, username=username_display, user_id=target_uid, balance=current_balance),
        parse_mode='HTML',
        reply_markup=cancel_button()
    )

def handle_renew_amount_input(chat_id, user_id, text):
    """استقبال عدد الرسائل المراد تجديدها وتنفيذ التجديد"""
    lang = get_user_language(user_id)
    amount_text = text.strip()
    if not amount_text.isdigit() or int(amount_text) <= 0:
        send_message(
            chat_id,
            t('renew_amount_invalid', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return

    amount = int(amount_text)
    target_uid = admin_context.get(user_id, {}).get('target_user')

    if not target_uid:
        send_message(chat_id, t('admin_action_generic_error', lang), parse_mode='HTML', reply_markup=admin_buttons(lang))
        user_states.pop(user_id, None)
        admin_context.pop(user_id, None)
        return

    old_count, new_count = renew_messages(target_uid, amount)
    name, username_display = get_user_display(target_uid)

    send_message(
        chat_id,
        t('renew_success_admin', lang, name=name, username=username_display, user_id=target_uid,
          old=old_count, added=amount, new=new_count),
        parse_mode='HTML',
        reply_markup=admin_buttons(lang)
    )

    try:
        target_lang = get_user_language(int(target_uid))
        send_message(
            int(target_uid),
            t('renew_user_notification', target_lang, new=new_count),
            parse_mode='HTML'
        )
    except:
        pass

    user_states.pop(user_id, None)
    admin_context.pop(user_id, None)

# ----- اشتراك VIP -----

def start_vip_flow(chat_id, user_id, message_id):
    """بدء تدفق اشتراك VIP: طلب ايدي أو يوزر المستخدم"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    admin_context[user_id] = {}
    user_states[user_id] = 'waiting_vip_user'
    edit_message_text(
        chat_id, message_id,
        t('admin_vip_prompt', lang),
        reply_markup=cancel_button(back_to='admin'),
        parse_mode='HTML'
    )

def handle_vip_user_input(chat_id, user_id, text):
    """استقبال ايدي أو يوزر المستخدم المراد تفعيل VIP له"""
    lang = get_user_language(user_id)
    target_uid = find_user_by_identifier(text)

    if target_uid is None:
        send_message(
            chat_id,
            t('renew_user_not_found', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return

    admin_context[user_id] = {'target_user': target_uid}
    user_states.pop(user_id, None)

    name, username_display = get_user_display(target_uid)
    vip_expiry = get_vip_expiry_text(target_uid)
    if vip_expiry:
        vip_line = t('admin_vip_existing_line', lang, expiry=vip_expiry)
    else:
        vip_line = t('admin_vip_no_existing_line', lang)

    send_message(
        chat_id,
        t('admin_vip_user_info', lang, name=name, username=username_display, user_id=target_uid, vip_line=vip_line),
        parse_mode='HTML',
        reply_markup=vip_duration_buttons(lang)
    )

def apply_vip_duration(chat_id, admin_id, message_id, duration_key):
    """تطبيق مدة اشتراك VIP المختارة على المستخدم المحدد"""
    lang = get_user_language(admin_id)
    target_uid = admin_context.get(admin_id, {}).get('target_user')

    if not target_uid:
        edit_message_text(chat_id, message_id, t('admin_action_generic_error', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')
        return

    seconds = VIP_DURATIONS.get(duration_key, 0)
    duration_label = DURATION_LABELS.get(duration_key, {}).get(lang, duration_key)

    new_expiry = add_vip(target_uid, seconds)
    expiry_text = time.strftime('%Y-%m-%d %H:%M', time.localtime(new_expiry))

    name, username_display = get_user_display(target_uid)

    edit_message_text(
        chat_id, message_id,
        t('admin_vip_success', lang, name=name, username=username_display, user_id=target_uid,
          duration=duration_label, expiry=expiry_text),
        reply_markup=admin_buttons(lang),
        parse_mode='HTML'
    )

    try:
        target_lang = get_user_language(int(target_uid))
        send_message(
            int(target_uid),
            t('admin_vip_user_notification', target_lang, duration=duration_label, expiry=expiry_text),
            parse_mode='HTML'
        )
    except:
        pass

    admin_context.pop(admin_id, None)


# ========================================================================
#                      إلغاء اشتراك VIP (أدمن)
# ========================================================================

def start_cancel_vip_flow(chat_id, user_id, message_id):
    """بدء تدفق إلغاء اشتراك VIP: طلب ايدي أو يوزر المستخدم"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    admin_context[user_id] = {}
    user_states[user_id] = 'waiting_cancel_vip_user'
    edit_message_text(
        chat_id, message_id,
        t('cancel_vip_prompt', lang),
        reply_markup=cancel_button(back_to='admin'),
        parse_mode='HTML'
    )

def handle_cancel_vip_user_input(chat_id, user_id, text):
    """استقبال ايدي أو يوزر المستخدم المراد إلغاء VIP له"""
    lang = get_user_language(user_id)
    from vip_system import find_user_by_identifier, get_user_display, is_vip, get_vip_expiry_text
    from buttons import cancel_vip_confirm_buttons, admin_buttons

    target_uid = find_user_by_identifier(text)

    if target_uid is None:
        send_message(
            chat_id,
            t('cancel_vip_user_not_found', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return

    # تحقق إذا كان المستخدم مشتركاً في VIP
    if not is_vip(target_uid):
        send_message(
            chat_id,
            t('cancel_vip_not_vip', lang),
            parse_mode='HTML',
            reply_markup=admin_buttons(lang)
        )
        user_states.pop(user_id, None)
        admin_context.pop(user_id, None)
        return

    admin_context[user_id] = {'target_user': target_uid}
    user_states.pop(user_id, None)

    name, username_display = get_user_display(target_uid)
    vip_expiry = get_vip_expiry_text(target_uid)
    vip_line = t('vip_status_active', lang, expiry=vip_expiry) if vip_expiry else ''

    send_message(
        chat_id,
        t('cancel_vip_user_found', lang, name=name, username=username_display, user_id=target_uid, vip_line=vip_line),
        parse_mode='HTML',
        reply_markup=cancel_vip_confirm_buttons(lang)
    )

def confirm_cancel_vip(chat_id, admin_id, message_id):
    """تأكيد إلغاء اشتراك VIP المستخدم"""
    lang = get_user_language(admin_id)
    target_uid = admin_context.get(admin_id, {}).get('target_user')
    from buttons import admin_buttons

    if not target_uid:
        edit_message_text(chat_id, message_id, t('admin_action_generic_error', lang), reply_markup=admin_buttons(lang), parse_mode='HTML')
        return

    # إلغاء الاشتراك: تعيين vip_until إلى 0
    from vip_system import get_user_display
    from config import data, save_data
    name, username_display = get_user_display(target_uid)

    if str(target_uid) in data:
        data[str(target_uid)]['vip_until'] = 0
        save_data()

    edit_message_text(
        chat_id, message_id,
        t('cancel_vip_success_admin', lang, name=name, username=username_display, user_id=target_uid),
        reply_markup=admin_buttons(lang),
        parse_mode='HTML'
    )

    # إشعار المستخدم
    try:
        target_lang = get_user_language(int(target_uid))
        send_message(int(target_uid), t('cancel_vip_user_notification', target_lang), parse_mode='HTML')
    except Exception:
        pass

    admin_context.pop(admin_id, None)


def toggle_referral(chat_id, user_id, message_id):
    """تفعيل/إلغاء زر الإحالة لجميع المستخدمين"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    new_state = not is_referral_enabled()
    set_referral_enabled(new_state)
    status_key = 'referral_status_enabled' if new_state else 'referral_status_disabled'
    status = t(status_key, lang)
    from buttons import admin_buttons
    edit_message_text(chat_id, message_id,
        t('referral_toggle_text', lang, status=status),
        reply_markup=admin_buttons(lang), parse_mode='HTML')


# ========================================================================
#                      حظر مستخدم (أدمن)
# ========================================================================

def start_ban_flow(chat_id, user_id, message_id):
    """بدء تدفق حظر مستخدم"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    admin_context[user_id] = {}
    user_states[user_id] = 'waiting_ban_user'
    edit_message_text(
        chat_id, message_id,
        t('ban_user_prompt', lang),
        reply_markup=cancel_button(back_to='admin'),
        parse_mode='HTML'
    )


def handle_ban_user_input(chat_id, user_id, text):
    """استقبال ID أو Username المستخدم المراد حظره"""
    lang = get_user_language(user_id)
    from channels_db import ban_user
    from vip_system import find_user_by_identifier
    target_uid = find_user_by_identifier(text)
    if target_uid is None:
        send_message(
            chat_id,
            t('ban_user_not_found', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return
    admin_context[user_id] = {'target_user': target_uid}
    user_states[user_id] = 'waiting_ban_reason'
    name, username_display = get_user_display(target_uid)
    send_message(
        chat_id,
        t('ban_user_found', lang, name=name, username=username_display, user_id=target_uid),
        parse_mode='HTML',
        reply_markup=cancel_button()
    )


def handle_ban_reason_input(chat_id, user_id, text):
    """استقبال سبب الحظر وتنفيذ الحظر"""
    lang = get_user_language(user_id)
    target_uid = admin_context.get(user_id, {}).get('target_user')
    if not target_uid:
        send_message(chat_id, t('admin_action_generic_error', lang), parse_mode='HTML', reply_markup=admin_buttons(lang))
        user_states.pop(user_id, None)
        admin_context.pop(user_id, None)
        return
    from channels_db import ban_user
    success = ban_user(target_uid, reason=text.strip())
    name, username_display = get_user_display(target_uid)
    if success:
        send_message(
            chat_id,
            t('ban_success', lang, name=name, username=username_display, user_id=target_uid),
            parse_mode='HTML',
            reply_markup=admin_buttons(lang)
        )
    else:
        send_message(
            chat_id,
            t('ban_failed', lang),
            parse_mode='HTML',
            reply_markup=admin_buttons(lang)
        )
    user_states.pop(user_id, None)
    admin_context.pop(user_id, None)


# ========================================================================
#                      إلغاء حظر مستخدم (أدمن)
# ========================================================================

def start_unban_flow(chat_id, user_id, message_id):
    """بدء تدفق إلغاء حظر مستخدم"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    admin_context[user_id] = {}
    user_states[user_id] = 'waiting_unban_user'
    edit_message_text(
        chat_id, message_id,
        t('unban_user_prompt', lang),
        reply_markup=cancel_button(back_to='admin'),
        parse_mode='HTML'
    )


def handle_unban_user_input(chat_id, user_id, text):
    """استقبال ID أو Username المستخدم المراد إلغاء حظره"""
    lang = get_user_language(user_id)
    from channels_db import unban_user
    from vip_system import find_user_by_identifier
    target_uid = find_user_by_identifier(text)
    if target_uid is None:
        send_message(
            chat_id,
            t('unban_user_not_found', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return
    success = unban_user(target_uid)
    name, username_display = get_user_display(target_uid)
    if success:
        send_message(
            chat_id,
            t('unban_success', lang, name=name, username=username_display, user_id=target_uid),
            parse_mode='HTML',
            reply_markup=admin_buttons(lang)
        )
    else:
        send_message(
            chat_id,
            t('unban_failed', lang),
            parse_mode='HTML',
            reply_markup=admin_buttons(lang)
        )
    user_states.pop(user_id, None)
    admin_context.pop(user_id, None)


# ========================================================================
#                      تغيير أسعار النجوم (أدمن)
# ========================================================================

# تخزين مؤقت لتغيير الأسعار (pending change)
stars_price_change_pending = {}


def start_change_stars_flow(chat_id, user_id, message_id):
    """عرض قائمة باقات النجوم مع الأسعار الحالية للأدمن (ديناميكية من STARS_PRICES).
    
    المطلوب: عند تغيير سعر أي باقة، يجب أن تُعرض الأسعار الجديدة هنا تلقائياً
    بدون أي تعديل يدوي — تُقرأ مباشرة من STARS_PRICES.
    """
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    from config import STARS_PRICES, DURATION_LABELS
    text = t('change_stars_header', lang) + "\n\n"
    for key in ['week', '2weeks', '3weeks']:
        label = DURATION_LABELS.get(key, {}).get(lang, key)
        price = STARS_PRICES.get(key, 0)
        text += f"• <b>{label}</b> — <code>{price}</code> ⭐\n"
    text += "\n" + t('change_stars_select', lang)
    # أزرار اختيار الباقة — تُمرّر الأسعار الديناميكية لتظهر في نصوص الأزرار
    from buttons import cancel_button
    edit_message_text(
        chat_id, message_id, text,
        reply_markup={
            "inline_keyboard": [
                [{"text": t('btn_stars_week', lang, price=STARS_PRICES.get('week', 10)), "callback_data": "stars_edit_week", "style": "primary"}],
                [{"text": t('btn_stars_2weeks', lang, price=STARS_PRICES.get('2weeks', 20)), "callback_data": "stars_edit_2weeks", "style": "primary"}],
                [{"text": t('btn_stars_3weeks', lang, price=STARS_PRICES.get('3weeks', 30)), "callback_data": "stars_edit_3weeks", "style": "primary"}],
                [{"text": t('btn_cancel', lang), "callback_data": "cancel_admin_action", "style": "danger"}]
            ]
        },
        parse_mode='HTML'
    )


def handle_stars_package_selection(chat_id, user_id, message_id, duration_key):
    """معالجة اختيار باقة نجوم لتعديل سعرها"""
    if user_id not in ADMIN:
        return
    lang = get_user_language(user_id)
    save_user_page(user_id, 'admin')  # حفظ أن المستخدم في لوحة الأدمن
    from config import STARS_PRICES, DURATION_LABELS
    current_price = STARS_PRICES.get(duration_key, 0)
    label = DURATION_LABELS.get(duration_key, {}).get(lang, duration_key)
    admin_context[user_id] = {'stars_duration': duration_key, 'current_price': current_price}
    user_states[user_id] = 'waiting_stars_new_price'
    edit_message_text(
        chat_id, message_id,
        t('change_stars_enter_price', lang, label=label, current=current_price),
        reply_markup=cancel_button(back_to='admin'),
        parse_mode='HTML'
    )


def handle_stars_new_price_input(chat_id, user_id, text):
    """استقبال السعر الجديد وعرض ملخص للتأكيد"""
    lang = get_user_language(user_id)
    duration_key = admin_context.get(user_id, {}).get('stars_duration')
    if not duration_key:
        send_message(chat_id, t('admin_action_generic_error', lang), parse_mode='HTML', reply_markup=admin_buttons(lang))
        user_states.pop(user_id, None)
        admin_context.pop(user_id, None)
        return
    new_price = text.strip()
    if not new_price.isdigit() or int(new_price) < 0:
        send_message(
            chat_id,
            t('change_stars_invalid', lang),
            parse_mode='HTML',
            reply_markup=cancel_button()
        )
        return
    new_price = int(new_price)
    from config import STARS_PRICES, DURATION_LABELS
    current_price = STARS_PRICES.get(duration_key, 0)
    label = DURATION_LABELS.get(duration_key, {}).get(lang, duration_key)
    # حفظ السعر الجديد المعلق
    global stars_price_change_pending
    stars_price_change_pending[user_id] = {
        'duration_key': duration_key,
        'new_price': new_price,
        'old_price': current_price,
        'label': label
    }
    from buttons import change_stars_confirm_buttons
    send_message(
        chat_id,
        t('change_stars_summary', lang, label=label, old=current_price, new=new_price),
        parse_mode='HTML',
        reply_markup=change_stars_confirm_buttons(lang)
    )
    user_states.pop(user_id, None)


def confirm_stars_price_change(chat_id, user_id, message_id):
    """تأكيد تغيير السعر وتحديثه"""
    lang = get_user_language(user_id)
    pending = stars_price_change_pending.pop(user_id, None)
    if not pending:
        edit_message_text(
            chat_id, message_id,
            t('admin_action_generic_error', lang),
            reply_markup=admin_buttons(lang),
            parse_mode='HTML'
        )
        return
    from config import STARS_PRICES, save_data
    duration_key = pending['duration_key']
    new_price = pending['new_price']
    old_price = pending['old_price']
    label = pending['label']
    # تحديث السعر
    STARS_PRICES[duration_key] = new_price
    # حفظ في ملف data/data.json
    try:
        import json
        import os
        prices_file = 'data/stars_prices.json'
        with open(prices_file, 'w') as f:
            json.dump(STARS_PRICES, f)
    except Exception as e:
        print(f"[Stars Prices Save Error] {e}")
    edit_message_text(
        chat_id, message_id,
        t('change_stars_success', lang, label=label, old=old_price, new=new_price),
        reply_markup=admin_buttons(lang),
        parse_mode='HTML'
    )
    admin_context.pop(user_id, None)
