#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WORMGPTbot.py — API مباشر لنموذج WORMGPT Thinking

يقرأ السستم برومبت وطبقة التفكير مباشرة من config.py (مُدمجة في الكود)
بدلاً من قراءتها من ملف wormgpt_personality.txt على القرص.
يعمل كطبقة تفكير مستقلة لكل مستخدم (Session + UUID).
"""

import sys
import uuid
import json
import time
import requests

# استيراد كل الإعدادات من config.py (لا قراءة من ملف خارجي)
from config import (
    # ===== شخصية التفكير (مُدمجة مباشرة في config.py) =====
    THINKING_SYSTEM_PROMPT,        # السستم برومبت الكامل لنموذج التفكير
    THINKING_LAYER_PREFIX,         # طبقة التفكير البرمجية
    # ===== API إعدادات نموذج التفكير =====
    THINKING_API_URL,              # رابط API
    THINKING_API_KEY,              # مفتاح API
    THINKING_MODEL_ID,             # اسم النموذج
    THINKING_CHAT_STYLE,           # نمط المحادثة
    THINKING_HACKER_IS_STINKY,     # علم تفعيل الوضع
    THINKING_ENABLED_TOOLS,        # الأدوات المفعّلة
    THINKING_TIMEOUT,              # مهلة الطلب
    THINKING_MODEL_NAME_IN_RESPONSE,  # اسم النموذج في الردود
)

# ===== إعدادات API (مأخوذة من config.py) =====
API_URL = THINKING_API_URL
API_KEY = THINKING_API_KEY
MODEL_ID = THINKING_MODEL_ID
CHAT_STYLE = THINKING_CHAT_STYLE
HACKER_IS_STINKY = THINKING_HACKER_IS_STINKY
ENABLED_TOOLS = THINKING_ENABLED_TOOLS

# السستم برومبت وطبقة التفكير (مأخوذان مباشرة من config.py)
SYSTEM_PROMPT = THINKING_SYSTEM_PROMPT
THINKING_LAYER = THINKING_LAYER_PREFIX

# ===== تخزين الجلسات لكل مستخدم =====
# كل مستخدم له UUID مستقل و Session مستقلة
user_sessions = {}

def get_or_create_session(user_id):
    """إنشاء أو الحصول على جلسة مستقلة لكل مستخدم"""
    uid = str(user_id)
    if uid not in user_sessions:
        user_sessions[uid] = {
            'session_uuid': str(uuid.uuid4()),
            'sensitivity_request_id': str(uuid.uuid4()),
            'created_at': time.time(),
            'last_used': time.time(),
        }
    else:
        user_sessions[uid]['last_used'] = time.time()
    return user_sessions[uid]

def clear_session(user_id):
    """مسح جلسة مستخدم محدد"""
    uid = str(user_id)
    if uid in user_sessions:
        del user_sessions[uid]


def build_thinking_prompt(user_message, user_lang='ar'):
    """بناء البرومبت الكامل مع طبقة التفكير (مصدرها config.py)"""
    thinking_prompt = (
        f"{SYSTEM_PROMPT}\n\n"
        f"[CRITICAL INSTRUCTIONS — WORMGPT Thinking Mode]\n"
        f"1. You MUST ALWAYS respond in the SAME LANGUAGE as the user's message ({user_lang}).\n"
        f"2. Your name is '{THINKING_MODEL_NAME_IN_RESPONSE}' in this mode.\n"
        f"3. Be natural, organized, and conversational.\n"
        f"4. NEVER use A), B), C) labels unless the user explicitly asks for them.\n"
        f"5. Think deeply before answering but NEVER reveal your internal thinking process.\n"
        f"6. Provide ONLY the final refined answer.\n"
        f"7. Do NOT include headers like 'Thinking Process' or 'Analysis Steps'.\n\n"
        f"{THINKING_LAYER}"
        f"User message:\n{user_message}"
    )
    return thinking_prompt

# ===== استدعاء API =====
def call_thinking_api(user_request, user_id=None, user_lang='ar'):
    """استدعاء API التفكير مع طبقة التفكير البرمجية (من config.py)"""
    session = get_or_create_session(user_id or 'default')

    # بناء البرومبت مع طبقة التفكير
    full_prompt = build_thinking_prompt(user_request, user_lang)

    # بناء chatHistory
    chat_history = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": full_prompt}
    ]

    data_payload = {
        "chat_style": CHAT_STYLE,
        "chatHistory": json.dumps(chat_history, ensure_ascii=False),
        "model": MODEL_ID,
        "session_uuid": session['session_uuid'],
        "sensitivity_request_id": session['sensitivity_request_id'],
        "hacker_is_stinky": HACKER_IS_STINKY,
        "enabled_tools": ENABLED_TOOLS,
    }

    headers = {
        "authority": "api.deepai.org",
        "accept": "*/*",
        "api-key": API_KEY,
        "origin": "https://deepai.org",
        "user-agent": (
            "Mozilla/5.0 (Linux; Android 15; SM-A145P) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36"
        ),
    }

    try:
        response = requests.post(
            API_URL,
            headers=headers,
            files=[],
            data=data_payload,
            stream=True,
            timeout=THINKING_TIMEOUT,
        )

        if response.status_code != 200:
            return None

        response.encoding = "utf-8"
        content_type = response.headers.get("Content-Type", "")

        if "text/event-stream" in content_type or "stream" in content_type:
            collected = []
            for line in response.iter_lines(decode_unicode=True):
                if not line:
                    continue
                if line.startswith("data: "):
                    line = line[6:]
                    if line == "[DONE]":
                        break
                line = line.strip()
                if not line:
                    continue
                if line.startswith("{") and line.endswith("}"):
                    try:
                        obj = json.loads(line)
                        for key in ("content", "text", "delta", "message", "response", "answer", "reply"):
                            val = obj.get(key)
                            if isinstance(val, str) and val:
                                collected.append(val)
                                break
                            if isinstance(val, list):
                                for v in val:
                                    if isinstance(v, dict):
                                        inner = v.get('text') or v.get('content')
                                        if isinstance(inner, str):
                                            collected.append(inner)
                                break
                        else:
                            choices = obj.get("choices")
                            if isinstance(choices, list) and choices:
                                delta = choices[0].get("delta") or {}
                                c = delta.get("content")
                                if isinstance(c, str) and c:
                                    collected.append(c)
                    except Exception:
                        collected.append(line)
                else:
                    collected.append(line)
            full = ''.join(collected).strip()
            return full if full else None
        else:
            try:
                obj = response.json()
                for key in ("content", "text", "reply", "response", "answer", "output", "result"):
                    v = obj.get(key)
                    if isinstance(v, str) and v:
                        return v
                choices = obj.get("choices")
                if isinstance(choices, list) and choices:
                    msg = choices[0].get("message") or {}
                    c = msg.get("content")
                    if isinstance(c, str) and c:
                        return c
                return None
            except Exception:
                return response.text.strip() if response.text and response.text.strip() else None
    except Exception:
        return None

# ===== واجهة برمجية مباشرة =====
def ask(user_message, user_id=None, user_lang='ar'):
    """
    الدالة الرئيسية للتفكير.
    المدخلات:
      - user_message: رسالة المستخدم
      - user_id: معرف المستخدم (للجلسات المستقلة)
      - user_lang: لغة المستخدم (افتراضي 'ar')
    المخرجات:
      - نص الرد أو None عند الفشل

    ملاحظة: السستم برومبت وطبقة التفكير البرمجية يُجلبان من config.py مباشرةً
    (لا توجد قراءة من ملف wormgpt_personality.txt).
    """
    return call_thinking_api(user_message, user_id=user_id, user_lang=user_lang)

# ===== اختبار مباشر =====
if __name__ == '__main__':
    print("=" * 60)
    print("WORMGPT Thinking API - Test Mode")
    print("=" * 60)
    print(f"System prompt source: config.py (embedded)")
    print(f"Thinking layer source: config.py (embedded)")
    print(f"Model: {MODEL_ID}")
    print(f"API URL: {API_URL}")
    print("-" * 60)

    test_user = "test_user_123"
    session = get_or_create_session(test_user)
    print(f"Session UUID: {session['session_uuid']}")
    print(f"Sensitivity ID: {session['sensitivity_request_id']}")
    print("-" * 60)

    test_msg = "ما هي فوائد الذكاء الاصطناعي في التعليم؟"
    print(f"User: {test_msg}")
    print("Thinking...")

    result = ask(test_msg, user_id=test_user, user_lang='ar')
    if result:
        print(f"\nWORMGPT Thinking: {result[:500]}...")
    else:
        print("\nNo response received.")
