import logging
import os
import traceback
from logging.handlers import RotatingFileHandler

# ========================================================================
#                      نظام تسجيل الأخطاء والأحداث
# ========================================================================

# إنشاء مجلد logs إن لم يكن موجوداً
if not os.path.exists('logs'):
    os.makedirs('logs')

_formatter_file = logging.Formatter(
    '%(asctime)s | %(levelname)-8s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
_formatter_console = logging.Formatter(
    '%(asctime)s | %(levelname)-8s | %(message)s',
    datefmt='%H:%M:%S'
)

# ===== سجل الأخطاء فقط (errors.log) — 5MB × 3 ملفات =====
_error_handler = RotatingFileHandler(
    'logs/errors.log', maxBytes=5 * 1024 * 1024,
    backupCount=3, encoding='utf-8'
)
_error_handler.setLevel(logging.ERROR)
_error_handler.setFormatter(_formatter_file)

# ===== سجل كل العمليات (bot.log) — 5MB × 2 ملفات =====
_info_handler = RotatingFileHandler(
    'logs/bot.log', maxBytes=5 * 1024 * 1024,
    backupCount=2, encoding='utf-8'
)
_info_handler.setLevel(logging.INFO)
_info_handler.setFormatter(_formatter_file)

# ===== سجل الكونسول =====
_console_handler = logging.StreamHandler()
_console_handler.setLevel(logging.WARNING)   # الكونسول: تحذيرات وما فوق فقط (أسرع)
_console_handler.setFormatter(_formatter_console)

logger = logging.getLogger('WormBot')
logger.setLevel(logging.DEBUG)
# تجنب إضافة handlers مكررة عند إعادة الاستيراد
if not logger.handlers:
    logger.addHandler(_error_handler)
    logger.addHandler(_info_handler)
    logger.addHandler(_console_handler)


# ========================================================================
#                      دوال التسجيل العامة
# ========================================================================

def log_error(message, user_id=None, exc=None):
    """تسجيل خطأ مع كامل التفاصيل (Traceback) في errors.log"""
    prefix = f"[uid:{user_id}] " if user_id else ""
    full_msg = f"{prefix}{message}"
    if exc is not None:
        tb = traceback.format_exc()
        if tb and tb.strip() != 'NoneType: None':
            full_msg += f"\n--- Traceback ---\n{tb.strip()}\n-----------------"
    logger.error(full_msg)


def log_info(message, user_id=None):
    """تسجيل حدث عادي في bot.log"""
    prefix = f"[uid:{user_id}] " if user_id else ""
    logger.info(f"{prefix}{message}")


def log_warning(message, user_id=None):
    """تسجيل تحذير في bot.log"""
    prefix = f"[uid:{user_id}] " if user_id else ""
    logger.warning(f"{prefix}{message}")


def safe_run(func, *args, fallback=None, label="", user_id=None, **kwargs):
    """
    ينفّذ الدالة بشكل آمن. عند أي خطأ يسجّله ويعيد fallback
    بدلاً من إيقاف البوت.
    """
    try:
        return func(*args, **kwargs)
    except Exception as exc:
        log_error(f"[safe_run][{label}] {exc}", user_id=user_id, exc=exc)
        return fallback
