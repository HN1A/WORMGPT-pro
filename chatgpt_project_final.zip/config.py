import requests
import json
import os
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from deep_translator import GoogleTranslator

# ========================================================================
#                      البيانات
# ========================================================================

TOKEN = '8585533927:AAGGC0txusnOvp8vnxhFYVXUKwIql0g9Ugc'
ADMIN = [8380297249]
OWNER_NAME = '𝗜𝗤𝗖𝘆𝗯𝗲𝗿964🇮🇶'
OWNER_USER = '@MuhibIQ'
CHANNEL = '@IQCyber1'

URL = f"https://api.telegram.org/bot{TOKEN}"
#ملاحظه البوت مجرد اسم  وكذالك api فقط اسم  وكل شيء اخلاقي  لايوجد شيء يقدم محتوى غير اخلاقي  
#حتى النماذج وحتى روابط api الاسسيه هي تم انشائه على اسم المشروع  ويوجد مفاتيح في السيرفر للنماذج قويه لايمكن فك قيودها هذا مشروع فقط محاكات لا اكثر ولايقدم اشيءا غير اخلاقي.  


# ===== جلسة HTTP مشتركة (Session) =====
# تُستخدم لكل الطلبات الصادرة بدلاً من استدعاء requests.post/get مباشرة، لسببين:
# 1) إعادة استخدام الاتصال (Connection Pooling/Keep-Alive): لا حاجة لفتح اتصال TCP/TLS جديد مع
#    كل ضغطة زر أو طلب، مما يسرّع استجابة الأزرار الشفافة بشكل ملموس.
# 2) إعادة محاولة تلقائية عند انقطاعات الشبكة المؤقتة (مثل "Connection reset by peer" أو أخطاء
#    الخادم 500/502/503/504) بدلاً من فشل الطلب فوراً.
_retry_strategy = Retry(total=3, backoff_factor=0.5, status_forcelist=[500, 502, 503, 504])
_adapter = HTTPAdapter(max_retries=_retry_strategy, pool_connections=20, pool_maxsize=20)
session = requests.Session()
session.mount("https://", _adapter)
session.mount("http://", _adapter)

# ===== WormGPT API =====
WORM_API_URL = "https://wormgpt2-u2rn.vercel.app/chat"

# توزيع الحمولة بين مرآتَي API الأول (V1) — يُجرَّب الأول ثم الثاني
WORM_API_URLS = [
    "https://worm-gpt-opal.vercel.app/chat",   # المرآة الأولى (أولوية)
    "https://wormgpt2-u2rn.vercel.app/chat",    # المرآة الاحتياطية
]
DUCKDUCKGO_API = "https://api.duckduckgo.com/"

# ========================================================================
#      نماذج البحث (Research Models) — WORMGPT-research-V1 / V2
# ========================================================================
# نظام منفصل تماماً عن نماذج الذكاء الاصطناعي التقليدية (V1/V2):
#   • WORMGPT-research-V1 → DuckDuckGo search API. متاح لجميع المستخدمين.
#   • WORMGPT-research-V2 → بحث عميق مع دعم الصور والـ context=20.
#      مقصور على الأدمن والمشتركين VIP فقط.

# ===== WORMGPT-research-V1 (DuckDuckGo) =====
# يستخدم نفس خدمة DuckDuckGo أعلاه (DUCKDUCKGO_API) ولكن كنموذج بحث
# محدد قابل للاختيار من قبل المستخدم من زر "نماذج البحث".
RESEARCH_V1_NAME = 'WORMGPT-research-V1'
RESEARCH_V1_TIMEOUT = 15   # مهلة طلب البحث النصي لـ DuckDuckGo

# ===== WORMGPT-research-V2 (deepai.org - بحث بالصور و context=20) =====
# متاح فقط لـ VIP / الأدمن. يدعم النصوص والصور.
# صيغة الـ request مختلفة كلياً عن V1/V2: multipart/form-data + streaming.
# يأتي النموذج V2 مع:
#   • context=20 رسالة (مخزّن في user_conversations عند تفعيل البحث V2)
#   • استقبال الصور (base64 في حقل visible_text، أو الإشارة لها في الجولة الأولى)
#   • api-key ثابت من ملف الموكود (تم التحقق منه وإرفاقه)
RESEARCH_V2_NAME = 'WORMGPT-research-V2'
RESEARCH_V2_URL = 'https://api.deepai.org/hacking_is_a_serious_crime'
RESEARCH_V2_API_KEY = 'tryit-90271057859-eb951a10b6f9af863153149dd6abf48d'
RESEARCH_V2_MODEL = 'online'                  # النموذج المستخدم في البحث V2 (online من الموكود)
RESEARCH_V2_SESSION_UUID = '27a1e634-d497-4e60-85e2-fccb1b8ce733'
RESEARCH_V2_SENSITIVITY_REQ_ID = '929eda5c-d009-4f34-823d-43c721c2f1c7'
RESEARCH_V2_HACKER_IS_STINKY = 'very_stinky'
RESEARCH_V2_CHAT_STYLE = 'chat'
RESEARCH_V2_ENABLED_TOOLS = '["image_generator","image_editor"]'
RESEARCH_V2_CONTEXT_LIMIT = 20   # سياق V2 = 20 رسالة (محدد من المتطلبات)
RESEARCH_V2_TIMEOUT = 60         # مهلة طلب البحث V2
RESEARCH_V2_STREAMING = True     # يستخدم streaming response

# User-Agent الافتراضي لـ deepai.org للبحث V2
RESEARCH_V2_USER_AGENT = 'Mozilla/5.0 (Linux; Android 15; SM-A145P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36'

# ===== System prompt للبحث V2 (مأخوذ من ملف الموكود، مترجم لـ multilingual) =====
# هذا الـ prompt يُلحق بـ messages ليدرس طلب المستخدم ويبحث بعمق في الشبكة
def build_research_v2_system_prompt(user_request):
    """بناء الـ system prompt الخاص بـ WORMGPT-research-V2 (مأخوذ من ملف الموكود)"""
    return (
        "Carefully analyze the user's request.\n\n"
        "Perform a deep search using all available search capabilities.\n\n"
        "Collect information from multiple reliable sources.\n\n"
        "Cross-check important facts.\n\n"
        "Prefer official documentation whenever available.\n\n"
        "Include direct source URLs only if they are verified.\n\n"
        "Explain your reasoning clearly.\n\n"
        "Summarize the final answer.\n\n"
        "At the end provide a \"Sources\" section containing every reference used.\n\n"
        f"User request:\n\n{user_request}"
    )

# ===== WormGPT-V2 API =====
WORM_V2_API_URL = "https://gemma3.cc/api/chat"  # API النموذج الثاني (gemma-3-27b)
V2_MODEL = "gemma-3-27b"                         # اسم النموذج المستخدم في V2
V2_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Linux; Android 10)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0)"
]

# ===== روابط V2 البديلة (Silent Failover) =====
# إذا فشل V2 الرئيسي لأي سبب (Timeout / خطأ خادم / استثناء / رد غير صالح)،
# يتم التبديل تلقائياً وبصمت إلى هذه الـ APIs بالترتيب قبل اللجوء إلى V1.
# كل رابط هنا يجب أن يقبل صيغة OpenAI-style:
#   {"messages":[{"role":"user","content":"..."}], "thinking":false, "locale":"en"}
V2_FALLBACK_URLS = [
    "https://ngini.com/api/chat",   # مرآة V2 الاحتياطية الأولى
]

# ===== روابط V2 البديلة من نوع deepai.org (Silent Failover - صيغة مختلفة) =====
# تستخدم كخيار ثالث (بعد gemma3.cc و ngini.com وقبل V1) — تعمل بصيغة multipart/form-data
# بدلاً من JSON، فتعاملت معها دالة مستقلة (_call_deepai_fallback في ai_engine.py).
# السبب في وجودها: deepai.org تستخدم مزوداً مختلفاً تماماً، فلو V2 الرئيسي ضغط أو V2_FALLBACK
# (ngini.com) توقفا سوياً، deepai.org تظل شغّالة وتُكمل الخدمة بصمت.
# عند إضافة رابط آخر من نفس النوع، ضعه في هذه القائمة فقط — لا تخلطه مع V2_FALLBACK_URLS
# لأن صيغة الـ requests مختلفة (multipart بدل JSON).
DEEPAI_FALLBACK_URLS = [
    "https://api.deepai.org/hacking_is_a_serious_crime",   # deepai.org — النموذج gemma-4
]

# ===== إعدادات deepai.org (مرتبطة بـ DEEPAI_FALLBACK_URLS) =====
# المعرّفات الثابتة مطلوبة من البروتوكول الخاص بـ deepai.org:
# session_uuid        → معرّف جلسة المحادثة (نستخدم ثابتاً ليحافظ على السياق)
# sensitivity_request_id → معرّف طلب فحص الحساسية
# hacker_is_stinky    → علم لتفعيل "وضع الهاكر" (مطلوب لرفع القيود المحتوى)
# model               → اسم النموذج (gemma-4 / gpt-4o-mini / …)
# chat_style          → نمط المحادثة (chat للاستخدام العادي)
DEEPAI_MODEL = "gemma-4"
DEEPAI_CHAT_STYLE = "chat"
DEEPAI_SESSION_UUID = "418efff2-9414-4389-85df-6f8b571833be"
DEEPAI_SENSITIVITY_REQUEST_ID = "6bb9ab07-b6bb-4c55-9d5b-2e8453306902"
DEEPAI_HACKER_IS_STINKY = "very_stinky"
DEEPAI_ENABLED_TOOLS = ["image_generator", "image_editor"]

# ===== تشغيل/تعطيل طبقة deepai.org ككل =====
# True  → تُجرَّب DEEPAI_FALLBACK_URLS بصمت بعد فشل gemma3.cc و V2_FALLBACK_URLS (الافتراضي)
# False → تخطّي deepai.org والانتقال مباشرةً إلى V1
DEEPAI_FALLBACK_ENABLED = True

# ===== دالة استدعاء ngini.com مع تصفية SSE (مبنية على h.py) =====
# هذه الدالة تنفّذ نفس منطق h.py بالضبط:
#   - ترسل الطلب بـ stream=True
#   - تقرأ السطور بـ iter_lines()
#   - تُصفّي كل سطر: تستخرج delta.content فقط
#   - تُجمّع القطع وتُعيد النص الكامل
def call_ngini(messages, timeout=30):
    """استدعاء ngini.com API بصيغة SSE streaming مع تصفية كاملة للرد.
    يُعيد النص المجمّع نظيفاً، أو None عند الفشل."""
    url = "https://ngini.com/api/chat"
    headers = {
        "content-type": "application/json",
        "origin": "https://ngini.com",
        "referer": "https://ngini.com/c/new?q=hi&locale=en",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    payload = {
        "messages": messages,
        "thinking": False,
        "locale": "en",
    }
    try:
        response = session.post(
            url,
            headers=headers,
            json=payload,
            stream=True,
            timeout=timeout,
        )
        if response.status_code != 200:
            return None
        # تثبيت الترميز على UTF-8 صريحاً قبل iter_lines — إجراء احتياطي دفاعي:
        # إن لم يحدّد خادم ngini.com charset في Content-Type لأي سبب، تفترض requests
        # خطأً ترميز ISO-8859-1 لمحتوى text/event-stream، فيظهر النص العربي مشوّهاً.
        response.encoding = "utf-8"
        answer = ""
        for line in response.iter_lines(decode_unicode=True):
            if not line:
                continue
            if line.startswith("data: "):
                data = line[6:]
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                    if "choices" in obj:
                        delta = obj["choices"][0]["delta"]
                        if "content" in delta:
                            answer += delta["content"]
                except Exception:
                    pass
        return answer.strip() if answer.strip() else None
    except Exception:
        return None


# ===== أنماط كشف "نفاد الرصيد / تجاوز الحد" في V2 =====
# تُستخدم لتمييز أخطاء الرصيد (التي تستوجب إبلاغ المستخدم) عن أخطاء الاتصال العابرة
# (التي تُعالَج بصمت عبر التبديل بين الروابط). يمكن إضافة أنماط جديدة بسهولة.
V2_BALANCE_ERROR_PATTERNS = [
    'quota exceeded', 'quota_exceeded', 'insufficient_quota',
    'insufficient balance', 'insufficient credit', 'insufficient credits',
    'no balance', 'balance exhausted', 'balance is 0', 'balance is low',
    'rate limit', 'rate_limit', 'too many requests', 'rate-limit',
    'billing', 'payment required', 'subscription limit',
    'limit exceeded', 'daily limit', 'monthly limit', 'tier limit',
    'free tier', 'upgrade plan', 'upgrade your', 'plan limit',
    'out of credits', 'out of quota', 'no credits',
    'plan does not allow', 'purchase more credits', 'buy credits',
    'credit limit', 'exceeded your current quota',
    'تم استخدام الحد', 'نفاد الرصيد', 'انتهت الرصيد', 'تجاوز الحد',
]

# ===== إعدادات النظام (Timeouts) =====
V2_PRIMARY_TIMEOUT = 30   # مهلة V2 الرئيسي
V2_FALLBACK_TIMEOUT = 30  # مهلة كل رابط بديل من V2
V1_TIMEOUT = 50           # مهلة V1 (داخل ask_wormgpt)
DEEPAI_TIMEOUT = 45       # مهلة كل رابط deepai.org (multipart رفع وحمل أكبر)

# ===== تشغيل/تعطيل V2 الرئيسي (gemma3.cc) =====
# True  → تشغيل gemma3.cc بشكل طبيعي (السلوك الافتراضي)
# False → تخطّي gemma3.cc تماماً والانتقال مباشرةً إلى ngini.com
V2_PRIMARY_ENABLED = True

# ===== إعدادات النموذج الثاني (V2) =====
V2_TRIAL_LIMIT = 4          # عدد رسائل V2 اليومية المجانية (تُجدَّد كل 24 ساعة)

# ===== المترجم =====
translator = GoogleTranslator(source='auto', target='ar')

# ===== تخزين المحادثات =====
user_conversations = {}
MAX_HISTORY = 10            # الحد الافتراضي للذاكرة (غير مشترك)
MAX_HISTORY_VIP = 50        # حد الذاكرة لمشتركي VIP / الأدمن (تم الرفع من 20 إلى 50 كما طلب المستخدم)

# ===== حد حجم الكود للعرض المباشر =====
MAX_INLINE_CODE_SIZE = 800  # تم الرفع من 500 إلى 800

# ===== نظام الوقت الفاصل بين رسائل المستخدمين العاديين =====
COOLDOWN_SECONDS = 25  # المستخدمين العاديين يجب الانتظار 25 ثانية بين كل رسالة، اما VIP فلا يوجد انتظار

# ===== نظام رصيد الرسائل =====
DEFAULT_MESSAGES_LIMIT = 20  # عدد الرسائل الافتراضي لكل مستخدم جديد

# ===== مدد اشتراك VIP المتاحة (بالثواني) =====
VIP_DURATIONS = {
    'week': 7 * 24 * 60 * 60,
    '2weeks': 14 * 24 * 60 * 60,
    '3weeks': 21 * 24 * 60 * 60
}

# ===== تسميات مدد الاشتراك (متعددة اللغات) - تُستخدم في لوحة الأدمن وفي فواتير نجوم تلجرام =====
DURATION_LABELS = {
    'week': {'ar': 'أسبوع', 'en': '1 week', 'ru': '1 неделя', 'zh': '1周', 'fa': '۱ هفته'},
    '2weeks': {'ar': 'أسبوعين', 'en': '2 weeks', 'ru': '2 недели', 'zh': '2周', 'fa': '۲ هفته'},
    '3weeks': {'ar': '3 أسابيع', 'en': '3 weeks', 'ru': '3 недели', 'zh': '3周', 'fa': '۳ هفته'},
}

# ===== أسعار اشتراك VIP بنجوم تلجرام (XTR) =====
STARS_PRICES = {
    'week': 10,
    '2weeks': 20,
    '3weeks': 30
}

# ===== تخزين وقت آخر رسالة لكل مستخدم (للنظام الزمني) =====
last_message_time = {}

# ===== سياق إجراءات الأدمن متعددة الخطوات (إذاعة / تجديد رسائل / VIP) =====
admin_context = {}

# ===== حالات انتظار إدخال المستخدم/الأدمن (محادثة متعددة الخطوات) =====
user_states = {}

# ===== تخزين مؤقت للصور (قبل أن يؤكد المستخدم رغبته في التحليل) =====
photo_pending = {}

# ===== تخزين مؤقت للملفات المرفوعة (قبل أن يُرسل المستخدم التعليم) =====
# البنية: file_pending[user_id] = {
#     'file_id': str,         # معرف الملف في تيليجرام لإعادة تنزيله عند الحاجة
#     'file_name': str,       # اسم الملف الأصلي
#     'content': str,         # محتوى الملف كنص
#     'line_count': int,      # عدد الأسطر
#     'extension': str,       # امتداد الملف (مثلاً .py)
#     'message_id': int,      # معرف الرسالة التي وصل فيها الملف
# }
file_pending = {}

# ===== تخزين آخر طلب AI لكل مستخدم (لتمكين زر "إعادة المحاولة" من إعادة التنفيذ فعلياً) =====
# البنية: last_ai_query[user_id] = {
#     'query': str,          # النص الأصلي الذي أرسله المستخدم
#     'is_code': bool,       # هل الطلب يتعلق بكود برمجي؟
#     'model': str,          # النموذج المطلوب (v1/v2)
#     'ts': float,           # وقت الحفظ (لإعادة تعيين الحالة بعد فترة طويلة)
# }
last_ai_query = {}

# ===== تخزين نموذج البحث المختار لكل مستخدم =====
# 'research_v1' (افتراضي - DuckDuckGo للجميع)
# 'research_v2' (للمشتركين VIP فقط - بحث عميق مع صور و context=20)
# البنية: user_research_model[user_id] = 'research_v1' | 'research_v2'
user_research_model = {}

# ===== تخزين الصور المعلقة لبحث V2 =====
# البنية: research_image_pending[user_id] = {
#     'file_id': str,            # معرف ملف الصورة في تيليجرام
#     'mime': str,               # نوع الصورة (image/jpeg, image/png, ...)
#     'b64': str,                # الصورة بصيغة base64
#     'caption': str,            # caption (إن وُجد)
#     'ts': float,               # وقت التخزين
# }
research_image_pending = {}

# ===== نوافذ زمنية لسياق البحث V2 =====
# عند انتهاء المدة، يُمسح السياق تلقائياً لمنع تكديس المحادثات القديمة
RESEARCH_V2_CONTEXT_TTL_SECONDS = 60 * 60   # ساعة واحدة كافية لجلسة بحث

# ===== إعدادات ميزة رفع الملفات (V2 File Upload) =====
SUPPORTED_FILE_EXTENSIONS = {
    # نصوص عامة
    '.txt', '.md', '.log', '.csv', '.tsv',
    # لغات برمجة
    '.py', '.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs',
    '.java', '.kt', '.kts', '.scala',
    '.c', '.cpp', '.cc', '.cxx', '.h', '.hpp', '.hxx',
    '.cs', '.vb',
    '.go', '.rs', '.swift', '.m', '.mm',
    '.php', '.rb', '.pl', '.lua', '.r',
    '.sh', '.bash', '.zsh', '.ps1', '.bat', '.cmd',
    # علامات وصفية
    '.html', '.htm', '.xhtml', '.xml', '.svg',
    '.css', '.scss', '.sass', '.less',
    '.json', '.json5', '.jsonc',
    '.yaml', '.yml', '.toml', '.ini', '.cfg', '.conf', '.env',
    # قواعد بيانات وبيانات
    '.sql', '.graphql', '.gql',
    # لغات أخرى
    '.dart', '.ex', '.exs', '.elm', '.clj', '.cljs', '.cljc',
    '.fs', '.fsx', '.ml', '.mli',
    # ملفات نصية مرتبطة بـ CVE (CVE-related text files)
    '.cve', '.nmap', '.nessus', '.xml',
}
FILE_MAX_LINES = 100        # الحد الأقصى لعدد الأسطر
FILE_MAX_BYTES = 200_000    # حد أعلى لعدد البايتات (200KB) لحماية الذاكرة

# ===== وضع الصيانة (متغير في الذاكرة فقط - يُعاد ضبطه على "متوقف" عند إعادة تشغيل البوت) =====
MAINTENANCE_MODE = False

def is_maintenance_mode():
    return MAINTENANCE_MODE

def set_maintenance_mode(enabled):
    global MAINTENANCE_MODE
    MAINTENANCE_MODE = enabled

# ========================================================================
#                      نظام الإحالة (Referral)
# ========================================================================
BOT_USERNAME    = "WormGPT_ai_1bot"   # يوزر البوت للرابط
REFERRAL_ENABLED = True                # تشغيل/إيقاف زر الإحالة عالمياً

def is_referral_enabled():
    return REFERRAL_ENABLED

def set_referral_enabled(enabled):
    global REFERRAL_ENABLED
    REFERRAL_ENABLED = enabled

# ========================================================================
#                      تخزين بيانات المستخدمين (data/data.json)
# ========================================================================

data = {}
if not os.path.exists('data'):
    os.makedirs('data')
if not os.path.exists('data/data.json'):
    with open('data/data.json', 'w') as f:
        json.dump({}, f)
with open('data/data.json', 'r') as f:
    try:
        data = json.load(f)
    except:
        data = {}

def save_data():
    """حفظ بيانات المستخدمين في الملف"""
    try:
        with open('data/data.json', 'w') as f:
            json.dump(data, f)
    except Exception as e:
        print(f"[Save Data Error] {e}")
