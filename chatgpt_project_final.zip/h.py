"""
h.py — اختبار مباشر لـ ngini.com SSE streaming
هذا الملف للتجربة اليدوية فقط، منطقه مدمج داخل ai_engine.py
"""
import json
import requests

url = "https://ngini.com/api/chat"

headers = {
    "content-type": "application/json",
    "origin": "https://ngini.com",
    "referer": "https://ngini.com/c/new?q=hi&locale=en",
    "user-agent": "Mozilla/5.0",
}

payload = {
    "messages": [
        {
            "role": "user",
            "content": "Hello, please explain what a loop is, what it is, and how to think effectively in programming. "
        }
    ],
    "thinking": False,
    "locale": "en"
}

response = requests.post(
    url,
    headers=headers,
    json=payload,
    stream=True
)

answer = ""

for line in response.iter_lines(decode_unicode=True):
    if not line:
        continue

    if line.startswith("data: "):
        data = line[6:]

        if data == "[DONE]":
            break

        try:
            obj = json.loads(data)

            if "choices" in obj:
                delta = obj["choices"][0]["delta"]
                if "content" in delta:
                    text = delta["content"]
                    answer += text
                    print(text, end="", flush=True)

        except Exception:
            pass

print("\n\nFinal Answer:")
print(answer)
