"""
test_cascade.py — اختبارات آلية لـ Cascade الجديد (V2 → OpenAI fallback → DeepAI fallback → V1)

شغّل بـ:
    cd project_bot
    python3 test_cascade.py

يُجرّب 8 سيناريوهات مختلفة للتأكد أن deepai.org fallback يعمل بشكل صحيح:
  1) V2 primary ينجح → لا failover
  2) V2 + OpenAI fallback يفشلان، DeepAI ينجح
  3) SSE parser يستخرج content
  4) Vercel-AI parser يستخرج content
  5) plain JSON parser يستخرج content
  6) DeepAI 429 يرفع NoBalanceError
  7) كل fail → None (→ V1 silent)
  8) DEEPAI_FALLBACK_ENABLED=False يتخطى DeepAI

كل الاختبارات off-line — لا اتصال حقيقي.
"""
import sys
import os
import json

# ضروري لنجاح import config
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class FakeResponse:
    """استجابة وهمية تحاكي production بدقة لـ gemma3.cc / ngini.com / deepai.org"""
    def __init__(self, status_code=200, text='', lines=None):
        self.status_code = status_code
        self._text = text
        self.encoding = 'utf-8'
        self._lines = lines or []
    def json(self):
        try:
            return json.loads(self._text)
        except Exception:
            raise ValueError("not json")
    @property
    def text(self):
        return self._text
    def iter_lines(self, decode_unicode=True):
        for line in self._lines:
            yield line
    def close(self):
        pass


def run_tests():
    import config
    import ai_engine

    passed = 0
    failed = 0

    def t(label, ok, extra=''):
        nonlocal passed, failed
        mark = '[OK]  ' if ok else '[FAIL]'
        print(f'{mark} {label}{": " + extra if extra else ""}')
        if ok:
            passed += 1
        else:
            failed += 1
        return ok

    messages = [
        {'role': 'system', 'content': 'You are WormGPT'},
        {'role': 'user', 'content': 'hi'},
    ]

    # ===== TEST 1 =====
    print()
    print('=' * 60)
    print('TEST 1: V2 primary succeeds → no failover needed')
    print('=' * 60)
    call_log = []
    def fp1(url, **kw):
        call_log.append(url)
        if 'gemma3.cc' in url:
            return FakeResponse(200, '0:"رد من V2 الأساسي"')
        return FakeResponse(500, 'should not be called')
    config.session.post = fp1
    r = ai_engine._call_v2_with_failover(messages)
    t('V2 primary returns content', r and 'V2 الأساسي' in r, f'result={r!r}')
    t('no OpenAI fallback called', not any('ngini.com' in c for c in call_log))
    t('no DeepAI fallback called', not any('deepai.org' in c for c in call_log))

    # ===== TEST 2 =====
    print()
    print('=' * 60)
    print('TEST 2: V2 + OpenAI fallback fail → DeepAI succeeds')
    print('=' * 60)
    call_log = []
    deepai_lines = [
        '{"type":"message","content":"هذا رد من deepai.org!","role":"assistant"}',
        '{"type":"message","content":" استجابة كاملة","role":"assistant"}',
    ]
    def fp2(url, **kw):
        call_log.append(url)
        if 'gemma3.cc' in url:    return FakeResponse(503, 'unavailable')
        if 'ngini.com' in url:    return FakeResponse(502, 'bad gateway')
        if 'deepai.org' in url:   return FakeResponse(200, '', lines=deepai_lines)
        return FakeResponse(500)
    config.session.post = fp2
    r = ai_engine._call_v2_with_failover(messages)
    t('DeepAI returns content', r and 'deepai.org' in r and 'استجابة كاملة' in r,
      f'result={r!r}')
    chain = [c.split('/')[2] for c in call_log]
    t('V2 primary tried', 'gemma3.cc' in chain)
    t('OpenAI fallback tried', 'ngini.com' in chain)
    t('DeepAI fallback tried (after V2 + OpenAI)', 'api.deepai.org' in chain)
    t('chain order: V2 → OpenAI → DeepAI',
      chain[:2] == ['gemma3.cc', 'gemma3.cc']
      and chain[2:4] == ['ngini.com', 'ngini.com']
      and 'api.deepai.org' in chain[4:],
      f'chain={chain}')

    # ===== TEST 3 =====
    print()
    print('=' * 60)
    print('TEST 3: parser — SSE format (data: {content})')
    print('=' * 60)
    sse_text = (
        'data: {"choices":[{"delta":{"content":"SSE "}}]}\n'
        'data: {"choices":[{"delta":{"content":"chunk"}}]}\n'
        'data: [DONE]'
    )
    r = ai_engine._parse_deepai_streaming(sse_text)
    t('SSE parser', r == 'SSE chunk', f'parsed={r!r}')

    # ===== TEST 4 =====
    print()
    print('=' * 60)
    print('TEST 4: parser — Vercel-AI format (0:"text" 1:"text")')
    print('=' * 60)
    r = ai_engine._parse_deepai_streaming('0:"Vercel "\n1:"chunk"\n2:" works"')
    t('Vercel-AI parser', r and 'Vercel chunk works' in r, f'parsed={r!r}')

    # ===== TEST 5 =====
    print()
    print('=' * 60)
    print('TEST 5: parser — plain JSON object ({"reply":"..."})')
    print('=' * 60)
    r = ai_engine._parse_deepai_streaming('{"reply":"plain json reply"}')
    t('plain JSON parser', r == 'plain json reply', f'parsed={r!r}')

    # ===== TEST 6 =====
    print()
    print('=' * 60)
    print('TEST 6: DeepAI 429 → NoBalanceError raised')
    print('=' * 60)
    def fp6(url, **kw):
        if 'gemma3.cc' in url or 'ngini.com' in url:
            return FakeResponse(503, 'fail')
        if 'deepai.org' in url:
            return FakeResponse(429, 'rate limit exceeded')
        return FakeResponse(500)
    config.session.post = fp6
    raised = False
    src = None
    try:
        ai_engine._call_v2_with_failover(messages)
    except ai_engine.NoBalanceError as e:
        raised = True
        src = e.source
    t('NoBalanceError raised', raised, f'source={src!r}')
    t('source identifies deepai.org', src and 'deepai.org' in src)

    # ===== TEST 7 =====
    print()
    print('=' * 60)
    print('TEST 7: All stages fail → None (→ V1 silent fallback in caller)')
    print('=' * 60)
    def fp7(url, **kw):
        return FakeResponse(503, 'all fail')
    config.session.post = fp7
    r = ai_engine._call_v2_with_failover(messages)
    t('cascade returns None', r is None, f'result={r!r}')

    # ===== TEST 8 =====
    print()
    print('=' * 60)
    print('TEST 8: DEEPAI_FALLBACK_ENABLED=False skips DeepAI')
    print('=' * 60)
    call_log = []
    def fp8(url, **kw):
        call_log.append(url)
        return FakeResponse(503, 'fail')
    config.session.post = fp8
    saved_flag = ai_engine.DEEPAI_FALLBACK_ENABLED
    ai_engine.DEEPAI_FALLBACK_ENABLED = False
    try:
        ai_engine._call_v2_with_failover(messages)
    finally:
        ai_engine.DEEPAI_FALLBACK_ENABLED = saved_flag
    deepai_calls = [c for c in call_log if 'deepai.org' in c]
    t('DeepAI not called when disabled', len(deepai_calls) == 0,
      f'calls={[c.split("/")[2] for c in deepai_calls]}')

    # ===== Final =====
    print()
    print('=' * 60)
    print(f'RESULT: {passed} passed, {failed} failed')
    print('=' * 60)
    return failed == 0


if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)
